﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine
{
	// Token: 0x0200001A RID: 26
	public class DoSpellCastArgs : EventArgs
	{
		// Token: 0x17000010 RID: 16
		// (get) Token: 0x060000B0 RID: 176 RVA: 0x00004EF4 File Offset: 0x000030F4
		// (set) Token: 0x060000B1 RID: 177 RVA: 0x00004F04 File Offset: 0x00003104
		public int SpellId { get; private set; }

		// Token: 0x060000B2 RID: 178 RVA: 0x00004F1C File Offset: 0x0000311C
		public DoSpellCastArgs(int spellId)
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
			DoSpellCastArgs.LNIqGyQ0mAcSyH0Ovdx();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_521a515f15c94d10b5254529acc6f115 != 0)
			{
				num = 0;
			}
			for (;;)
			{
				switch (num)
				{
				case 1:
					return;
				}
				this.SpellId = spellId;
				num = 1;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_521a515f15c94d10b5254529acc6f115 == 0)
				{
					num = 1;
				}
			}
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x00004FA0 File Offset: 0x000031A0
		// Note: this type is marked as 'beforefieldinit'.
		static DoSpellCastArgs()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00004FB0 File Offset: 0x000031B0
		internal static bool xPt4gIQNZOsvVo8TPWU()
		{
			return DoSpellCastArgs.hWo9q5Q64eN6g5pGmmM == null;
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x00004FC4 File Offset: 0x000031C4
		internal static DoSpellCastArgs tpyt65Qnd15BR0PV6fs()
		{
			return DoSpellCastArgs.hWo9q5Q64eN6g5pGmmM;
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x00004FD4 File Offset: 0x000031D4
		internal static void LNIqGyQ0mAcSyH0Ovdx()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x040000F2 RID: 242
		internal static DoSpellCastArgs hWo9q5Q64eN6g5pGmmM;
	}
}
