﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine
{
	// Token: 0x0200003C RID: 60
	public class Macro
	{
		// Token: 0x0600056B RID: 1387 RVA: 0x0002D53C File Offset: 0x0002B73C
		public Macro()
		{
			Macro.CJpSTs4tsDcZmWtxQxc();
			Macro.hkGtCD4YCHG2YfreTJJ();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_d7db82c175de47d2b5f36bc0c7f71006 == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600056C RID: 1388 RVA: 0x0002D59C File Offset: 0x0002B79C
		// Note: this type is marked as 'beforefieldinit'.
		static Macro()
		{
			Macro.KeAye04saN4avDFlVaR();
		}

		// Token: 0x0600056D RID: 1389 RVA: 0x0002D5AC File Offset: 0x0002B7AC
		internal static void CJpSTs4tsDcZmWtxQxc()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x0600056E RID: 1390 RVA: 0x0002D5BC File Offset: 0x0002B7BC
		internal static void hkGtCD4YCHG2YfreTJJ()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x0600056F RID: 1391 RVA: 0x0002D5CC File Offset: 0x0002B7CC
		internal static bool SDoWR14mlKrRV6AhYId()
		{
			return Macro.cAMk6W4JelEOQy3hwVr == null;
		}

		// Token: 0x06000570 RID: 1392 RVA: 0x0002D5E0 File Offset: 0x0002B7E0
		internal static Macro IAHgY74H33P1GlSA8kQ()
		{
			return Macro.cAMk6W4JelEOQy3hwVr;
		}

		// Token: 0x06000571 RID: 1393 RVA: 0x0002D5F0 File Offset: 0x0002B7F0
		internal static void KeAye04saN4avDFlVaR()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x0400024C RID: 588
		public string Name;

		// Token: 0x0400024D RID: 589
		public string Example;

		// Token: 0x0400024E RID: 590
		public int SpellID;

		// Token: 0x0400024F RID: 591
		public int SpellRank;

		// Token: 0x04000250 RID: 592
		public int ItemID;

		// Token: 0x04000251 RID: 593
		private static Macro cAMk6W4JelEOQy3hwVr;
	}
}
