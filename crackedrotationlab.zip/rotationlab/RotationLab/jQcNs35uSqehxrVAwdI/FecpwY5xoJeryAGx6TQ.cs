﻿using System;
using System.Reflection;
using MyU9Ep58ZH3s5ThDFJQ;
using wKolMkxZecDx58YaRR4;
using XR7RtrxI8Vm7Dgx9BKr;

namespace jQcNs35uSqehxrVAwdI
{
	// Token: 0x02000057 RID: 87
	internal class FecpwY5xoJeryAGx6TQ
	{
		// Token: 0x060007F1 RID: 2033 RVA: 0x000431DC File Offset: 0x000413DC
		internal static void Yxw0oZbn5i(int typemdt)
		{
			int num = 6;
			int num2 = num;
			for (;;)
			{
				int num3;
				FieldInfo fieldInfo;
				FieldInfo[] fields;
				switch (num2)
				{
				case 0:
					goto IL_126;
				case 1:
					num3 = 0;
					num2 = 3;
					if (FecpwY5xoJeryAGx6TQ.SO2h6ulu9DfnScyVyba() != null)
					{
						num2 = 3;
						continue;
					}
					continue;
				case 2:
				{
					MethodInfo method = (MethodInfo)FecpwY5xoJeryAGx6TQ.eRJC5elyc2boTs0vpgI(FecpwY5xoJeryAGx6TQ.fou1syrO5, FecpwY5xoJeryAGx6TQ.fPY0WJlVHErVyMflhS3(fieldInfo) + 100663296);
					num2 = 7;
					if (!FecpwY5xoJeryAGx6TQ.OqtSoilxPXZlOUSoN6a())
					{
						num2 = 5;
						continue;
					}
					continue;
				}
				case 3:
					break;
				case 4:
					break;
				case 5:
				{
					Type type;
					fields = type.GetFields();
					num2 = 0;
					if (FecpwY5xoJeryAGx6TQ.OqtSoilxPXZlOUSoN6a())
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				case 6:
				{
					Type type = FecpwY5xoJeryAGx6TQ.fou1syrO5.ResolveType(33554432 + typemdt);
					num2 = 4;
					if (FecpwY5xoJeryAGx6TQ.OqtSoilxPXZlOUSoN6a())
					{
						num2 = 5;
						continue;
					}
					continue;
				}
				case 7:
				{
					MethodInfo method;
					Type type;
					FecpwY5xoJeryAGx6TQ.OwDw8xl82PrNmidneW4(fieldInfo, null, (MulticastDelegate)Delegate.CreateDelegate(type, method));
					num2 = 8;
					continue;
				}
				case 8:
					num3++;
					num2 = 4;
					if (FecpwY5xoJeryAGx6TQ.SO2h6ulu9DfnScyVyba() != null)
					{
						num2 = 0;
						continue;
					}
					continue;
				default:
					goto IL_126;
				}
				if (num3 >= fields.Length)
				{
					break;
				}
				num2 = 0;
				if (!FecpwY5xoJeryAGx6TQ.OqtSoilxPXZlOUSoN6a())
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_126:
				fieldInfo = fields[num3];
				num2 = 2;
				if (FecpwY5xoJeryAGx6TQ.SO2h6ulu9DfnScyVyba() != null)
				{
					num2 = 0;
				}
			}
		}

		// Token: 0x060007F2 RID: 2034 RVA: 0x00043370 File Offset: 0x00041570
		public FecpwY5xoJeryAGx6TQ()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
			FecpwY5xoJeryAGx6TQ.A4GK1UlqRaksItSohvw();
			base..ctor();
			int num = 0;
			if (true)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060007F3 RID: 2035 RVA: 0x000433CC File Offset: 0x000415CC
		// Note: this type is marked as 'beforefieldinit'.
		static FecpwY5xoJeryAGx6TQ()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					FecpwY5xoJeryAGx6TQ.gRqFHAld1Bcv6FV6Xty();
					num2 = 0;
					if (!true)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
					num2 = 3;
					if (false)
					{
						num2 = 3;
						continue;
					}
					continue;
				case 3:
					goto IL_6A;
				}
				FecpwY5xoJeryAGx6TQ.bvCIZBlop6Xr3Yu6DNi();
				num2 = 2;
				if (!false)
				{
					num2 = 2;
				}
			}
			IL_6A:
			FecpwY5xoJeryAGx6TQ.fou1syrO5 = FecpwY5xoJeryAGx6TQ.RwsV9QlQ0j8bVQ4mUEN(FecpwY5xoJeryAGx6TQ.yp8l2ll3U6aigLSUuEO(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(33554519)).Assembly);
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x00043480 File Offset: 0x00041680
		internal static int fPY0WJlVHErVyMflhS3(object A_0)
		{
			return A_0.MetadataToken;
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x00043494 File Offset: 0x00041694
		internal static object eRJC5elyc2boTs0vpgI(object A_0, int A_1)
		{
			return A_0.ResolveMethod(A_1);
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x000434AC File Offset: 0x000416AC
		internal static void OwDw8xl82PrNmidneW4(object A_0, object A_1, object A_2)
		{
			A_0.SetValue(A_1, A_2);
		}

		// Token: 0x060007F7 RID: 2039 RVA: 0x000434C8 File Offset: 0x000416C8
		internal static bool OqtSoilxPXZlOUSoN6a()
		{
			return FecpwY5xoJeryAGx6TQ.pUYYP7l56mRTwEGfGqI == null;
		}

		// Token: 0x060007F8 RID: 2040 RVA: 0x000434DC File Offset: 0x000416DC
		internal static FecpwY5xoJeryAGx6TQ SO2h6ulu9DfnScyVyba()
		{
			return FecpwY5xoJeryAGx6TQ.pUYYP7l56mRTwEGfGqI;
		}

		// Token: 0x060007F9 RID: 2041 RVA: 0x000434EC File Offset: 0x000416EC
		internal static void A4GK1UlqRaksItSohvw()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x060007FA RID: 2042 RVA: 0x000434FC File Offset: 0x000416FC
		internal static void gRqFHAld1Bcv6FV6Xty()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x060007FB RID: 2043 RVA: 0x0004350C File Offset: 0x0004170C
		internal static void bvCIZBlop6Xr3Yu6DNi()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x060007FC RID: 2044 RVA: 0x0004351C File Offset: 0x0004171C
		internal static Type yp8l2ll3U6aigLSUuEO(RuntimeTypeHandle A_0)
		{
			return Type.GetTypeFromHandle(A_0);
		}

		// Token: 0x060007FD RID: 2045 RVA: 0x00043530 File Offset: 0x00041730
		internal static object RwsV9QlQ0j8bVQ4mUEN(object A_0)
		{
			return A_0.ManifestModule;
		}

		// Token: 0x0400036B RID: 875
		internal static Module fou1syrO5;

		// Token: 0x0400036C RID: 876
		internal static FecpwY5xoJeryAGx6TQ pUYYP7l56mRTwEGfGqI;

		// Token: 0x02000058 RID: 88
		internal sealed class jBuyQY5V0rZZmov37Pv : MulticastDelegate
		{
			// Token: 0x060007FE RID: 2046
			public extern jBuyQY5V0rZZmov37Pv(object \u0020, IntPtr \u0020);

			// Token: 0x060007FF RID: 2047
			public extern void Invoke(object o);

			// Token: 0x06000800 RID: 2048
			public extern IAsyncResult BeginInvoke(object o, AsyncCallback callback, object @object);

			// Token: 0x06000801 RID: 2049
			public extern void EndInvoke(IAsyncResult result);

			// Token: 0x06000802 RID: 2050 RVA: 0x00043544 File Offset: 0x00041744
			static jBuyQY5V0rZZmov37Pv()
			{
				vua32v5yjQhjRjK4YIO.aep5UvAyyY();
			}
		}
	}
}
