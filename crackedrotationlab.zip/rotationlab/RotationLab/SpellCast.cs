﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine
{
	// Token: 0x0200003B RID: 59
	public class SpellCast
	{
		// Token: 0x06000565 RID: 1381 RVA: 0x0002D488 File Offset: 0x0002B688
		public SpellCast()
		{
			SpellCast.PsF4NT4nH28AQrbjbl6();
			SpellCast.zb1gJ440q1BofdNDH5N();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_1259d5d4e4144ef5a0c05f808ad73078 == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x06000566 RID: 1382 RVA: 0x0002D4E8 File Offset: 0x0002B6E8
		// Note: this type is marked as 'beforefieldinit'.
		static SpellCast()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x06000567 RID: 1383 RVA: 0x0002D4F8 File Offset: 0x0002B6F8
		internal static void PsF4NT4nH28AQrbjbl6()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x06000568 RID: 1384 RVA: 0x0002D508 File Offset: 0x0002B708
		internal static void zb1gJ440q1BofdNDH5N()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x06000569 RID: 1385 RVA: 0x0002D518 File Offset: 0x0002B718
		internal static bool lgHVv2469ZcZslkY5OA()
		{
			return SpellCast.uPBIui42yroL3ac0e54 == null;
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x0002D52C File Offset: 0x0002B72C
		internal static SpellCast LRLUBW4NFXUnQllNEom()
		{
			return SpellCast.uPBIui42yroL3ac0e54;
		}

		// Token: 0x04000249 RID: 585
		public int SpellId;

		// Token: 0x0400024A RID: 586
		public long Timestamp;

		// Token: 0x0400024B RID: 587
		private static SpellCast uPBIui42yroL3ac0e54;
	}
}
