﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine
{
	// Token: 0x02000019 RID: 25
	public class LogEventArgs : EventArgs
	{
		// Token: 0x1700000F RID: 15
		// (get) Token: 0x060000A8 RID: 168 RVA: 0x00004DF0 File Offset: 0x00002FF0
		// (set) Token: 0x060000A9 RID: 169 RVA: 0x00004E00 File Offset: 0x00003000
		public string Message { get; private set; }

		// Token: 0x060000AA RID: 170 RVA: 0x00004E1C File Offset: 0x0000301C
		public LogEventArgs(string message)
		{
			LogEventArgs.VuYG3oQ7JJZEwGDMnMj();
			LogEventArgs.mxcheIQ29nOmmQsTpqt();
			base..ctor();
			int num = 1;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0a2b7fe605ba404ba745ea0e50bfd1bb != 0)
			{
				num = 1;
			}
			for (;;)
			{
				switch (num)
				{
				default:
					return;
				case 1:
					this.Message = message;
					num = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_1ab95fbf5c0845689e9d97c1311c612e != 0)
					{
						num = 0;
					}
					break;
				}
			}
		}

		// Token: 0x060000AB RID: 171 RVA: 0x00004EA0 File Offset: 0x000030A0
		// Note: this type is marked as 'beforefieldinit'.
		static LogEventArgs()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x060000AC RID: 172 RVA: 0x00004EB0 File Offset: 0x000030B0
		internal static bool FU8gurQksK8b01Kaa4L()
		{
			return LogEventArgs.sRnx9rQe8iaxVgSVCAX == null;
		}

		// Token: 0x060000AD RID: 173 RVA: 0x00004EC4 File Offset: 0x000030C4
		internal static LogEventArgs PdqZZiQrn78SM1bo8vI()
		{
			return LogEventArgs.sRnx9rQe8iaxVgSVCAX;
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00004ED4 File Offset: 0x000030D4
		internal static void VuYG3oQ7JJZEwGDMnMj()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x060000AF RID: 175 RVA: 0x00004EE4 File Offset: 0x000030E4
		internal static void mxcheIQ29nOmmQsTpqt()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x040000F0 RID: 240
		private static LogEventArgs sRnx9rQe8iaxVgSVCAX;
	}
}
