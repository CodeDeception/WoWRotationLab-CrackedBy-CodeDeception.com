﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine
{
	// Token: 0x0200003F RID: 63
	public class RotationSetting
	{
		// Token: 0x0600057E RID: 1406 RVA: 0x0002D768 File Offset: 0x0002B968
		public RotationSetting()
		{
			RotationSetting.xIYRjTOcPihWfxSO2Sv();
			RotationSetting.T4jIVQO5sQ9QfP7T5T5();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_84a9e919b9fe4f039ce072ff9fa8ab32 != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x0002D7C8 File Offset: 0x0002B9C8
		// Note: this type is marked as 'beforefieldinit'.
		static RotationSetting()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x0002D7D8 File Offset: 0x0002B9D8
		internal static void xIYRjTOcPihWfxSO2Sv()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x0002D7E8 File Offset: 0x0002B9E8
		internal static void T4jIVQO5sQ9QfP7T5T5()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x06000582 RID: 1410 RVA: 0x0002D7F8 File Offset: 0x0002B9F8
		internal static bool cOaySxOPOZUSddalLEN()
		{
			return RotationSetting.ypxTSXOWeBSvEPpl83f == null;
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x0002D80C File Offset: 0x0002BA0C
		internal static RotationSetting M08JDhOERinIZXJFJdM()
		{
			return RotationSetting.ypxTSXOWeBSvEPpl83f;
		}

		// Token: 0x04000261 RID: 609
		public string SettingID;

		// Token: 0x04000262 RID: 610
		public string DisplayName;

		// Token: 0x04000263 RID: 611
		public string Description;

		// Token: 0x04000264 RID: 612
		public int ObjectType;

		// Token: 0x04000265 RID: 613
		public string[] PossibleValues;

		// Token: 0x04000266 RID: 614
		public object CurrentValue;

		// Token: 0x04000267 RID: 615
		public object DefaultValue;

		// Token: 0x04000268 RID: 616
		private static RotationSetting ypxTSXOWeBSvEPpl83f;
	}
}
