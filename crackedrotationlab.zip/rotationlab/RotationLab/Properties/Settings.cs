﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine.Properties
{
	// Token: 0x02000053 RID: 83
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")]
	[CompilerGenerated]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x060007E8 RID: 2024 RVA: 0x0003C590 File Offset: 0x0003A790
		public Settings()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
			Settings.NthkgyfzKNWrfPoCNg0();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_82ef02aa8b754adb8434f8a772d183e3 == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060007E9 RID: 2025 RVA: 0x0003C5F0 File Offset: 0x0003A7F0
		// Note: this type is marked as 'beforefieldinit'.
		static Settings()
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					Settings.defaultInstance = (Settings)Settings.opmEUlFWTfYxF9vSfEI(new Settings());
					num2 = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_827c6d37267a42a5864c59085f394f8f != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
					Settings.NthkgyfzKNWrfPoCNg0();
					num2 = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_226f95e821ae480585438175bbddf9be == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					vua32v5yjQhjRjK4YIO.aep5UvAyyY();
					num2 = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_54c2f8a2b1dd479e83e6b60054e43e88 == 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x060007EA RID: 2026 RVA: 0x0003C6A8 File Offset: 0x0003A8A8
		internal static void NthkgyfzKNWrfPoCNg0()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x060007EB RID: 2027 RVA: 0x0003C6B8 File Offset: 0x0003A8B8
		internal static bool b5R5Xwfjm3g4gyy5hWe()
		{
			return Settings.BKhGVgfviqIMFlnNqkp == null;
		}

		// Token: 0x060007EC RID: 2028 RVA: 0x0003C6CC File Offset: 0x0003A8CC
		internal static Settings Bx0ifDfbfycgy99KKDp()
		{
			return Settings.BKhGVgfviqIMFlnNqkp;
		}

		// Token: 0x060007ED RID: 2029 RVA: 0x0003C6DC File Offset: 0x0003A8DC
		internal static object opmEUlFWTfYxF9vSfEI(object A_0)
		{
			return SettingsBase.Synchronized(A_0);
		}

		// Token: 0x04000368 RID: 872
		private static Settings BKhGVgfviqIMFlnNqkp;
	}
}
