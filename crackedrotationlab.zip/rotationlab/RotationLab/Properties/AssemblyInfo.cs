﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.8262.5940")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyProduct("")]
[assembly: ComVisible(false)]
[assembly: SuppressIldasm]
[assembly: Guid("3cf87536-902b-4283-aef2-1a036576ea3e")]
[assembly: AssemblyTitle("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("")]
