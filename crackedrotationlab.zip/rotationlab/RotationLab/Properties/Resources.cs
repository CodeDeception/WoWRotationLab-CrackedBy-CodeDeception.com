﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;
using MyU9Ep58ZH3s5ThDFJQ;
using wKolMkxZecDx58YaRR4;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine.Properties
{
	// Token: 0x02000052 RID: 82
	[CompilerGenerated]
	[DebuggerNonUserCode]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	internal class Resources
	{
		// Token: 0x060007C6 RID: 1990 RVA: 0x0003BFB4 File Offset: 0x0003A1B4
		internal Resources()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
			Resources.myHpoxfMTAP3QIy1TJU();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_408cdf8d10324497825639e7638db7b2 != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060007C7 RID: 1991 RVA: 0x0003C014 File Offset: 0x0003A214
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					Resources.resourceMan = new ResourceManager("RotationLabEngine.Properties.Resources", Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(33554514)).Assembly);
					int num = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_827c6d37267a42a5864c59085f394f8f == 0)
					{
						num = 0;
					}
					switch (num)
					{
					}
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x060007C8 RID: 1992 RVA: 0x0003C090 File Offset: 0x0003A290
		// (set) Token: 0x060007C9 RID: 1993 RVA: 0x0003C0A0 File Offset: 0x0003A2A0
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x060007CA RID: 1994 RVA: 0x0003C0B0 File Offset: 0x0003A2B0
		internal static Bitmap add
		{
			get
			{
				return (Bitmap)Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), Resources.B7NLgGfBePdbt0ky0pW(978854837 ^ 978876733), Resources.resourceCulture);
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060007CB RID: 1995 RVA: 0x0003C0E0 File Offset: 0x0003A2E0
		internal static Bitmap clear
		{
			get
			{
				return (Bitmap)Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), vua32v5yjQhjRjK4YIO.BRA5TcZvlv(2040894867 + -686633457 ^ 1354250544), Resources.resourceCulture);
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060007CC RID: 1996 RVA: 0x0003C114 File Offset: 0x0003A314
		internal static Bitmap click
		{
			get
			{
				return (Bitmap)Resources.nTamJSfGatkQTXOwXDM().GetObject(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1815843576 ^ -1815857240), Resources.resourceCulture);
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060007CD RID: 1997 RVA: 0x0003C144 File Offset: 0x0003A344
		internal static Bitmap document
		{
			get
			{
				return (Bitmap)Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1307524010 ^ -1307533576), Resources.resourceCulture);
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060007CE RID: 1998 RVA: 0x0003C174 File Offset: 0x0003A374
		internal static Bitmap favourite
		{
			get
			{
				return (Bitmap)Resources.nTamJSfGatkQTXOwXDM().GetObject(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1366152946 ^ -1366133812), Resources.resourceCulture);
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060007CF RID: 1999 RVA: 0x0003C1A4 File Offset: 0x0003A3A4
		internal static Bitmap inv_misc_questionmark
		{
			get
			{
				return (Bitmap)Resources.nTamJSfGatkQTXOwXDM().GetObject(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-613886095 << 1 ^ -1227754438), Resources.resourceCulture);
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x060007D0 RID: 2000 RVA: 0x0003C1D8 File Offset: 0x0003A3D8
		internal static Bitmap keyboard__3_
		{
			get
			{
				return (Bitmap)Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), Resources.B7NLgGfBePdbt0ky0pW(587114080 ^ 587136358), Resources.resourceCulture);
			}
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x060007D1 RID: 2001 RVA: 0x0003C208 File Offset: 0x0003A408
		internal static byte[] Magistral_Bold
		{
			get
			{
				return (byte[])Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), Resources.B7NLgGfBePdbt0ky0pW(-613886095 << 1 ^ -1227754048), Resources.resourceCulture);
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x060007D2 RID: 2002 RVA: 0x0003C23C File Offset: 0x0003A43C
		internal static byte[] Magistral_Book
		{
			get
			{
				return (byte[])Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), Resources.B7NLgGfBePdbt0ky0pW(1055311542 ^ 1055301108), Resources.resourceCulture);
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060007D3 RID: 2003 RVA: 0x0003C26C File Offset: 0x0003A46C
		internal static byte[] Magistral_Medium
		{
			get
			{
				return (byte[])Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), Resources.B7NLgGfBePdbt0ky0pW(-1505789866 ^ -1505811660), Resources.resourceCulture);
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x060007D4 RID: 2004 RVA: 0x0003C29C File Offset: 0x0003A49C
		internal static byte[] Marine_Bold
		{
			get
			{
				return (byte[])Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), Resources.B7NLgGfBePdbt0ky0pW(268802365 >> 1 ^ 134387480), Resources.resourceCulture);
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x060007D5 RID: 2005 RVA: 0x0003C2D0 File Offset: 0x0003A4D0
		internal static byte[] Marine_Regular
		{
			get
			{
				return (byte[])Resources.x5MgWvfDmXl7h1YlQ1R(Resources.ResourceManager, Resources.B7NLgGfBePdbt0ky0pW(-582433477 + 1816872807 ^ 1234458370), Resources.resourceCulture);
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x060007D6 RID: 2006 RVA: 0x0003C304 File Offset: 0x0003A504
		internal static Bitmap padlock
		{
			get
			{
				return (Bitmap)Resources.nTamJSfGatkQTXOwXDM().GetObject(Resources.B7NLgGfBePdbt0ky0pW(1657092858 << 1 ^ -980799948), Resources.resourceCulture);
			}
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x060007D7 RID: 2007 RVA: 0x0003C338 File Offset: 0x0003A538
		internal static Bitmap pause
		{
			get
			{
				return (Bitmap)Resources.nTamJSfGatkQTXOwXDM().GetObject(Resources.B7NLgGfBePdbt0ky0pW(-1008853611 >> 6 ^ -15785052), Resources.resourceCulture);
			}
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x060007D8 RID: 2008 RVA: 0x0003C36C File Offset: 0x0003A56C
		internal static Bitmap pencil
		{
			get
			{
				return (Bitmap)Resources.x5MgWvfDmXl7h1YlQ1R(Resources.ResourceManager, Resources.B7NLgGfBePdbt0ky0pW(145144672 << 4 ^ -1972638240), Resources.resourceCulture);
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x060007D9 RID: 2009 RVA: 0x0003C3A0 File Offset: 0x0003A5A0
		internal static Bitmap play
		{
			get
			{
				return (Bitmap)Resources.nTamJSfGatkQTXOwXDM().GetObject(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(951294359 ^ 47512224 ^ 979843271), Resources.resourceCulture);
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x060007DA RID: 2010 RVA: 0x0003C3D4 File Offset: 0x0003A5D4
		internal static Bitmap rpg_game
		{
			get
			{
				return (Bitmap)Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), Resources.B7NLgGfBePdbt0ky0pW(--1722095099 ^ 1722109447), Resources.resourceCulture);
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x060007DB RID: 2011 RVA: 0x0003C404 File Offset: 0x0003A604
		internal static Bitmap send
		{
			get
			{
				return (Bitmap)Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), Resources.B7NLgGfBePdbt0ky0pW(850579974 + 1765464631 ^ -1678905299), Resources.resourceCulture);
			}
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x060007DC RID: 2012 RVA: 0x0003C438 File Offset: 0x0003A638
		internal static Bitmap settings
		{
			get
			{
				return (Bitmap)Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), Resources.B7NLgGfBePdbt0ky0pW(-2083830725 ^ -2083842009), Resources.resourceCulture);
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x060007DD RID: 2013 RVA: 0x0003C468 File Offset: 0x0003A668
		internal static Bitmap sleeping
		{
			get
			{
				return (Bitmap)Resources.nTamJSfGatkQTXOwXDM().GetObject(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-33448599 >> 2 ^ -8373398), Resources.resourceCulture);
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x060007DE RID: 2014 RVA: 0x0003C49C File Offset: 0x0003A69C
		internal static Bitmap trade_engineering
		{
			get
			{
				return (Bitmap)Resources.nTamJSfGatkQTXOwXDM().GetObject(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1745773992 ^ -1745762788), Resources.resourceCulture);
			}
		}

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x060007DF RID: 2015 RVA: 0x0003C4CC File Offset: 0x0003A6CC
		internal static byte[] UbuntuMono_Regular
		{
			get
			{
				return (byte[])Resources.x5MgWvfDmXl7h1YlQ1R(Resources.nTamJSfGatkQTXOwXDM(), Resources.B7NLgGfBePdbt0ky0pW(-256932895 ^ -256909429), Resources.resourceCulture);
			}
		}

		// Token: 0x060007E0 RID: 2016 RVA: 0x0003C4FC File Offset: 0x0003A6FC
		// Note: this type is marked as 'beforefieldinit'.
		static Resources()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x060007E1 RID: 2017 RVA: 0x0003C50C File Offset: 0x0003A70C
		internal static void myHpoxfMTAP3QIy1TJU()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x060007E2 RID: 2018 RVA: 0x0003C51C File Offset: 0x0003A71C
		internal static bool JIHGNcfgL95wLGqiFtp()
		{
			return Resources.domfDKfsdZXjOwTkmbw == null;
		}

		// Token: 0x060007E3 RID: 2019 RVA: 0x0003C530 File Offset: 0x0003A730
		internal static Resources sI6PjSfXwvqwWNWMZbm()
		{
			return Resources.domfDKfsdZXjOwTkmbw;
		}

		// Token: 0x060007E4 RID: 2020 RVA: 0x0003C540 File Offset: 0x0003A740
		internal static object nTamJSfGatkQTXOwXDM()
		{
			return Resources.ResourceManager;
		}

		// Token: 0x060007E5 RID: 2021 RVA: 0x0003C550 File Offset: 0x0003A750
		internal static object B7NLgGfBePdbt0ky0pW(int \u0020)
		{
			return vua32v5yjQhjRjK4YIO.BRA5TcZvlv(\u0020);
		}

		// Token: 0x060007E6 RID: 2022 RVA: 0x0003C564 File Offset: 0x0003A764
		internal static object x5MgWvfDmXl7h1YlQ1R(object A_0, object A_1, object A_2)
		{
			return A_0.GetObject(A_1, A_2);
		}

		// Token: 0x04000364 RID: 868
		private static ResourceManager resourceMan;

		// Token: 0x04000365 RID: 869
		private static CultureInfo resourceCulture;

		// Token: 0x04000366 RID: 870
		private static Resources domfDKfsdZXjOwTkmbw;
	}
}
