﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine
{
	// Token: 0x0200001B RID: 27
	public class DoItemCastArgs : EventArgs
	{
		// Token: 0x17000011 RID: 17
		// (get) Token: 0x060000B7 RID: 183 RVA: 0x00004FE4 File Offset: 0x000031E4
		// (set) Token: 0x060000B8 RID: 184 RVA: 0x00004FF4 File Offset: 0x000031F4
		public int ItemId { get; private set; }

		// Token: 0x060000B9 RID: 185 RVA: 0x00005010 File Offset: 0x00003210
		public DoItemCastArgs(int itemId)
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
			DoItemCastArgs.kVm1wBQtJKtHi2TIERG();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_24c6414a8a5b4f2680c42f1a5855f977 != 0)
			{
				num = 1;
			}
			for (;;)
			{
				switch (num)
				{
				default:
					return;
				case 1:
					this.ItemId = itemId;
					num = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0e5e3d7d8cdf4d2a9040ab7043b65fe6 != 0)
					{
						num = 0;
					}
					break;
				}
			}
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00005094 File Offset: 0x00003294
		// Note: this type is marked as 'beforefieldinit'.
		static DoItemCastArgs()
		{
			DoItemCastArgs.sbHh2aQYYZTSFXyJWcf();
		}

		// Token: 0x060000BB RID: 187 RVA: 0x000050A4 File Offset: 0x000032A4
		internal static bool IbglFDQmqVYjCUOEGju()
		{
			return DoItemCastArgs.jAH7lPQJt8T7GWSOELN == null;
		}

		// Token: 0x060000BC RID: 188 RVA: 0x000050B8 File Offset: 0x000032B8
		internal static DoItemCastArgs OJACG8QHZ0WqgIIlQ74()
		{
			return DoItemCastArgs.jAH7lPQJt8T7GWSOELN;
		}

		// Token: 0x060000BD RID: 189 RVA: 0x000050C8 File Offset: 0x000032C8
		internal static void kVm1wBQtJKtHi2TIERG()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x060000BE RID: 190 RVA: 0x000050D8 File Offset: 0x000032D8
		internal static void sbHh2aQYYZTSFXyJWcf()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x040000F4 RID: 244
		private static DoItemCastArgs jAH7lPQJt8T7GWSOELN;
	}
}
