﻿using System;
using System.Collections.Generic;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace pv3wLjFLovBNS8B3YH
{
	// Token: 0x02000012 RID: 18
	internal class xcBF6XfpTXPOK6FjeY
	{
		// Token: 0x06000082 RID: 130 RVA: 0x00004998 File Offset: 0x00002B98
		public xcBF6XfpTXPOK6FjeY()
		{
			xcBF6XfpTXPOK6FjeY.AxwkrFQur7KwbMbc6CN();
			xcBF6XfpTXPOK6FjeY.MeL6IsQVWgCdrWcEfdS();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_a8b0fe86ca414d59a00505e4688a2028 != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x06000083 RID: 131 RVA: 0x000049F8 File Offset: 0x00002BF8
		// Note: this type is marked as 'beforefieldinit'.
		static xcBF6XfpTXPOK6FjeY()
		{
			xcBF6XfpTXPOK6FjeY.qwGdOEQyF1DJKNTN3x1();
		}

		// Token: 0x06000084 RID: 132 RVA: 0x00004A08 File Offset: 0x00002C08
		internal static void AxwkrFQur7KwbMbc6CN()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00004A18 File Offset: 0x00002C18
		internal static void MeL6IsQVWgCdrWcEfdS()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x06000086 RID: 134 RVA: 0x00004A28 File Offset: 0x00002C28
		internal static bool TaSgHyQ5Aq7162s3HYG()
		{
			return xcBF6XfpTXPOK6FjeY.aDwXcUQcspIWsWR99NH == null;
		}

		// Token: 0x06000087 RID: 135 RVA: 0x00004A3C File Offset: 0x00002C3C
		internal static xcBF6XfpTXPOK6FjeY ytNDvvQxYA2qf27tb4h()
		{
			return xcBF6XfpTXPOK6FjeY.aDwXcUQcspIWsWR99NH;
		}

		// Token: 0x06000088 RID: 136 RVA: 0x00004A4C File Offset: 0x00002C4C
		internal static void qwGdOEQyF1DJKNTN3x1()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x040000C7 RID: 199
		public string AccessToken;

		// Token: 0x040000C8 RID: 200
		public int[] SpellList;

		// Token: 0x040000C9 RID: 201
		public int[] BuffList;

		// Token: 0x040000CA RID: 202
		public int[] DebuffList;

		// Token: 0x040000CB RID: 203
		public int[] ItemList;

		// Token: 0x040000CC RID: 204
		public string[] UnitList;

		// Token: 0x040000CD RID: 205
		public string[] ToggleList;

		// Token: 0x040000CE RID: 206
		public int RefreshRate;

		// Token: 0x040000CF RID: 207
		public bool Classic;

		// Token: 0x040000D0 RID: 208
		public bool HealingRotation;

		// Token: 0x040000D1 RID: 209
		public string RotationName;

		// Token: 0x040000D2 RID: 210
		public string AddonName;

		// Token: 0x040000D3 RID: 211
		public int PixelLocation;

		// Token: 0x040000D4 RID: 212
		public int ClassId;

		// Token: 0x040000D5 RID: 213
		public string EngineVersion;

		// Token: 0x040000D6 RID: 214
		public List<string[]> AutoBind;

		// Token: 0x040000D7 RID: 215
		private static xcBF6XfpTXPOK6FjeY aDwXcUQcspIWsWR99NH;
	}
}
