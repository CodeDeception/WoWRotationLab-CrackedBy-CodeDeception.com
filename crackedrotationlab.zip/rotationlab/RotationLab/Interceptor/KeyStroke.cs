﻿using System;

namespace Interceptor
{
	// Token: 0x0200000A RID: 10
	public struct KeyStroke
	{
		// Token: 0x0400004D RID: 77
		public ushort Code;

		// Token: 0x0400004E RID: 78
		public KeyState State;

		// Token: 0x0400004F RID: 79
		public uint Information;
	}
}
