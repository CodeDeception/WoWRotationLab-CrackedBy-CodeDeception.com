﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace Interceptor
{
	// Token: 0x0200000E RID: 14
	public class MousePressedEventArgs : EventArgs
	{
		// Token: 0x1700000A RID: 10
		// (get) Token: 0x0600004F RID: 79 RVA: 0x00003014 File Offset: 0x00001214
		// (set) Token: 0x06000050 RID: 80 RVA: 0x00003024 File Offset: 0x00001224
		public MouseState State { get; set; }

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000051 RID: 81 RVA: 0x0000303C File Offset: 0x0000123C
		// (set) Token: 0x06000052 RID: 82 RVA: 0x0000304C File Offset: 0x0000124C
		public bool Handled { get; set; }

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000053 RID: 83 RVA: 0x00003064 File Offset: 0x00001264
		// (set) Token: 0x06000054 RID: 84 RVA: 0x00003074 File Offset: 0x00001274
		public int X { get; set; }

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000055 RID: 85 RVA: 0x0000308C File Offset: 0x0000128C
		// (set) Token: 0x06000056 RID: 86 RVA: 0x0000309C File Offset: 0x0000129C
		public int Y { get; set; }

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000057 RID: 87 RVA: 0x000030B8 File Offset: 0x000012B8
		// (set) Token: 0x06000058 RID: 88 RVA: 0x000030C8 File Offset: 0x000012C8
		public short Rolling { get; set; }

		// Token: 0x06000059 RID: 89 RVA: 0x000030E4 File Offset: 0x000012E4
		public MousePressedEventArgs()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0a2b7fe605ba404ba745ea0e50bfd1bb == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600005A RID: 90 RVA: 0x00003144 File Offset: 0x00001344
		// Note: this type is marked as 'beforefieldinit'.
		static MousePressedEventArgs()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x0600005B RID: 91 RVA: 0x00003154 File Offset: 0x00001354
		internal static bool GUtjQg3LFlaglq3Mbf6()
		{
			return MousePressedEventArgs.uA64iL3RdIONrHQsKYw == null;
		}

		// Token: 0x0600005C RID: 92 RVA: 0x00003168 File Offset: 0x00001368
		internal static MousePressedEventArgs N8sAkm3lbsWZWQPeN47()
		{
			return MousePressedEventArgs.uA64iL3RdIONrHQsKYw;
		}

		// Token: 0x0400005B RID: 91
		internal static MousePressedEventArgs uA64iL3RdIONrHQsKYw;
	}
}
