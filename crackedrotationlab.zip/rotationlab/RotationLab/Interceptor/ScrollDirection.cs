﻿using System;

namespace Interceptor
{
	// Token: 0x02000010 RID: 16
	public enum ScrollDirection
	{
		// Token: 0x040000C2 RID: 194
		Down,
		// Token: 0x040000C3 RID: 195
		Up
	}
}
