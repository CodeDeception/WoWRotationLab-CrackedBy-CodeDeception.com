﻿using System;

namespace Interceptor
{
	// Token: 0x02000009 RID: 9
	public struct MouseStroke
	{
		// Token: 0x04000047 RID: 71
		public MouseState State;

		// Token: 0x04000048 RID: 72
		public MouseFlags Flags;

		// Token: 0x04000049 RID: 73
		public short Rolling;

		// Token: 0x0400004A RID: 74
		public int X;

		// Token: 0x0400004B RID: 75
		public int Y;

		// Token: 0x0400004C RID: 76
		public ushort Information;
	}
}
