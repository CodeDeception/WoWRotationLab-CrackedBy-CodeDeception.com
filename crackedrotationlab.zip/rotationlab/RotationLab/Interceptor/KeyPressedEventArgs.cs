﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace Interceptor
{
	// Token: 0x0200000D RID: 13
	public class KeyPressedEventArgs : EventArgs
	{
		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000043 RID: 67 RVA: 0x00002EE8 File Offset: 0x000010E8
		// (set) Token: 0x06000044 RID: 68 RVA: 0x00002EF8 File Offset: 0x000010F8
		public ushort Key { get; set; }

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000045 RID: 69 RVA: 0x00002F10 File Offset: 0x00001110
		// (set) Token: 0x06000046 RID: 70 RVA: 0x00002F20 File Offset: 0x00001120
		public KeyState State { get; set; }

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000047 RID: 71 RVA: 0x00002F38 File Offset: 0x00001138
		// (set) Token: 0x06000048 RID: 72 RVA: 0x00002F48 File Offset: 0x00001148
		public bool Handled { get; set; }

		// Token: 0x06000049 RID: 73 RVA: 0x00002F60 File Offset: 0x00001160
		public KeyPressedEventArgs()
		{
			KeyPressedEventArgs.ipv5Ps3FFPstIbowxHq();
			KeyPressedEventArgs.P4Egqu3T9RKfIQbmUG8();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_d7db82c175de47d2b5f36bc0c7f71006 == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600004A RID: 74 RVA: 0x00002FC0 File Offset: 0x000011C0
		// Note: this type is marked as 'beforefieldinit'.
		static KeyPressedEventArgs()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x0600004B RID: 75 RVA: 0x00002FD0 File Offset: 0x000011D0
		internal static bool SEqMgI3OftyheKxWunm()
		{
			return KeyPressedEventArgs.draAeg34M20oBLbqIAN == null;
		}

		// Token: 0x0600004C RID: 76 RVA: 0x00002FE4 File Offset: 0x000011E4
		internal static KeyPressedEventArgs TFapId3fSLeNPtBwnUN()
		{
			return KeyPressedEventArgs.draAeg34M20oBLbqIAN;
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00002FF4 File Offset: 0x000011F4
		internal static void ipv5Ps3FFPstIbowxHq()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x0600004E RID: 78 RVA: 0x00003004 File Offset: 0x00001204
		internal static void P4Egqu3T9RKfIQbmUG8()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x04000055 RID: 85
		internal static KeyPressedEventArgs draAeg34M20oBLbqIAN;
	}
}
