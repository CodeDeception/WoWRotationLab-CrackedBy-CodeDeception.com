﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace Sk5EtwKTjRJr4xlhBC
{
	// Token: 0x02000015 RID: 21
	internal class Rxlep3aFWM75xoYk07
	{
		// Token: 0x06000095 RID: 149 RVA: 0x00004BC4 File Offset: 0x00002DC4
		public Rxlep3aFWM75xoYk07()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
			Rxlep3aFWM75xoYk07.m1AKFLQiScjSY08Lvf5();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_30d33a1ced8343dfb34aa8f1408e62af == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x06000096 RID: 150 RVA: 0x00004C24 File Offset: 0x00002E24
		// Note: this type is marked as 'beforefieldinit'.
		static Rxlep3aFWM75xoYk07()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x06000097 RID: 151 RVA: 0x00004C34 File Offset: 0x00002E34
		internal static void m1AKFLQiScjSY08Lvf5()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00004C44 File Offset: 0x00002E44
		internal static bool mjLolVQSs25RGh9c7ZZ()
		{
			return Rxlep3aFWM75xoYk07.C7QUxxQhU4gTIYi9R7n == null;
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00004C58 File Offset: 0x00002E58
		internal static Rxlep3aFWM75xoYk07 JdN0MCQIAZRhGWrE0uZ()
		{
			return Rxlep3aFWM75xoYk07.C7QUxxQhU4gTIYi9R7n;
		}

		// Token: 0x040000E3 RID: 227
		public string Title;

		// Token: 0x040000E4 RID: 228
		public string Code;

		// Token: 0x040000E5 RID: 229
		public string Error;

		// Token: 0x040000E6 RID: 230
		internal static Rxlep3aFWM75xoYk07 C7QUxxQhU4gTIYi9R7n;
	}
}
