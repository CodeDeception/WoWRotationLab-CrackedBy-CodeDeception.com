﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using wKolMkxZecDx58YaRR4;
using XR7RtrxI8Vm7Dgx9BKr;
using z6sH8Cxtx1xCxjgcS7P;

namespace MyU9Ep58ZH3s5ThDFJQ
{
	// Token: 0x02000059 RID: 89
	internal class vua32v5yjQhjRjK4YIO
	{
		// Token: 0x06000803 RID: 2051 RVA: 0x00043554 File Offset: 0x00041754
		static vua32v5yjQhjRjK4YIO()
		{
			vua32v5yjQhjRjK4YIO.U6XE6mvyw = new uint[]
			{
				3614090360U,
				3905402710U,
				606105819U,
				3250441966U,
				4118548399U,
				1200080426U,
				2821735955U,
				4249261313U,
				1770035416U,
				2336552879U,
				4294925233U,
				2304563134U,
				1804603682U,
				4254626195U,
				2792965006U,
				1236535329U,
				4129170786U,
				3225465664U,
				643717713U,
				3921069994U,
				3593408605U,
				38016083U,
				3634488961U,
				3889429448U,
				568446438U,
				3275163606U,
				4107603335U,
				1163531501U,
				2850285829U,
				4243563512U,
				1735328473U,
				2368359562U,
				4294588738U,
				2272392833U,
				1839030562U,
				4259657740U,
				2763975236U,
				1272893353U,
				4139469664U,
				3200236656U,
				681279174U,
				3936430074U,
				3572445317U,
				76029189U,
				3654602809U,
				3873151461U,
				530742520U,
				3299628645U,
				4096336452U,
				1126891415U,
				2878612391U,
				4237533241U,
				1700485571U,
				2399980690U,
				4293915773U,
				2240044497U,
				1873313359U,
				4264355552U,
				2734768916U,
				1309151649U,
				4149444226U,
				3174756917U,
				718787259U,
				3951481745U
			};
			vua32v5yjQhjRjK4YIO.GJ23VPZUC = false;
			vua32v5yjQhjRjK4YIO.VIl2UgjvI = false;
			vua32v5yjQhjRjK4YIO.EXHzxLTGx = null;
			vua32v5yjQhjRjK4YIO.pAL10SKCoC = null;
			vua32v5yjQhjRjK4YIO.bYc11bZ2yR = new object();
			vua32v5yjQhjRjK4YIO.Pgs1HOBEQA = 0;
			vua32v5yjQhjRjK4YIO.t8Q1fis8nb = new object();
			vua32v5yjQhjRjK4YIO.RaA1I3e0cE = null;
			vua32v5yjQhjRjK4YIO.BV01muBIf0 = null;
			vua32v5yjQhjRjK4YIO.lRG1gLlTer = new byte[0];
			vua32v5yjQhjRjK4YIO.QRR1YKfBNJ = new byte[0];
			vua32v5yjQhjRjK4YIO.lQu18GAsIh = IntPtr.Zero;
			vua32v5yjQhjRjK4YIO.ueQ1CBZqwr = IntPtr.Zero;
			vua32v5yjQhjRjK4YIO.BiA1jH0AoM = new string[0];
			vua32v5yjQhjRjK4YIO.Syr1aJSCyW = new int[0];
			vua32v5yjQhjRjK4YIO.fKU1wiJQGY = 1;
			vua32v5yjQhjRjK4YIO.mhL1hZ6InY = false;
			vua32v5yjQhjRjK4YIO.uFW1iZApx1 = new SortedList();
			vua32v5yjQhjRjK4YIO.VyN15LqlEh = 0;
			vua32v5yjQhjRjK4YIO.X4h1A928yN = 0L;
			vua32v5yjQhjRjK4YIO.XBV1llcJHV = null;
			vua32v5yjQhjRjK4YIO.iBN1U8RgNG = null;
			vua32v5yjQhjRjK4YIO.CoD1QZV1a1 = 0L;
			vua32v5yjQhjRjK4YIO.SDV1d6LAgj = 0;
			vua32v5yjQhjRjK4YIO.QxN19ECe8h = false;
			vua32v5yjQhjRjK4YIO.atZ1SSejVu = false;
			vua32v5yjQhjRjK4YIO.RYG1kecuXB = 0;
			vua32v5yjQhjRjK4YIO.WB11tRIZxP = IntPtr.Zero;
			vua32v5yjQhjRjK4YIO.firstrundone = false;
			vua32v5yjQhjRjK4YIO.BSI1ZLPHr8 = new Hashtable();
			vua32v5yjQhjRjK4YIO.CHf1uRY5iT = null;
			vua32v5yjQhjRjK4YIO.XJ517srtuJ = null;
			vua32v5yjQhjRjK4YIO.PrY1OKksdd = null;
			vua32v5yjQhjRjK4YIO.HqA1otFDcJ = null;
			vua32v5yjQhjRjK4YIO.J8t1vEcUBI = null;
			vua32v5yjQhjRjK4YIO.D081RjBZ7X = null;
			vua32v5yjQhjRjK4YIO.hyO1NyyabH = IntPtr.Zero;
			vua32v5yjQhjRjK4YIO.WDJ1r9tJFl = Encoding.Unicode.GetString(new byte[]
			{
				134,
				123,
				241,
				8,
				24,
				98,
				77,
				199
			});
			try
			{
				RSACryptoServiceProvider.UseMachineKeyStore = true;
			}
			catch
			{
			}
		}

		// Token: 0x06000804 RID: 2052 RVA: 0x000436EC File Offset: 0x000418EC
		private void tXp03IRwTr()
		{
		}

		// Token: 0x06000805 RID: 2053 RVA: 0x000436F0 File Offset: 0x000418F0
		internal static byte[] Qrt5qTrUB7(byte[] \u0020)
		{
			uint[] array = new uint[16];
			uint num = (uint)((448 - \u0020.Length * 8 % 512 + 512) % 512);
			if (num == 0U)
			{
				num = 512U;
			}
			uint num2 = (uint)((long)\u0020.Length + (long)((ulong)(num / 8U)) + 8L);
			ulong num3 = (ulong)((long)\u0020.Length * 8L);
			byte[] array2 = new byte[num2];
			for (int i = 0; i < \u0020.Length; i++)
			{
				array2[i] = \u0020[i];
			}
			byte[] array3 = array2;
			int num4 = \u0020.Length;
			array3[num4] |= 128;
			for (int j = 8; j > 0; j--)
			{
				array2[(int)(checked((IntPtr)(unchecked((ulong)num2 - (ulong)((long)j)))))] = (byte)(num3 >> (8 - j) * 8 & 255UL);
			}
			uint num5 = (uint)(array2.Length * 8 / 32);
			uint num6 = 1732584193U;
			uint num7 = 4023233417U;
			uint num8 = 2562383102U;
			uint num9 = 271733878U;
			for (uint num10 = 0U; num10 < num5 / 16U; num10 += 1U)
			{
				uint num11 = num10 << 6;
				for (uint num12 = 0U; num12 < 61U; num12 += 4U)
				{
					array[(int)(num12 >> 2)] = (uint)((int)array2[(int)(num11 + (num12 + 3U))] << 24 | (int)array2[(int)(num11 + (num12 + 2U))] << 16 | (int)array2[(int)(num11 + (num12 + 1U))] << 8 | (int)array2[(int)(num11 + num12)]);
				}
				uint num13 = num6;
				uint num14 = num7;
				uint num15 = num8;
				uint num16 = num9;
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num6, num7, num8, num9, 0U, 7, 1U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num9, num6, num7, num8, 1U, 12, 2U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num8, num9, num6, num7, 2U, 17, 3U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num7, num8, num9, num6, 3U, 22, 4U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num6, num7, num8, num9, 4U, 7, 5U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num9, num6, num7, num8, 5U, 12, 6U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num8, num9, num6, num7, 6U, 17, 7U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num7, num8, num9, num6, 7U, 22, 8U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num6, num7, num8, num9, 8U, 7, 9U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num9, num6, num7, num8, 9U, 12, 10U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num8, num9, num6, num7, 10U, 17, 11U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num7, num8, num9, num6, 11U, 22, 12U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num6, num7, num8, num9, 12U, 7, 13U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num9, num6, num7, num8, 13U, 12, 14U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num8, num9, num6, num7, 14U, 17, 15U, array);
				vua32v5yjQhjRjK4YIO.cc55dQMteJ(ref num7, num8, num9, num6, 15U, 22, 16U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num6, num7, num8, num9, 1U, 5, 17U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num9, num6, num7, num8, 6U, 9, 18U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num8, num9, num6, num7, 11U, 14, 19U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num7, num8, num9, num6, 0U, 20, 20U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num6, num7, num8, num9, 5U, 5, 21U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num9, num6, num7, num8, 10U, 9, 22U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num8, num9, num6, num7, 15U, 14, 23U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num7, num8, num9, num6, 4U, 20, 24U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num6, num7, num8, num9, 9U, 5, 25U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num9, num6, num7, num8, 14U, 9, 26U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num8, num9, num6, num7, 3U, 14, 27U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num7, num8, num9, num6, 8U, 20, 28U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num6, num7, num8, num9, 13U, 5, 29U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num9, num6, num7, num8, 2U, 9, 30U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num8, num9, num6, num7, 7U, 14, 31U, array);
				vua32v5yjQhjRjK4YIO.TQc5orURRI(ref num7, num8, num9, num6, 12U, 20, 32U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num6, num7, num8, num9, 5U, 4, 33U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num9, num6, num7, num8, 8U, 11, 34U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num8, num9, num6, num7, 11U, 16, 35U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num7, num8, num9, num6, 14U, 23, 36U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num6, num7, num8, num9, 1U, 4, 37U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num9, num6, num7, num8, 4U, 11, 38U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num8, num9, num6, num7, 7U, 16, 39U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num7, num8, num9, num6, 10U, 23, 40U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num6, num7, num8, num9, 13U, 4, 41U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num9, num6, num7, num8, 0U, 11, 42U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num8, num9, num6, num7, 3U, 16, 43U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num7, num8, num9, num6, 6U, 23, 44U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num6, num7, num8, num9, 9U, 4, 45U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num9, num6, num7, num8, 12U, 11, 46U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num8, num9, num6, num7, 15U, 16, 47U, array);
				vua32v5yjQhjRjK4YIO.YgQ53b16aw(ref num7, num8, num9, num6, 2U, 23, 48U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num6, num7, num8, num9, 0U, 6, 49U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num9, num6, num7, num8, 7U, 10, 50U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num8, num9, num6, num7, 14U, 15, 51U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num7, num8, num9, num6, 5U, 21, 52U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num6, num7, num8, num9, 12U, 6, 53U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num9, num6, num7, num8, 3U, 10, 54U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num8, num9, num6, num7, 10U, 15, 55U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num7, num8, num9, num6, 1U, 21, 56U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num6, num7, num8, num9, 8U, 6, 57U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num9, num6, num7, num8, 15U, 10, 58U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num8, num9, num6, num7, 6U, 15, 59U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num7, num8, num9, num6, 13U, 21, 60U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num6, num7, num8, num9, 4U, 6, 61U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num9, num6, num7, num8, 11U, 10, 62U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num8, num9, num6, num7, 2U, 15, 63U, array);
				vua32v5yjQhjRjK4YIO.I3t5Q8RyWF(ref num7, num8, num9, num6, 9U, 21, 64U, array);
				num6 += num13;
				num7 += num14;
				num8 += num15;
				num9 += num16;
			}
			byte[] array4 = new byte[16];
			Array.Copy(BitConverter.GetBytes(num6), 0, array4, 0, 4);
			Array.Copy(BitConverter.GetBytes(num7), 0, array4, 4, 4);
			Array.Copy(BitConverter.GetBytes(num8), 0, array4, 8, 4);
			Array.Copy(BitConverter.GetBytes(num9), 0, array4, 12, 4);
			return array4;
		}

		// Token: 0x06000806 RID: 2054 RVA: 0x00043D54 File Offset: 0x00041F54
		private static void cc55dQMteJ(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, uint[] \u0020)
		{
			\u0020 += vua32v5yjQhjRjK4YIO.IOg5C1KYgR(\u0020 + ((\u0020 & \u0020) | (~\u0020 & \u0020)) + \u0020[(int)\u0020] + vua32v5yjQhjRjK4YIO.U6XE6mvyw[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x06000807 RID: 2055 RVA: 0x00043D80 File Offset: 0x00041F80
		private static void TQc5orURRI(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, uint[] \u0020)
		{
			\u0020 += vua32v5yjQhjRjK4YIO.IOg5C1KYgR(\u0020 + ((\u0020 & \u0020) | (\u0020 & ~\u0020)) + \u0020[(int)\u0020] + vua32v5yjQhjRjK4YIO.U6XE6mvyw[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x06000808 RID: 2056 RVA: 0x00043DAC File Offset: 0x00041FAC
		private static void YgQ53b16aw(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, uint[] \u0020)
		{
			\u0020 += vua32v5yjQhjRjK4YIO.IOg5C1KYgR(\u0020 + (\u0020 ^ \u0020 ^ \u0020) + \u0020[(int)\u0020] + vua32v5yjQhjRjK4YIO.U6XE6mvyw[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x06000809 RID: 2057 RVA: 0x00043DD4 File Offset: 0x00041FD4
		private static void I3t5Q8RyWF(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, uint[] \u0020)
		{
			\u0020 += vua32v5yjQhjRjK4YIO.IOg5C1KYgR(\u0020 + (\u0020 ^ (\u0020 | ~\u0020)) + \u0020[(int)\u0020] + vua32v5yjQhjRjK4YIO.U6XE6mvyw[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x0600080A RID: 2058 RVA: 0x00043DFC File Offset: 0x00041FFC
		private static uint IOg5C1KYgR(uint \u0020, ushort \u0020)
		{
			return \u0020 >> (int)(32 - \u0020) | \u0020 << (int)\u0020;
		}

		// Token: 0x0600080B RID: 2059 RVA: 0x00043E10 File Offset: 0x00042010
		internal static bool j7l59fYfBn()
		{
			if (!vua32v5yjQhjRjK4YIO.GJ23VPZUC)
			{
				vua32v5yjQhjRjK4YIO.goO5hv75Zu();
				vua32v5yjQhjRjK4YIO.GJ23VPZUC = true;
			}
			return vua32v5yjQhjRjK4YIO.VIl2UgjvI;
		}

		// Token: 0x0600080C RID: 2060 RVA: 0x00043E2C File Offset: 0x0004202C
		internal vua32v5yjQhjRjK4YIO()
		{
		}

		// Token: 0x0600080D RID: 2061 RVA: 0x00043E34 File Offset: 0x00042034
		private void BmN5w2YUcf(byte[] \u0020, byte[] \u0020, byte[] \u0020)
		{
			int num = \u0020.Length % 4;
			int num2 = \u0020.Length / 4;
			byte[] array = new byte[\u0020.Length];
			int num3 = \u0020.Length / 4;
			uint num4 = 0U;
			if (num > 0)
			{
				num2++;
			}
			for (int i = 0; i < num2; i++)
			{
				int num5 = i % num3;
				int num6 = i * 4;
				uint num7 = (uint)(num5 * 4);
				uint num8 = (uint)((int)\u0020[(int)(num7 + 3U)] << 24 | (int)\u0020[(int)(num7 + 2U)] << 16 | (int)\u0020[(int)(num7 + 1U)] << 8 | (int)\u0020[(int)num7]);
				uint num9 = 255U;
				int num10 = 0;
				uint num11;
				if (i == num2 - 1 && num > 0)
				{
					num11 = 0U;
					num4 += num8;
					for (int j = 0; j < num; j++)
					{
						if (j > 0)
						{
							num11 <<= 8;
						}
						num11 |= (uint)\u0020[\u0020.Length - (1 + j)];
					}
				}
				else
				{
					num4 += num8;
					num7 = (uint)num6;
					num11 = (uint)((int)\u0020[(int)(num7 + 3U)] << 24 | (int)\u0020[(int)(num7 + 2U)] << 16 | (int)\u0020[(int)(num7 + 1U)] << 8 | (int)\u0020[(int)num7]);
				}
				uint num12 = num4;
				uint num13 = 1746411212U;
				uint num14 = 2041473469U;
				uint num15 = 779880615U;
				uint num16 = 1852038394U;
				uint num17 = num12;
				uint num18 = 568982301U;
				num16 = 3196U * (num16 & 1048575U) - (num16 >> 20);
				num15 = 420U * (num15 & 1048575U) + (num15 >> 20);
				num13 = 5919U * num13 - num14;
				uint num19 = (num14 >> 11 | num14 << 21) ^ num16;
				uint num20 = num19 & 1431655765U;
				num19 &= 2863311530U;
				num14 = (num19 >> 1 | num20 << 1);
				ulong num21 = 18446744073038777088UL;
				num21 |= 1UL;
				num13 = (uint)((ulong)(num13 * num13) % num21);
				uint num22 = num16 & 252645135U;
				uint num23 = num16 & 4042322160U;
				num22 = ((num22 >> 4 | num23 << 4) ^ num15);
				num16 = (num16 << 4 | num16 >> 28);
				num18 -= num15;
				num17 ^= num17 << 13;
				num17 += num13;
				num17 ^= num17 >> 17;
				num17 += num16;
				num17 ^= num17 << 15;
				num17 += num18;
				num17 = ((num14 << 6) + num13 ^ num16) + num17;
				num4 = num12 + (uint)num17;
				if (i == num2 - 1 && num > 0)
				{
					uint num24 = num4 ^ num11;
					for (int k = 0; k < num; k++)
					{
						if (k > 0)
						{
							num9 <<= 8;
							num10 += 8;
						}
						array[num6 + k] = (byte)((num24 & num9) >> num10);
					}
				}
				else
				{
					uint num25 = num4 ^ num11;
					array[num6] = (byte)(num25 & 255U);
					array[num6 + 1] = (byte)((num25 & 65280U) >> 8);
					array[num6 + 2] = (byte)((num25 & 16711680U) >> 16);
					array[num6 + 3] = (byte)((num25 & 4278190080U) >> 24);
				}
			}
			vua32v5yjQhjRjK4YIO.lRG1gLlTer = array;
		}

		// Token: 0x0600080E RID: 2062 RVA: 0x000441B0 File Offset: 0x000423B0
		internal static SymmetricAlgorithm LXW5ASdnvZ()
		{
			SymmetricAlgorithm result = null;
			if (vua32v5yjQhjRjK4YIO.j7l59fYfBn())
			{
				result = new AesCryptoServiceProvider();
			}
			else
			{
				try
				{
					result = new RijndaelManaged();
				}
				catch
				{
					result = (SymmetricAlgorithm)Activator.CreateInstance("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089", "System.Security.Cryptography.AesCryptoServiceProvider").Unwrap();
				}
			}
			return result;
		}

		// Token: 0x0600080F RID: 2063 RVA: 0x00044214 File Offset: 0x00042414
		internal static void goO5hv75Zu()
		{
			try
			{
				vua32v5yjQhjRjK4YIO.VIl2UgjvI = CryptoConfig.AllowOnlyFipsAlgorithms;
			}
			catch
			{
			}
		}

		// Token: 0x06000810 RID: 2064 RVA: 0x00044248 File Offset: 0x00042448
		internal static byte[] LxG5S2Hn4o(byte[] \u0020)
		{
			if (!vua32v5yjQhjRjK4YIO.j7l59fYfBn())
			{
				return new MD5CryptoServiceProvider().ComputeHash(\u0020);
			}
			return vua32v5yjQhjRjK4YIO.Qrt5qTrUB7(\u0020);
		}

		// Token: 0x06000811 RID: 2065 RVA: 0x00044268 File Offset: 0x00042468
		internal static void pKF5IPBFtn(HashAlgorithm \u0020, Stream \u0020, uint \u0020, byte[] \u0020)
		{
			while (\u0020 > 0U)
			{
				int num = (\u0020 > (uint)\u0020.Length) ? \u0020.Length : ((int)\u0020);
				\u0020.Read(\u0020, 0, num);
				vua32v5yjQhjRjK4YIO.TnZ5iY18oG(\u0020, \u0020, 0, num);
				\u0020 -= (uint)num;
			}
		}

		// Token: 0x06000812 RID: 2066 RVA: 0x000442AC File Offset: 0x000424AC
		internal static void TnZ5iY18oG(HashAlgorithm \u0020, byte[] \u0020, int \u0020, int \u0020)
		{
			\u0020.TransformBlock(\u0020, \u0020, \u0020, \u0020, \u0020);
		}

		// Token: 0x06000813 RID: 2067 RVA: 0x000442BC File Offset: 0x000424BC
		internal static uint qC25ZNKulF(uint \u0020, int \u0020, long \u0020, BinaryReader \u0020)
		{
			for (int i = 0; i < \u0020; i++)
			{
				\u0020.BaseStream.Position = \u0020 + (long)(i * 40 + 8);
				uint num = \u0020.ReadUInt32();
				uint num2 = \u0020.ReadUInt32();
				\u0020.ReadUInt32();
				uint num3 = \u0020.ReadUInt32();
				if (num2 <= \u0020 && \u0020 < num2 + num)
				{
					return num3 + \u0020 - num2;
				}
			}
			return 0U;
		}

		// Token: 0x06000814 RID: 2068 RVA: 0x00044324 File Offset: 0x00042524
		internal static void aep5UvAyyY()
		{
			int num = 15;
			int num2 = num;
			for (;;)
			{
				BinaryReader binaryReader;
				bool flag;
				string text;
				HashAlgorithm hashAlgorithm;
				string text2;
				switch (num2)
				{
				case 0:
					goto IL_AA2;
				case 1:
					try
					{
						if (binaryReader != null)
						{
							goto IL_959;
						}
						int num3 = 2;
						IL_943:
						switch (num3)
						{
						case 1:
							IL_959:
							vua32v5yjQhjRjK4YIO.kCdVCPoLg0VWVIk6a6g(binaryReader);
							num3 = 0;
							if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() == null)
							{
								num3 = 0;
								goto IL_943;
							}
							goto IL_943;
						}
						goto IL_8CC;
					}
					catch
					{
						int num4 = 0;
						if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() == null)
						{
							num4 = 0;
						}
						switch (num4)
						{
						default:
							goto IL_8CC;
						}
					}
					goto IL_9EA;
				case 2:
					goto IL_A07;
				case 3:
					return;
				case 4:
					flag = false;
					num2 = 20;
					continue;
				case 5:
					goto IL_A3D;
				case 6:
					try
					{
						FileStream fileStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.Read);
						int num5 = 24;
						for (;;)
						{
							long num6;
							int num7;
							uint num8;
							uint num9;
							uint num10;
							long num11;
							byte[] array2;
							uint num13;
							long num14;
							long num16;
							int num17;
							int num18;
							long num19;
							switch (num5)
							{
							case 0:
								goto IL_5ED;
							case 1:
								vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(fileStream, num6);
								num7 = 8;
								break;
							case 2:
								vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(fileStream, (long)((ulong)(num8 + 32U)));
								num5 = 37;
								if (!vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
								{
									num5 = 10;
									continue;
								}
								continue;
							case 3:
								goto IL_55C;
							case 4:
								num9 -= num10;
								num5 = 6;
								if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() == null)
								{
									num5 = 22;
									continue;
								}
								continue;
							case 5:
								goto IL_3E4;
							case 6:
							{
								uint num12;
								num11 = num6 + (long)((ulong)num12);
								num5 = 16;
								continue;
							}
							case 7:
								goto IL_338;
							case 8:
							{
								uint num12;
								byte[] array = vua32v5yjQhjRjK4YIO.OFvD0PofQ8pQnRTtjYU(binaryReader, (int)num12);
								num5 = 6;
								if (vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
								{
									num5 = 17;
									continue;
								}
								continue;
							}
							case 9:
								goto IL_549;
							case 10:
								vua32v5yjQhjRjK4YIO.ChQvCWoONmQTsXD4yGa(hashAlgorithm, new byte[0], 0, 0);
								num5 = 1;
								if (!vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
								{
									num5 = 1;
									continue;
								}
								continue;
							case 11:
								vua32v5yjQhjRjK4YIO.kf8oJqoSTlcuodB5Teu(hashAlgorithm, fileStream, 152U, array2);
								num5 = 0;
								if (!vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
								{
									num5 = 0;
									continue;
								}
								continue;
							case 12:
								if (num13 < num9)
								{
									num5 = 40;
									continue;
								}
								goto IL_338;
							case 13:
								goto IL_2EC;
							case 14:
								goto IL_338;
							case 15:
								vua32v5yjQhjRjK4YIO.kf8oJqoSTlcuodB5Teu(hashAlgorithm, fileStream, num10, array2);
								num5 = 3;
								if (vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
								{
									num5 = 4;
									continue;
								}
								continue;
							case 16:
								vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(fileStream, num14);
								num5 = 27;
								if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() != null)
								{
									num5 = 25;
									continue;
								}
								continue;
							case 17:
							{
								byte[] array;
								vua32v5yjQhjRjK4YIO.bRsgsqoFipU8MAMAF24(array);
								num5 = 28;
								continue;
							}
							case 18:
								goto IL_1B9;
							case 19:
							{
								uint num15 = vua32v5yjQhjRjK4YIO.x4yEtRo1sjiuBGLdWag(binaryReader);
								num5 = 29;
								continue;
							}
							case 20:
								goto IL_1B9;
							case 21:
								if (num6 > num16)
								{
									goto IL_549;
								}
								num5 = 21;
								if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() == null)
								{
									num5 = 23;
									continue;
								}
								continue;
							case 22:
								goto IL_59D;
							case 23:
								if (num16 >= num11)
								{
									num5 = 9;
									continue;
								}
								goto IL_2EC;
							case 24:
								binaryReader = new BinaryReader(fileStream);
								num5 = 34;
								continue;
							case 25:
							{
								FileStream fileStream2 = fileStream;
								vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(fileStream2, vua32v5yjQhjRjK4YIO.iaSWcSoUHi57GCkO7up(fileStream2) + (long)((ulong)num13));
								num5 = 18;
								if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() == null)
								{
									num5 = 36;
									continue;
								}
								continue;
							}
							case 26:
								goto IL_549;
							case 27:
								num17 = 0;
								num5 = 18;
								continue;
							case 28:
							{
								byte[] array;
								flag = !vua32v5yjQhjRjK4YIO.MZJ9IHoRrudNNlB7JkZ(vua32v5yjQhjRjK4YIO.EXHzxLTGx, vua32v5yjQhjRjK4YIO.WWqgbSoTWLab5fyJC78(hashAlgorithm), text2, array);
								num5 = 43;
								continue;
							}
							case 29:
							{
								uint num15;
								vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(fileStream, (long)((ulong)num15));
								num5 = 41;
								continue;
							}
							case 30:
								num9 = vua32v5yjQhjRjK4YIO.x4yEtRo1sjiuBGLdWag(binaryReader);
								num5 = 11;
								if (vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
								{
									num5 = 19;
									continue;
								}
								continue;
							case 31:
								goto IL_3E4;
							case 32:
								goto IL_43A;
							case 33:
								vua32v5yjQhjRjK4YIO.kf8oJqoSTlcuodB5Teu(hashAlgorithm, fileStream, num9, array2);
								num5 = 7;
								continue;
							case 34:
								array2 = new byte[65536];
								num5 = 11;
								continue;
							case 35:
								goto IL_586;
							case 36:
								goto IL_59D;
							case 37:
							{
								uint u = vua32v5yjQhjRjK4YIO.x4yEtRo1sjiuBGLdWag(binaryReader);
								uint num12 = vua32v5yjQhjRjK4YIO.x4yEtRo1sjiuBGLdWag(binaryReader);
								num6 = (long)((ulong)vua32v5yjQhjRjK4YIO.i4DLcBop40cOBck10DF(u, num18, num19, binaryReader));
								num5 = 6;
								continue;
							}
							case 38:
								goto IL_470;
							case 39:
								goto IL_470;
							case 40:
								num9 -= num13;
								num7 = 25;
								break;
							case 41:
								goto IL_59D;
							case 42:
								goto IL_37D;
							case 43:
								goto IL_6FC;
							default:
								goto IL_5ED;
							}
							num5 = num7;
							continue;
							IL_1B9:
							if (num17 < num18)
							{
								goto IL_37D;
							}
							num5 = 10;
							if (!vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
							{
								num5 = 4;
								continue;
							}
							continue;
							IL_2EC:
							num13 = (uint)(num11 - num16);
							num5 = 12;
							continue;
							IL_338:
							num17++;
							num5 = 20;
							continue;
							IL_37D:
							vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(fileStream, num19 + (long)(num17 * 40) + 16L);
							num5 = 30;
							continue;
							IL_3E4:
							num8 = vua32v5yjQhjRjK4YIO.i4DLcBop40cOBck10DF(vua32v5yjQhjRjK4YIO.x4yEtRo1sjiuBGLdWag(binaryReader), num18, num19, binaryReader);
							num5 = 2;
							continue;
							IL_43A:
							num16 = vua32v5yjQhjRjK4YIO.iaSWcSoUHi57GCkO7up(fileStream);
							num5 = 21;
							continue;
							IL_59D:
							if (num9 > 0U)
							{
								goto IL_43A;
							}
							num5 = 14;
							if (!vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
							{
								num5 = 12;
								continue;
							}
							continue;
							IL_470:
							vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(fileStream, 376L);
							num5 = 31;
							continue;
							IL_549:
							if (num16 >= num11)
							{
								num5 = 33;
								continue;
							}
							IL_55C:
							num10 = (uint)vua32v5yjQhjRjK4YIO.pYcZAco4CtLVof5dk9v(num6 - num16, (long)((ulong)num9));
							num5 = 7;
							if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() == null)
							{
								num5 = 15;
								continue;
							}
							continue;
							IL_586:
							vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(fileStream, 360L);
							num5 = 5;
							continue;
							IL_5ED:
							bool flag2 = vua32v5yjQhjRjK4YIO.rLWmHJoIOjUjyry637F(binaryReader) != 523;
							int num20 = flag2 ? 96 : 112;
							vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(fileStream, 152L);
							vua32v5yjQhjRjK4YIO.sT1PdIoidHmANIkcpaW(fileStream, array2, 0, num20);
							array2[64] = 0;
							array2[65] = 0;
							array2[66] = 0;
							array2[67] = 0;
							vua32v5yjQhjRjK4YIO.wYUQE2oZdWaYWfLbNNN(hashAlgorithm, array2, 0, num20);
							vua32v5yjQhjRjK4YIO.sT1PdIoidHmANIkcpaW(fileStream, array2, 0, 128);
							array2[32] = 0;
							array2[33] = 0;
							array2[34] = 0;
							array2[35] = 0;
							array2[36] = 0;
							array2[37] = 0;
							array2[38] = 0;
							array2[39] = 0;
							vua32v5yjQhjRjK4YIO.wYUQE2oZdWaYWfLbNNN(hashAlgorithm, array2, 0, 128);
							num19 = vua32v5yjQhjRjK4YIO.iaSWcSoUHi57GCkO7up(fileStream);
							vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(fileStream, 134L);
							num18 = (int)vua32v5yjQhjRjK4YIO.rLWmHJoIOjUjyry637F(binaryReader);
							vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(fileStream, num19);
							vua32v5yjQhjRjK4YIO.kf8oJqoSTlcuodB5Teu(hashAlgorithm, fileStream, (uint)(num18 * 40), array2);
							num14 = vua32v5yjQhjRjK4YIO.iaSWcSoUHi57GCkO7up(fileStream);
							if (flag2)
							{
								goto IL_586;
							}
							num5 = 38;
							if (!vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
							{
								num5 = 33;
							}
						}
						IL_6FC:
						goto IL_AA2;
					}
					catch
					{
						int num21 = 1;
						if (!vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
						{
							num21 = 1;
						}
						for (;;)
						{
							switch (num21)
							{
							case 1:
								flag = true;
								num21 = 0;
								if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() != null)
								{
									num21 = 0;
									continue;
								}
								continue;
							}
							break;
						}
						goto IL_AA2;
					}
					break;
				case 7:
					if (text == null)
					{
						return;
					}
					num2 = 22;
					if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() != null)
					{
						num2 = 13;
						continue;
					}
					continue;
				case 8:
					break;
				case 9:
					vua32v5yjQhjRjK4YIO.dawOAgdvUuqjjbWDTaU(true);
					num2 = 13;
					continue;
				case 10:
					try
					{
						vua32v5yjQhjRjK4YIO.jsNEGrxyc7c7MqjFUgf jsNEGrxyc7c7MqjFUgf = new vua32v5yjQhjRjK4YIO.jsNEGrxyc7c7MqjFUgf(vua32v5yjQhjRjK4YIO.Hin79Zocp5A5DPUwSWS(vua32v5yjQhjRjK4YIO.QDHV0iQKg, "MRfnuMxe84X69YMjyQ.3F7dyiuKnfVkapU2vQ"));
						vua32v5yjQhjRjK4YIO.cnVmRlox9cJSRVHsZPP(vua32v5yjQhjRjK4YIO.VnwbqMo55K1wHepas1k(jsNEGrxyc7c7MqjFUgf), 0L);
						byte[] array3 = vua32v5yjQhjRjK4YIO.tnfD0JoVuAd0GalwTms(jsNEGrxyc7c7MqjFUgf, (int)vua32v5yjQhjRjK4YIO.PdhlkVouTLGyE0QRO6r(vua32v5yjQhjRjK4YIO.VnwbqMo55K1wHepas1k(jsNEGrxyc7c7MqjFUgf)));
						byte[] array4 = new byte[32];
						int num22 = 25 + 93;
						array4[0] = (byte)num22;
						num22 = 108 + 77;
						array4[0] = (byte)num22;
						num22 = 181 - 60;
						array4[0] = (byte)num22;
						array4[0] = 195 - 65;
						num22 = 159 + 56;
						array4[0] = (byte)num22;
						array4[1] = 139 - 46;
						num22 = 31 + 57;
						array4[1] = (byte)num22;
						num22 = 221 - 73;
						array4[1] = (byte)num22;
						num22 = 245 - 81;
						array4[1] = (byte)num22;
						num22 = 28 + 108;
						array4[1] = (byte)num22;
						num22 = 96 - 22;
						array4[1] = (byte)num22;
						array4[2] = 133 - 44;
						array4[2] = 214 - 71;
						array4[2] = 124 - 124;
						array4[3] = 184 - 61;
						array4[3] = 35 + 74;
						num22 = 245 - 81;
						array4[3] = (byte)num22;
						array4[3] = 238 - 79;
						num22 = 179 - 59;
						array4[3] = (byte)num22;
						array4[3] = 171 - 91;
						array4[4] = 157 - 52;
						num22 = 78 + 114;
						array4[4] = (byte)num22;
						array4[4] = 184 - 61;
						num22 = 52 + 3;
						array4[4] = (byte)num22;
						array4[4] = 213 - 95;
						array4[5] = 103 + 80;
						num22 = 218 - 72;
						array4[5] = (byte)num22;
						array4[5] = 236 - 78;
						array4[5] = 86 + 71;
						num22 = 76 + 65;
						array4[6] = (byte)num22;
						array4[6] = 120 + 24;
						num22 = 107 + 59;
						array4[6] = (byte)num22;
						num22 = 132 - 44;
						array4[7] = (byte)num22;
						array4[7] = 191 - 63;
						array4[7] = 141 - 40;
						array4[8] = 233 - 77;
						num22 = 119 + 9;
						array4[8] = (byte)num22;
						num22 = 159 - 53;
						array4[8] = (byte)num22;
						array4[8] = 156 + 65;
						array4[9] = 181 - 60;
						array4[9] = 41 + 36;
						num22 = 68 + 122;
						array4[9] = (byte)num22;
						array4[10] = 230 - 76;
						num22 = 194 - 64;
						array4[10] = (byte)num22;
						array4[10] = 72 + 61;
						array4[11] = 204 - 68;
						num22 = 239 - 79;
						array4[11] = (byte)num22;
						array4[11] = 169 - 69;
						array4[12] = 195 - 65;
						num22 = 156 - 52;
						array4[12] = (byte)num22;
						array4[12] = 125 - 41;
						num22 = 6 + 19;
						array4[12] = (byte)num22;
						array4[12] = 106 + 58;
						num22 = 58 + 82;
						array4[13] = (byte)num22;
						num22 = 138 - 46;
						array4[13] = (byte)num22;
						num22 = 177 - 59;
						array4[13] = (byte)num22;
						num22 = 78 - 62;
						array4[13] = (byte)num22;
						array4[14] = 83 + 93;
						num22 = 205 - 68;
						array4[14] = (byte)num22;
						num22 = 199 - 66;
						array4[14] = (byte)num22;
						array4[14] = 130 - 43;
						array4[14] = 235 - 78;
						array4[14] = 156 + 1;
						array4[15] = 35 + 52;
						num22 = 171 - 57;
						array4[15] = (byte)num22;
						num22 = 116 - 25;
						array4[15] = (byte)num22;
						array4[16] = 229 - 76;
						array4[16] = 8 + 122;
						array4[16] = 134 - 44;
						num22 = 223 - 74;
						array4[16] = (byte)num22;
						array4[16] = 160 - 81;
						array4[17] = 89 + 9;
						array4[17] = 243 - 81;
						num22 = 252 - 84;
						array4[17] = (byte)num22;
						num22 = 186 + 13;
						array4[17] = (byte)num22;
						array4[18] = 23 + 81;
						array4[18] = 204 - 68;
						num22 = 49 + 6;
						array4[18] = (byte)num22;
						num22 = 133 - 38;
						array4[18] = (byte)num22;
						array4[19] = 221 - 73;
						array4[19] = 129 - 43;
						array4[19] = 130 - 43;
						array4[19] = 184 - 61;
						num22 = 138 - 46;
						array4[19] = (byte)num22;
						num22 = 195 - 105;
						array4[19] = (byte)num22;
						array4[20] = 14 + 39;
						num22 = 82 + 15;
						array4[20] = (byte)num22;
						array4[20] = 149 - 49;
						array4[20] = 237 - 79;
						num22 = 192 - 64;
						array4[20] = (byte)num22;
						num22 = 100 - 38;
						array4[20] = (byte)num22;
						array4[21] = 120 + 124;
						num22 = 162 - 54;
						array4[21] = (byte)num22;
						array4[21] = 20 + 25;
						num22 = 237 - 79;
						array4[21] = (byte)num22;
						array4[21] = 170 - 56;
						num22 = 135 + 14;
						array4[21] = (byte)num22;
						num22 = 25 + 61;
						array4[22] = (byte)num22;
						array4[22] = 188 - 62;
						num22 = 225 + 9;
						array4[22] = (byte)num22;
						array4[23] = 36 + 51;
						num22 = 136 - 45;
						array4[23] = (byte)num22;
						num22 = 207 - 69;
						array4[23] = (byte)num22;
						array4[23] = 27 + 100;
						num22 = 1 + 13;
						array4[24] = (byte)num22;
						array4[24] = 41 + 75;
						array4[24] = 224 - 74;
						array4[24] = 110 - 88;
						num22 = 29 + 52;
						array4[25] = (byte)num22;
						num22 = 120 + 97;
						array4[25] = (byte)num22;
						num22 = 207 - 107;
						array4[25] = (byte)num22;
						array4[26] = 21 + 33;
						array4[26] = 80 + 2;
						array4[26] = 46 + 99;
						array4[26] = 92 + 48;
						array4[27] = 144 - 48;
						num22 = 198 - 66;
						array4[27] = (byte)num22;
						array4[27] = 14 + 112;
						array4[27] = 76 + 91;
						num22 = 96 + 58;
						array4[27] = (byte)num22;
						array4[28] = 251 - 83;
						array4[28] = 105 + 78;
						array4[28] = 163 - 54;
						array4[28] = 124 + 69;
						array4[28] = 128 - 42;
						array4[28] = 116 - 98;
						num22 = 245 - 81;
						array4[29] = (byte)num22;
						num22 = 30 + 51;
						array4[29] = (byte)num22;
						num22 = 63 + 74;
						array4[29] = (byte)num22;
						array4[29] = 49 + 114;
						num22 = 63 + 114;
						array4[30] = (byte)num22;
						array4[30] = 33 + 120;
						array4[30] = 144 - 48;
						num22 = 66 - 62;
						array4[30] = (byte)num22;
						num22 = 157 - 52;
						array4[31] = (byte)num22;
						array4[31] = 219 - 73;
						array4[31] = 80 + 27;
						num22 = 16 + 20;
						array4[31] = (byte)num22;
						array4[31] = 81 + 116;
						num22 = 138 + 75;
						array4[31] = (byte)num22;
						byte[] array5 = array4;
						byte[] array6 = new byte[16];
						int num23 = 151 - 50;
						array6[0] = (byte)num23;
						num23 = 8 + 108;
						array6[0] = (byte)num23;
						num23 = 90 + 62;
						array6[0] = (byte)num23;
						num23 = 175 - 58;
						array6[1] = (byte)num23;
						num23 = 62 + 56;
						array6[1] = (byte)num23;
						array6[1] = 13 + 2;
						num23 = 71 - 57;
						array6[1] = (byte)num23;
						array6[2] = 92 + 54;
						num23 = 202 - 67;
						array6[2] = (byte)num23;
						array6[2] = 237 - 79;
						array6[2] = 146 - 38;
						array6[3] = 112 + 7;
						num23 = 86 + 124;
						array6[3] = (byte)num23;
						num23 = 184 - 61;
						array6[3] = (byte)num23;
						num23 = 35 + 74;
						array6[3] = (byte)num23;
						num23 = 245 - 81;
						array6[3] = (byte)num23;
						array6[3] = 166 + 49;
						num23 = 138 - 46;
						array6[4] = (byte)num23;
						num23 = 91 + 81;
						array6[4] = (byte)num23;
						num23 = 51 + 78;
						array6[4] = (byte)num23;
						num23 = 174 - 58;
						array6[4] = (byte)num23;
						array6[4] = 77 - 57;
						num23 = 52 + 3;
						array6[5] = (byte)num23;
						num23 = 223 - 74;
						array6[5] = (byte)num23;
						num23 = 117 - 80;
						array6[5] = (byte)num23;
						array6[6] = 89 + 37;
						num23 = 71 + 37;
						array6[6] = (byte)num23;
						num23 = 68 - 65;
						array6[6] = (byte)num23;
						array6[7] = 120 + 24;
						num23 = 59 + 85;
						array6[7] = (byte)num23;
						array6[7] = 116 + 63;
						array6[7] = 227 - 75;
						array6[7] = 75 + 119;
						num23 = 33 + 111;
						array6[7] = (byte)num23;
						num23 = 65 + 79;
						array6[8] = (byte)num23;
						num23 = 218 - 72;
						array6[8] = (byte)num23;
						num23 = 36 + 11;
						array6[8] = (byte)num23;
						num23 = 243 - 81;
						array6[8] = (byte)num23;
						num23 = 50 + 104;
						array6[8] = (byte)num23;
						array6[9] = 61 + 103;
						array6[9] = 48 + 110;
						array6[9] = 84 + 69;
						num23 = 68 + 52;
						array6[10] = (byte)num23;
						num23 = 166 - 55;
						array6[10] = (byte)num23;
						array6[10] = 82 + 6;
						num23 = 58 + 8;
						array6[10] = (byte)num23;
						num23 = 210 - 70;
						array6[10] = (byte)num23;
						array6[10] = 236 + 1;
						array6[11] = 28 + 50;
						num23 = 62 + 12;
						array6[11] = (byte)num23;
						num23 = 221 - 73;
						array6[11] = (byte)num23;
						array6[11] = 205 - 68;
						num23 = 174 - 71;
						array6[11] = (byte)num23;
						num23 = 5 + 92;
						array6[12] = (byte)num23;
						array6[12] = 126 - 42;
						array6[12] = 122 - 83;
						array6[13] = 179 - 59;
						num23 = 171 - 57;
						array6[13] = (byte)num23;
						num23 = 25 + 26;
						array6[13] = (byte)num23;
						array6[13] = 147 - 100;
						array6[14] = 133 - 44;
						num23 = 169 - 56;
						array6[14] = (byte)num23;
						array6[14] = 142 + 9;
						array6[15] = 223 - 74;
						num23 = 24 + 89;
						array6[15] = (byte)num23;
						num23 = 69 + 113;
						array6[15] = (byte)num23;
						array6[15] = 175 + 43;
						byte[] array7 = array6;
						object obj = vua32v5yjQhjRjK4YIO.CMkaqcoykBdflPLW2fB();
						vua32v5yjQhjRjK4YIO.kSh0iJo8UjBOk1eG7LK(obj, CipherMode.CBC);
						ICryptoTransform transform = vua32v5yjQhjRjK4YIO.ooeOmcoqkvAGqTvDpI4(obj, array5, array7);
						Stream stream = vua32v5yjQhjRjK4YIO.krEeFRod4g8ANYMWNQt();
						CryptoStream cryptoStream = new CryptoStream(stream, transform, CryptoStreamMode.Write);
						vua32v5yjQhjRjK4YIO.Agyx3foo3DAm8f7N1hN(cryptoStream, array3, 0, array3.Length);
						vua32v5yjQhjRjK4YIO.fS7wRro301mtHpZNSsC(cryptoStream);
						vua32v5yjQhjRjK4YIO.RTIeNjowDqMoQ8CRIlb(vua32v5yjQhjRjK4YIO.EXHzxLTGx, vua32v5yjQhjRjK4YIO.C6q0Ilo9U0SoWudv0PW(vua32v5yjQhjRjK4YIO.BjVdxyoQVmPSxkSjafs(), vua32v5yjQhjRjK4YIO.MKTMTMoCkqotWMrgaHF(stream)));
						vua32v5yjQhjRjK4YIO.XUXX14oAnoygn8KS3nA(stream);
						vua32v5yjQhjRjK4YIO.XUXX14oAnoygn8KS3nA(cryptoStream);
						vua32v5yjQhjRjK4YIO.Uoj6efohobKjsSLyb1Q(jsNEGrxyc7c7MqjFUgf);
						int num24 = 0;
						if (!vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
						{
							num24 = 0;
						}
						switch (num24)
						{
						default:
							goto IL_7A1;
						}
					}
					catch
					{
						int num25 = 0;
						if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() == null)
						{
							num25 = 0;
						}
						for (;;)
						{
							switch (num25)
							{
							default:
								flag = true;
								num25 = 1;
								if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() != null)
								{
									num25 = 1;
								}
								break;
							case 1:
								goto IL_2041;
							}
						}
						IL_2041:
						goto IL_7A1;
					}
					goto IL_2050;
				case 11:
					goto IL_2066;
				case 12:
					goto IL_ABD;
				case 13:
					vua32v5yjQhjRjK4YIO.EXHzxLTGx = new RSACryptoServiceProvider();
					num2 = 17;
					if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() == null)
					{
						num2 = 21;
						continue;
					}
					continue;
				case 14:
					goto IL_A4C;
				case 15:
					if (vua32v5yjQhjRjK4YIO.EXHzxLTGx != null)
					{
						num2 = 14;
						continue;
					}
					goto IL_A3D;
				case 16:
					try
					{
						hashAlgorithm = vua32v5yjQhjRjK4YIO.FVtb4FoWs0TTSExT7Hi();
						int num26 = 0;
						if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() == null)
						{
							num26 = 1;
						}
						for (;;)
						{
							switch (num26)
							{
							case 1:
								text2 = vua32v5yjQhjRjK4YIO.BBTCguoPg8cL5mR7sdI("SHA1");
								num26 = 0;
								if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() == null)
								{
									num26 = 0;
									continue;
								}
								continue;
							case 2:
								goto IL_85D;
							case 3:
								goto IL_7F2;
							}
							if (vua32v5yjQhjRjK4YIO.PA0DhEoEXqWUel9xPGu(text))
							{
								goto IL_85D;
							}
							num26 = 3;
							if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() != null)
							{
								num26 = 2;
							}
						}
						IL_7F2:
						return;
						IL_85D:
						goto IL_2066;
					}
					catch
					{
						int num27 = 0;
						if (vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
						{
							num27 = 0;
						}
						switch (num27)
						{
						default:
							return;
						}
					}
					return;
				case 17:
					goto IL_7A1;
				case 18:
					goto IL_9EA;
				case 19:
					goto IL_8CC;
				case 20:
					return;
				case 21:
					text = vua32v5yjQhjRjK4YIO.AHenlOdbvavtMugx1ON(vua32v5yjQhjRjK4YIO.ygIRMIdjbXoZj6dgO6T(typeof(vua32v5yjQhjRjK4YIO).TypeHandle).Assembly);
					num2 = 7;
					if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() != null)
					{
						num2 = 3;
						continue;
					}
					continue;
				case 22:
					goto IL_2050;
				case 23:
					goto IL_8CC;
				default:
					goto IL_AA2;
				}
				hashAlgorithm = null;
				num2 = 18;
				if (!vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
				{
					num2 = 9;
					continue;
				}
				continue;
				IL_7A1:
				if (flag)
				{
					num2 = 19;
					continue;
				}
				goto IL_ABD;
				IL_8CC:
				if (flag)
				{
					goto IL_A07;
				}
				num2 = 4;
				if (!vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
				{
					num2 = 1;
					continue;
				}
				continue;
				IL_9EA:
				text2 = null;
				num2 = 5;
				if (vua32v5yjQhjRjK4YIO.NCA9UGdB5vtOVh5O2cs() == null)
				{
					num2 = 16;
					continue;
				}
				continue;
				IL_A3D:
				vua32v5yjQhjRjK4YIO.iZjQCjdDauV1d0GnTWv();
				num2 = 9;
				continue;
				IL_AA2:
				num2 = 1;
				if (!vua32v5yjQhjRjK4YIO.IH2h7bdGhq6PqvDfeTR())
				{
					num2 = 1;
					continue;
				}
				continue;
				IL_ABD:
				binaryReader = null;
				num2 = 6;
				continue;
				IL_2050:
				if (vua32v5yjQhjRjK4YIO.uoODVLdzZs48oqPoF63(text) != 0)
				{
					num2 = 8;
					continue;
				}
				return;
				IL_2066:
				flag = false;
				num2 = 10;
			}
			return;
			IL_A07:
			throw new Exception(vua32v5yjQhjRjK4YIO.PAQMINoKrt3MVIJOZ4M(vua32v5yjQhjRjK4YIO.MggiEfoa8jeIA7DoFmk(vua32v5yjQhjRjK4YIO.KZyxO3olnOmgHZ8xUnI(vua32v5yjQhjRjK4YIO.ygIRMIdjbXoZj6dgO6T(typeof(vua32v5yjQhjRjK4YIO).TypeHandle).Assembly)), " is tampered."));
			IL_A4C:;
		}

		// Token: 0x06000815 RID: 2069 RVA: 0x00046408 File Offset: 0x00044608
		public static void GqP516At0d(RuntimeTypeHandle \u0020)
		{
			try
			{
				Type typeFromHandle = Type.GetTypeFromHandle(\u0020);
				if (vua32v5yjQhjRjK4YIO.pAL10SKCoC == null)
				{
					object obj = vua32v5yjQhjRjK4YIO.bYc11bZ2yR;
					lock (obj)
					{
						Dictionary<int, int> dictionary = new Dictionary<int, int>();
						BinaryReader binaryReader = new BinaryReader(Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(33554521)).Assembly.GetManifestResourceStream("ulGgQAd6RKboaGeliD.b91pRkoF1oYkT8QpFI"));
						binaryReader.BaseStream.Position = 0L;
						byte[] array = binaryReader.ReadBytes((int)binaryReader.BaseStream.Length);
						binaryReader.Close();
						if (array.Length != 0)
						{
							int num = array.Length % 4;
							int num2 = array.Length / 4;
							byte[] array2 = new byte[array.Length];
							uint num3 = 0U;
							if (num > 0)
							{
								num2++;
							}
							for (int i = 0; i < num2; i++)
							{
								int num4 = i * 4;
								uint num5 = 255U;
								int num6 = 0;
								uint num7;
								if (i == num2 - 1 && num > 0)
								{
									num7 = 0U;
									for (int j = 0; j < num; j++)
									{
										if (j > 0)
										{
											num7 <<= 8;
										}
										num7 |= (uint)array[array.Length - (1 + j)];
									}
								}
								else
								{
									uint num8 = (uint)num4;
									num7 = (uint)((int)array[(int)(num8 + 3U)] << 24 | (int)array[(int)(num8 + 2U)] << 16 | (int)array[(int)(num8 + 1U)] << 8 | (int)array[(int)num8]);
								}
								num3 = num3;
								num3 += vua32v5yjQhjRjK4YIO.g4E5OpQeSu(num3);
								if (i == num2 - 1 && num > 0)
								{
									uint num9 = num3 ^ num7;
									for (int k = 0; k < num; k++)
									{
										if (k > 0)
										{
											num5 <<= 8;
											num6 += 8;
										}
										array2[num4 + k] = (byte)((num9 & num5) >> num6);
									}
								}
								else
								{
									uint num10 = num3 ^ num7;
									array2[num4] = (byte)(num10 & 255U);
									array2[num4 + 1] = (byte)((num10 & 65280U) >> 8);
									array2[num4 + 2] = (byte)((num10 & 16711680U) >> 16);
									array2[num4 + 3] = (byte)((num10 & 4278190080U) >> 24);
								}
							}
							array = array2;
							int num11 = array.Length / 8;
							vua32v5yjQhjRjK4YIO.jsNEGrxyc7c7MqjFUgf jsNEGrxyc7c7MqjFUgf = new vua32v5yjQhjRjK4YIO.jsNEGrxyc7c7MqjFUgf(new MemoryStream(array));
							for (int l = 0; l < num11; l++)
							{
								int key = jsNEGrxyc7c7MqjFUgf.TiuxdQCTyx();
								int value = jsNEGrxyc7c7MqjFUgf.TiuxdQCTyx();
								dictionary.Add(key, value);
							}
							jsNEGrxyc7c7MqjFUgf.DIaxoZpvij();
						}
						vua32v5yjQhjRjK4YIO.pAL10SKCoC = dictionary;
					}
				}
				FieldInfo[] fields = typeFromHandle.GetFields(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.GetField);
				for (int m = 0; m < fields.Length; m++)
				{
					try
					{
						FieldInfo fieldInfo = fields[m];
						int metadataToken = fieldInfo.MetadataToken;
						int num12 = vua32v5yjQhjRjK4YIO.pAL10SKCoC[metadataToken];
						bool flag2 = (num12 & 1073741824) > 0;
						num12 &= 1073741823;
						MethodInfo methodInfo = (MethodInfo)Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(33554521)).Module.ResolveMethod(num12, typeFromHandle.GetGenericArguments(), new Type[0]);
						if (methodInfo.IsStatic)
						{
							fieldInfo.SetValue(null, Delegate.CreateDelegate(fieldInfo.FieldType, methodInfo));
						}
						else
						{
							ParameterInfo[] parameters = methodInfo.GetParameters();
							int num13 = parameters.Length + 1;
							Type[] array3 = new Type[num13];
							if (methodInfo.DeclaringType.IsValueType)
							{
								array3[0] = methodInfo.DeclaringType.MakeByRefType();
							}
							else
							{
								array3[0] = Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(16777236));
							}
							for (int n = 0; n < parameters.Length; n++)
							{
								array3[n + 1] = parameters[n].ParameterType;
							}
							DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, methodInfo.ReturnType, array3, typeFromHandle, true);
							ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
							for (int num14 = 0; num14 < num13; num14++)
							{
								switch (num14)
								{
								case 0:
									ilgenerator.Emit(OpCodes.Ldarg_0);
									break;
								case 1:
									ilgenerator.Emit(OpCodes.Ldarg_1);
									break;
								case 2:
									ilgenerator.Emit(OpCodes.Ldarg_2);
									break;
								case 3:
									ilgenerator.Emit(OpCodes.Ldarg_3);
									break;
								default:
									ilgenerator.Emit(OpCodes.Ldarg_S, num14);
									break;
								}
							}
							ilgenerator.Emit(OpCodes.Tailcall);
							ilgenerator.Emit(flag2 ? OpCodes.Callvirt : OpCodes.Call, methodInfo);
							ilgenerator.Emit(OpCodes.Ret);
							fieldInfo.SetValue(null, dynamicMethod.CreateDelegate(typeFromHandle));
						}
					}
					catch
					{
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000816 RID: 2070 RVA: 0x00046908 File Offset: 0x00044B08
		private static uint dex54AgERE(uint \u0020)
		{
			return (uint)"{11111-22222-10009-11112}".Length;
		}

		// Token: 0x06000817 RID: 2071 RVA: 0x00046914 File Offset: 0x00044B14
		private static uint g4E5OpQeSu(uint \u0020)
		{
			return 0U;
		}

		// Token: 0x06000818 RID: 2072 RVA: 0x00046918 File Offset: 0x00044B18
		internal static void p1T5fGSd8t()
		{
			if (Debugger.IsAttached)
			{
				throw new Exception("Debugger Detected");
			}
		}

		// Token: 0x06000819 RID: 2073 RVA: 0x00046930 File Offset: 0x00044B30
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static void ITC5FA7Rdl(Stream \u0020, int \u0020)
		{
			ykD11HxHfZBYH7OcFOG.by2xXOQ8u6(0, new object[]
			{
				\u0020,
				\u0020
			}, null);
		}

		// Token: 0x0600081A RID: 2074 RVA: 0x00046970 File Offset: 0x00044B70
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static string BRA5TcZvlv(int \u0020)
		{
			if (vua32v5yjQhjRjK4YIO.lRG1gLlTer.Length == 0)
			{
				vua32v5yjQhjRjK4YIO.RaA1I3e0cE = new List<string>();
				vua32v5yjQhjRjK4YIO.BV01muBIf0 = new List<int>();
				vua32v5yjQhjRjK4YIO.ITC5FA7Rdl(vua32v5yjQhjRjK4YIO.QDHV0iQKg.GetManifestResourceStream("P3PMFAPrFAEEKaWdjv.7DXvmxE6PF8c6IS3QV"), \u0020);
			}
			if (vua32v5yjQhjRjK4YIO.Pgs1HOBEQA < 75)
			{
				if (vua32v5yjQhjRjK4YIO.QDHV0iQKg != new StackFrame(1).GetMethod().DeclaringType.Assembly)
				{
					throw new Exception();
				}
				vua32v5yjQhjRjK4YIO.Pgs1HOBEQA++;
			}
			object obj = vua32v5yjQhjRjK4YIO.t8Q1fis8nb;
			lock (obj)
			{
				int num = BitConverter.ToInt32(vua32v5yjQhjRjK4YIO.lRG1gLlTer, \u0020);
				if (num < vua32v5yjQhjRjK4YIO.BV01muBIf0.Count && vua32v5yjQhjRjK4YIO.BV01muBIf0[num] == \u0020)
				{
					return vua32v5yjQhjRjK4YIO.RaA1I3e0cE[num];
				}
				try
				{
					PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
					byte[] array = new byte[num];
					Array.Copy(vua32v5yjQhjRjK4YIO.lRG1gLlTer, \u0020 + 4, array, 0, num);
					string @string = Encoding.Unicode.GetString(array, 0, array.Length);
					vua32v5yjQhjRjK4YIO.RaA1I3e0cE.Add(@string);
					vua32v5yjQhjRjK4YIO.BV01muBIf0.Add(\u0020);
					Array.Copy(BitConverter.GetBytes(vua32v5yjQhjRjK4YIO.RaA1I3e0cE.Count - 1), 0, vua32v5yjQhjRjK4YIO.lRG1gLlTer, \u0020, 4);
					return @string;
				}
				catch
				{
				}
			}
			return "";
		}

		// Token: 0x0600081B RID: 2075 RVA: 0x00046AE8 File Offset: 0x00044CE8
		internal static string nOC5RJWah8(string \u0020)
		{
			"{11111-22222-50001-00000}".Trim();
			byte[] array = Convert.FromBase64String(\u0020);
			return Encoding.Unicode.GetString(array, 0, array.Length);
		}

		// Token: 0x0600081C RID: 2076 RVA: 0x00046B18 File Offset: 0x00044D18
		private static int YPi5L4q0Sj()
		{
			return 5;
		}

		// Token: 0x0600081D RID: 2077 RVA: 0x00046B1C File Offset: 0x00044D1C
		private static void eEX5lHAx8B()
		{
			try
			{
				RSACryptoServiceProvider.UseMachineKeyStore = true;
			}
			catch
			{
			}
		}

		// Token: 0x0600081E RID: 2078 RVA: 0x00046B4C File Offset: 0x00044D4C
		private static Delegate NpQ5a6suPC(IntPtr \u0020, Type \u0020)
		{
			return (Delegate)Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(16777334)).GetMethod("GetDelegateForFunctionPointer", new Type[]
			{
				Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(16777245)),
				Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(16777370))
			}).Invoke(null, new object[]
			{
				\u0020,
				\u0020
			});
		}

		// Token: 0x0600081F RID: 2079 RVA: 0x00046BBC File Offset: 0x00044DBC
		internal static object mEt5KoNZkk(object \u0020)
		{
			try
			{
				if (File.Exists(((Assembly)\u0020).Location))
				{
					return ((Assembly)\u0020).Location;
				}
			}
			catch
			{
			}
			try
			{
				if (File.Exists(((Assembly)\u0020).GetName().CodeBase.ToString().Replace("file:///", "")))
				{
					return ((Assembly)\u0020).GetName().CodeBase.ToString().Replace("file:///", "");
				}
			}
			catch
			{
			}
			try
			{
				if (File.Exists(\u0020.GetType().GetProperty("Location").GetValue(\u0020, new object[0]).ToString()))
				{
					return \u0020.GetType().GetProperty("Location").GetValue(\u0020, new object[0]).ToString();
				}
			}
			catch
			{
			}
			return "";
		}

		// Token: 0x06000820 RID: 2080
		[DllImport("kernel32", EntryPoint = "LoadLibrary")]
		public static extern IntPtr rRi5eyQhVu(string \u0020);

		// Token: 0x06000821 RID: 2081
		[DllImport("kernel32", CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress")]
		public static extern IntPtr R2Z5kJAhGZ(IntPtr \u0020, string \u0020);

		// Token: 0x06000822 RID: 2082 RVA: 0x00046CEC File Offset: 0x00044EEC
		private static IntPtr Fve5rAWeKb(IntPtr \u0020, string \u0020, uint \u0020)
		{
			if (vua32v5yjQhjRjK4YIO.CHf1uRY5iT == null)
			{
				vua32v5yjQhjRjK4YIO.CHf1uRY5iT = (vua32v5yjQhjRjK4YIO.O1Mm0Hx3dbSrcitnmCD)Marshal.GetDelegateForFunctionPointer(vua32v5yjQhjRjK4YIO.R2Z5kJAhGZ(vua32v5yjQhjRjK4YIO.pZbnhv6YB(), "Find ".Trim() + "ResourceA"), Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(33554530)));
			}
			return vua32v5yjQhjRjK4YIO.CHf1uRY5iT(\u0020, \u0020, \u0020);
		}

		// Token: 0x06000823 RID: 2083 RVA: 0x00046D4C File Offset: 0x00044F4C
		private static IntPtr s1f57HraGE(IntPtr \u0020, uint \u0020, uint \u0020, uint \u0020)
		{
			if (vua32v5yjQhjRjK4YIO.XJ517srtuJ == null)
			{
				vua32v5yjQhjRjK4YIO.XJ517srtuJ = (vua32v5yjQhjRjK4YIO.f0sdc7xQdmWmvLqDBIn)Marshal.GetDelegateForFunctionPointer(vua32v5yjQhjRjK4YIO.R2Z5kJAhGZ(vua32v5yjQhjRjK4YIO.pZbnhv6YB(), "Virtual ".Trim() + "Alloc"), Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(33554531)));
			}
			return vua32v5yjQhjRjK4YIO.XJ517srtuJ(\u0020, \u0020, \u0020, \u0020);
		}

		// Token: 0x06000824 RID: 2084 RVA: 0x00046DB0 File Offset: 0x00044FB0
		private static int mYp52QU2Q5(IntPtr \u0020, IntPtr \u0020, [In] [Out] byte[] \u0020, uint \u0020, out IntPtr \u0020)
		{
			if (vua32v5yjQhjRjK4YIO.PrY1OKksdd == null)
			{
				vua32v5yjQhjRjK4YIO.PrY1OKksdd = (vua32v5yjQhjRjK4YIO.SNyQ5HxCH60X8KRDBAe)Marshal.GetDelegateForFunctionPointer(vua32v5yjQhjRjK4YIO.R2Z5kJAhGZ(vua32v5yjQhjRjK4YIO.pZbnhv6YB(), "Write ".Trim() + "Process ".Trim() + "Memory"), Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(33554532)));
			}
			return vua32v5yjQhjRjK4YIO.PrY1OKksdd(\u0020, \u0020, \u0020, \u0020, out \u0020);
		}

		// Token: 0x06000825 RID: 2085 RVA: 0x00046E20 File Offset: 0x00045020
		private static int kYK56BKdS7(IntPtr \u0020, int \u0020, int \u0020, ref int \u0020)
		{
			if (vua32v5yjQhjRjK4YIO.HqA1otFDcJ == null)
			{
				vua32v5yjQhjRjK4YIO.HqA1otFDcJ = (vua32v5yjQhjRjK4YIO.HXa62Gx9sx0rQ58QnKb)Marshal.GetDelegateForFunctionPointer(vua32v5yjQhjRjK4YIO.R2Z5kJAhGZ(vua32v5yjQhjRjK4YIO.pZbnhv6YB(), "Virtual ".Trim() + "Protect"), Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(33554533)));
			}
			return vua32v5yjQhjRjK4YIO.HqA1otFDcJ(\u0020, \u0020, \u0020, ref \u0020);
		}

		// Token: 0x06000826 RID: 2086 RVA: 0x00046E84 File Offset: 0x00045084
		private static IntPtr hxx5NkEjE9(uint \u0020, int \u0020, uint \u0020)
		{
			if (vua32v5yjQhjRjK4YIO.J8t1vEcUBI == null)
			{
				vua32v5yjQhjRjK4YIO.J8t1vEcUBI = (vua32v5yjQhjRjK4YIO.pIoGZoxwSRtUIn6Xi8M)Marshal.GetDelegateForFunctionPointer(vua32v5yjQhjRjK4YIO.R2Z5kJAhGZ(vua32v5yjQhjRjK4YIO.pZbnhv6YB(), "Open ".Trim() + "Process"), Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(33554534)));
			}
			return vua32v5yjQhjRjK4YIO.J8t1vEcUBI(\u0020, \u0020, \u0020);
		}

		// Token: 0x06000827 RID: 2087 RVA: 0x00046EE4 File Offset: 0x000450E4
		private static int eAk5nNDgrg(IntPtr \u0020)
		{
			if (vua32v5yjQhjRjK4YIO.D081RjBZ7X == null)
			{
				vua32v5yjQhjRjK4YIO.D081RjBZ7X = (vua32v5yjQhjRjK4YIO.oDAa6ExAnCNOlNnQeLK)Marshal.GetDelegateForFunctionPointer(vua32v5yjQhjRjK4YIO.R2Z5kJAhGZ(vua32v5yjQhjRjK4YIO.pZbnhv6YB(), "Close ".Trim() + "Handle"), Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(33554535)));
			}
			return vua32v5yjQhjRjK4YIO.D081RjBZ7X(\u0020);
		}

		// Token: 0x06000828 RID: 2088 RVA: 0x00046F44 File Offset: 0x00045144
		private static IntPtr pZbnhv6YB()
		{
			if (vua32v5yjQhjRjK4YIO.hyO1NyyabH == IntPtr.Zero)
			{
				vua32v5yjQhjRjK4YIO.hyO1NyyabH = vua32v5yjQhjRjK4YIO.rRi5eyQhVu("kernel ".Trim() + "32.dll");
			}
			return vua32v5yjQhjRjK4YIO.hyO1NyyabH;
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x00046F80 File Offset: 0x00045180
		private static byte[] TAH50F0CkI(string \u0020)
		{
			byte[] array;
			using (FileStream fileStream = new FileStream(\u0020, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				int num = 0;
				int i = (int)fileStream.Length;
				array = new byte[i];
				while (i > 0)
				{
					int num2 = fileStream.Read(array, num, i);
					num += num2;
					i -= num2;
				}
			}
			return array;
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x00046FEC File Offset: 0x000451EC
		internal static Stream S4L5JqKWmW()
		{
			return new MemoryStream();
		}

		// Token: 0x0600082B RID: 2091 RVA: 0x00046FF4 File Offset: 0x000451F4
		internal static byte[] Unf5mbvjVH(Stream \u0020)
		{
			return ((MemoryStream)\u0020).ToArray();
		}

		// Token: 0x0600082C RID: 2092 RVA: 0x00047004 File Offset: 0x00045204
		private static byte[] L145HbaqWw(byte[] \u0020)
		{
			Stream stream = vua32v5yjQhjRjK4YIO.S4L5JqKWmW();
			SymmetricAlgorithm symmetricAlgorithm = vua32v5yjQhjRjK4YIO.LXW5ASdnvZ();
			symmetricAlgorithm.Key = new byte[]
			{
				112,
				53,
				131,
				161,
				105,
				171,
				5,
				48,
				57,
				29,
				15,
				148,
				51,
				33,
				143,
				252,
				175,
				3,
				207,
				213,
				205,
				100,
				153,
				184,
				145,
				227,
				20,
				51,
				153,
				229,
				73,
				127
			};
			symmetricAlgorithm.IV = new byte[]
			{
				100,
				120,
				42,
				159,
				51,
				194,
				188,
				95,
				116,
				182,
				167,
				159,
				98,
				196,
				103,
				75
			};
			CryptoStream cryptoStream = new CryptoStream(stream, symmetricAlgorithm.CreateDecryptor(), CryptoStreamMode.Write);
			cryptoStream.Write(\u0020, 0, \u0020.Length);
			cryptoStream.Close();
			byte[] result = vua32v5yjQhjRjK4YIO.Unf5mbvjVH(stream);
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
			return result;
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x00047078 File Offset: 0x00045278
		private unsafe static int eS35tDtayw(string \u0020)
		{
			char* ptr = \u0020;
			if (ptr != null)
			{
				ptr += RuntimeHelpers.OffsetToStringData / 2;
			}
			int num = 5381;
			int num2 = num;
			char* ptr2 = ptr;
			int num3;
			while ((num3 = (int)(*ptr2)) != 0)
			{
				num = ((num << 5) + num ^ num3);
				num3 = (int)ptr2[1];
				if (num3 == 0)
				{
					break;
				}
				num2 = ((num2 << 5) + num2 ^ num3);
				ptr2 += 2;
			}
			return num + num2 * 1566083941;
		}

		// Token: 0x0600082E RID: 2094 RVA: 0x000470E8 File Offset: 0x000452E8
		internal static bool lUp5Ybtt05(string \u0020, string \u0020)
		{
			if (\u0020 == \u0020)
			{
				return true;
			}
			if (\u0020 == null || \u0020 == null)
			{
				return false;
			}
			bool flag = false;
			bool flag2 = false;
			int num = 0;
			int num2 = 0;
			if (\u0020.StartsWith(vua32v5yjQhjRjK4YIO.WDJ1r9tJFl))
			{
				flag = true;
				num = (int)(\u0020[4] | (int)\u0020[5] << 8 | (int)\u0020[6] << 16 | (int)\u0020[7] << 24);
			}
			if (\u0020.StartsWith(vua32v5yjQhjRjK4YIO.WDJ1r9tJFl))
			{
				flag2 = true;
				num2 = (int)(\u0020[4] | (int)\u0020[5] << 8 | (int)\u0020[6] << 16 | (int)\u0020[7] << 24);
			}
			if (!flag && !flag2)
			{
				return false;
			}
			if (!flag)
			{
				num = vua32v5yjQhjRjK4YIO.eS35tDtayw(\u0020);
			}
			if (!flag2)
			{
				num2 = vua32v5yjQhjRjK4YIO.eS35tDtayw(\u0020);
			}
			return num == num2;
		}

		// Token: 0x0600082F RID: 2095 RVA: 0x000471BC File Offset: 0x000453BC
		private byte[] taS5syhK29()
		{
			return null;
		}

		// Token: 0x06000830 RID: 2096 RVA: 0x000471CC File Offset: 0x000453CC
		private byte[] qTl5g5exEu()
		{
			return null;
		}

		// Token: 0x06000831 RID: 2097 RVA: 0x000471DC File Offset: 0x000453DC
		private byte[] HwS5XZRyxs()
		{
			return null;
		}

		// Token: 0x06000832 RID: 2098 RVA: 0x000471EC File Offset: 0x000453EC
		private byte[] iHa5MuhNF1()
		{
			return null;
		}

		// Token: 0x06000833 RID: 2099 RVA: 0x000471FC File Offset: 0x000453FC
		private byte[] CHq5GKPa8I()
		{
			int length = "{11111-22222-30001-00001}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x0004721C File Offset: 0x0004541C
		private byte[] g2p5Be6OGp()
		{
			int length = "{11111-22222-30001-00002}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x0004723C File Offset: 0x0004543C
		internal byte[] JO85DZWqs5()
		{
			int length = "{11111-22222-40001-00001}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x0004725C File Offset: 0x0004545C
		internal byte[] jQg5vgaiDu()
		{
			int length = "{11111-22222-40001-00002}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x0004727C File Offset: 0x0004547C
		internal byte[] h775j7xLs3()
		{
			int length = "{11111-22222-50001-00001}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x0004729C File Offset: 0x0004549C
		internal byte[] F1D5baYU2c()
		{
			int length = "{11111-22222-50001-00002}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x000472BC File Offset: 0x000454BC
		internal static object KV1imfdeTcsAuvv6l8O(object A_0)
		{
			return A_0.m9OIO8Q0EK();
		}

		// Token: 0x0600083A RID: 2106 RVA: 0x000472C8 File Offset: 0x000454C8
		internal static void GGCjEodkPwgw3PjY4gG(object A_0, long A_1)
		{
			A_0.Position = A_1;
		}

		// Token: 0x0600083B RID: 2107 RVA: 0x000472D8 File Offset: 0x000454D8
		internal static long BRXYDTdrInUBGolv16T(object A_0)
		{
			return A_0.Length;
		}

		// Token: 0x0600083C RID: 2108 RVA: 0x000472E4 File Offset: 0x000454E4
		internal static object eIBtV0d7qUVlHSv70fE(object A_0, int \u0020)
		{
			return A_0.LdQx8niFJo(\u0020);
		}

		// Token: 0x0600083D RID: 2109 RVA: 0x000472F4 File Offset: 0x000454F4
		internal static void ph39VOd2AUhhVsdnXRs(object A_0)
		{
			A_0.DIaxoZpvij();
		}

		// Token: 0x0600083E RID: 2110 RVA: 0x00047300 File Offset: 0x00045500
		internal static void qBfPqXd6j1ffuEWQoVd(object A_0)
		{
			Array.Reverse(A_0);
		}

		// Token: 0x0600083F RID: 2111 RVA: 0x0004730C File Offset: 0x0004550C
		internal static object Q3yPyydNdZCUJRcyOrc(object A_0)
		{
			return A_0.GetName();
		}

		// Token: 0x06000840 RID: 2112 RVA: 0x00047318 File Offset: 0x00045518
		internal static object ESH5fldnhZbfsmUbQyv(object A_0)
		{
			return A_0.GetPublicKeyToken();
		}

		// Token: 0x06000841 RID: 2113 RVA: 0x00047324 File Offset: 0x00045524
		internal static object qOWEY3d0U14kulIeNlq()
		{
			return vua32v5yjQhjRjK4YIO.LXW5ASdnvZ();
		}

		// Token: 0x06000842 RID: 2114 RVA: 0x0004732C File Offset: 0x0004552C
		internal static void mPOkACdJoZlk1eFQiYc(object A_0, CipherMode A_1)
		{
			A_0.Mode = A_1;
		}

		// Token: 0x06000843 RID: 2115 RVA: 0x0004733C File Offset: 0x0004553C
		internal static object iHQ2DCdm4tLEpM0WilE(object A_0, object A_1, object A_2)
		{
			return A_0.CreateDecryptor(A_1, A_2);
		}

		// Token: 0x06000844 RID: 2116 RVA: 0x00047350 File Offset: 0x00045550
		internal static object LpGviydHd77sgXrGOKu()
		{
			return vua32v5yjQhjRjK4YIO.S4L5JqKWmW();
		}

		// Token: 0x06000845 RID: 2117 RVA: 0x00047358 File Offset: 0x00045558
		internal static void vsN8qbdtJN2NWHuqVp6(object A_0, object A_1, int A_2, int A_3)
		{
			A_0.Write(A_1, A_2, A_3);
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x00047370 File Offset: 0x00045570
		internal static void KqNut5dYTCrgbyaTgBt(object A_0)
		{
			A_0.FlushFinalBlock();
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x0004737C File Offset: 0x0004557C
		internal static object Em1pftdstHInbqJXSDZ(object A_0)
		{
			return vua32v5yjQhjRjK4YIO.Unf5mbvjVH(A_0);
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x00047388 File Offset: 0x00045588
		internal static void VkRQPydglMmybUm2b1i(object A_0)
		{
			A_0.Close();
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x00047394 File Offset: 0x00045594
		internal static object uiwtaFdXmxomyR6HmcV(object A_0)
		{
			return A_0.EntryPoint;
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x000473A0 File Offset: 0x000455A0
		internal static bool qFIS0YdMvvDSXZ9C6ku(object A_0, object A_1)
		{
			return A_0 == A_1;
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x000473B0 File Offset: 0x000455B0
		internal static bool SAyjWYdaMrSRnqPpPNd()
		{
			return null == null;
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x000473B8 File Offset: 0x000455B8
		internal static object pPsKX1dK336YgiRvEoI()
		{
			return null;
		}

		// Token: 0x0600084D RID: 2125 RVA: 0x000473BC File Offset: 0x000455BC
		internal static void iZjQCjdDauV1d0GnTWv()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x0600084E RID: 2126 RVA: 0x000473C4 File Offset: 0x000455C4
		internal static void dawOAgdvUuqjjbWDTaU(bool A_0)
		{
			RSACryptoServiceProvider.UseMachineKeyStore = A_0;
		}

		// Token: 0x0600084F RID: 2127 RVA: 0x000473D0 File Offset: 0x000455D0
		internal static Type ygIRMIdjbXoZj6dgO6T(RuntimeTypeHandle A_0)
		{
			return Type.GetTypeFromHandle(A_0);
		}

		// Token: 0x06000850 RID: 2128 RVA: 0x000473DC File Offset: 0x000455DC
		internal static object AHenlOdbvavtMugx1ON(object A_0)
		{
			return A_0.Location;
		}

		// Token: 0x06000851 RID: 2129 RVA: 0x000473E8 File Offset: 0x000455E8
		internal static int uoODVLdzZs48oqPoF63(object A_0)
		{
			return A_0.Length;
		}

		// Token: 0x06000852 RID: 2130 RVA: 0x000473F4 File Offset: 0x000455F4
		internal static object FVtb4FoWs0TTSExT7Hi()
		{
			return SHA1.Create();
		}

		// Token: 0x06000853 RID: 2131 RVA: 0x000473FC File Offset: 0x000455FC
		internal static object BBTCguoPg8cL5mR7sdI(object A_0)
		{
			return CryptoConfig.MapNameToOID(A_0);
		}

		// Token: 0x06000854 RID: 2132 RVA: 0x00047408 File Offset: 0x00045608
		internal static bool PA0DhEoEXqWUel9xPGu(object A_0)
		{
			return File.Exists(A_0);
		}

		// Token: 0x06000855 RID: 2133 RVA: 0x00047414 File Offset: 0x00045614
		internal static object Hin79Zocp5A5DPUwSWS(object A_0, object A_1)
		{
			return A_0.GetManifestResourceStream(A_1);
		}

		// Token: 0x06000856 RID: 2134 RVA: 0x00047424 File Offset: 0x00045624
		internal static object VnwbqMo55K1wHepas1k(object A_0)
		{
			return A_0.m9OIO8Q0EK();
		}

		// Token: 0x06000857 RID: 2135 RVA: 0x00047430 File Offset: 0x00045630
		internal static void cnVmRlox9cJSRVHsZPP(object A_0, long A_1)
		{
			A_0.Position = A_1;
		}

		// Token: 0x06000858 RID: 2136 RVA: 0x00047440 File Offset: 0x00045640
		internal static long PdhlkVouTLGyE0QRO6r(object A_0)
		{
			return A_0.Length;
		}

		// Token: 0x06000859 RID: 2137 RVA: 0x0004744C File Offset: 0x0004564C
		internal static object tnfD0JoVuAd0GalwTms(object A_0, int \u0020)
		{
			return A_0.LdQx8niFJo(\u0020);
		}

		// Token: 0x0600085A RID: 2138 RVA: 0x0004745C File Offset: 0x0004565C
		internal static object CMkaqcoykBdflPLW2fB()
		{
			return vua32v5yjQhjRjK4YIO.LXW5ASdnvZ();
		}

		// Token: 0x0600085B RID: 2139 RVA: 0x00047464 File Offset: 0x00045664
		internal static void kSh0iJo8UjBOk1eG7LK(object A_0, CipherMode A_1)
		{
			A_0.Mode = A_1;
		}

		// Token: 0x0600085C RID: 2140 RVA: 0x00047474 File Offset: 0x00045674
		internal static object ooeOmcoqkvAGqTvDpI4(object A_0, object A_1, object A_2)
		{
			return A_0.CreateDecryptor(A_1, A_2);
		}

		// Token: 0x0600085D RID: 2141 RVA: 0x00047488 File Offset: 0x00045688
		internal static object krEeFRod4g8ANYMWNQt()
		{
			return vua32v5yjQhjRjK4YIO.S4L5JqKWmW();
		}

		// Token: 0x0600085E RID: 2142 RVA: 0x00047490 File Offset: 0x00045690
		internal static void Agyx3foo3DAm8f7N1hN(object A_0, object A_1, int A_2, int A_3)
		{
			A_0.Write(A_1, A_2, A_3);
		}

		// Token: 0x0600085F RID: 2143 RVA: 0x000474A8 File Offset: 0x000456A8
		internal static void fS7wRro301mtHpZNSsC(object A_0)
		{
			A_0.FlushFinalBlock();
		}

		// Token: 0x06000860 RID: 2144 RVA: 0x000474B4 File Offset: 0x000456B4
		internal static object BjVdxyoQVmPSxkSjafs()
		{
			return Encoding.UTF8;
		}

		// Token: 0x06000861 RID: 2145 RVA: 0x000474BC File Offset: 0x000456BC
		internal static object MKTMTMoCkqotWMrgaHF(object A_0)
		{
			return vua32v5yjQhjRjK4YIO.Unf5mbvjVH(A_0);
		}

		// Token: 0x06000862 RID: 2146 RVA: 0x000474C8 File Offset: 0x000456C8
		internal static object C6q0Ilo9U0SoWudv0PW(object A_0, object A_1)
		{
			return A_0.GetString(A_1);
		}

		// Token: 0x06000863 RID: 2147 RVA: 0x000474D8 File Offset: 0x000456D8
		internal static void RTIeNjowDqMoQ8CRIlb(object A_0, object A_1)
		{
			A_0.FromXmlString(A_1);
		}

		// Token: 0x06000864 RID: 2148 RVA: 0x000474E8 File Offset: 0x000456E8
		internal static void XUXX14oAnoygn8KS3nA(object A_0)
		{
			A_0.Close();
		}

		// Token: 0x06000865 RID: 2149 RVA: 0x000474F4 File Offset: 0x000456F4
		internal static void Uoj6efohobKjsSLyb1Q(object A_0)
		{
			A_0.DIaxoZpvij();
		}

		// Token: 0x06000866 RID: 2150 RVA: 0x00047500 File Offset: 0x00045700
		internal static void kf8oJqoSTlcuodB5Teu(object A_0, object A_1, uint \u0020, object A_3)
		{
			vua32v5yjQhjRjK4YIO.pKF5IPBFtn(A_0, A_1, \u0020, A_3);
		}

		// Token: 0x06000867 RID: 2151 RVA: 0x00047518 File Offset: 0x00045718
		internal static ushort rLWmHJoIOjUjyry637F(object A_0)
		{
			return A_0.ReadUInt16();
		}

		// Token: 0x06000868 RID: 2152 RVA: 0x00047524 File Offset: 0x00045724
		internal static int sT1PdIoidHmANIkcpaW(object A_0, object A_1, int A_2, int A_3)
		{
			return A_0.Read(A_1, A_2, A_3);
		}

		// Token: 0x06000869 RID: 2153 RVA: 0x0004753C File Offset: 0x0004573C
		internal static void wYUQE2oZdWaYWfLbNNN(object A_0, object A_1, int \u0020, int \u0020)
		{
			vua32v5yjQhjRjK4YIO.TnZ5iY18oG(A_0, A_1, \u0020, \u0020);
		}

		// Token: 0x0600086A RID: 2154 RVA: 0x00047554 File Offset: 0x00045754
		internal static long iaSWcSoUHi57GCkO7up(object A_0)
		{
			return A_0.Position;
		}

		// Token: 0x0600086B RID: 2155 RVA: 0x00047560 File Offset: 0x00045760
		internal static uint x4yEtRo1sjiuBGLdWag(object A_0)
		{
			return A_0.ReadUInt32();
		}

		// Token: 0x0600086C RID: 2156 RVA: 0x0004756C File Offset: 0x0004576C
		internal static uint i4DLcBop40cOBck10DF(uint \u0020, int \u0020, long \u0020, object A_3)
		{
			return vua32v5yjQhjRjK4YIO.qC25ZNKulF(\u0020, \u0020, \u0020, A_3);
		}

		// Token: 0x0600086D RID: 2157 RVA: 0x00047584 File Offset: 0x00045784
		internal static long pYcZAco4CtLVof5dk9v(long A_0, long A_1)
		{
			return Math.Min(A_0, A_1);
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x00047594 File Offset: 0x00045794
		internal static object ChQvCWoONmQTsXD4yGa(object A_0, object A_1, int A_2, int A_3)
		{
			return A_0.TransformFinalBlock(A_1, A_2, A_3);
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x000475AC File Offset: 0x000457AC
		internal static object OFvD0PofQ8pQnRTtjYU(object A_0, int A_1)
		{
			return A_0.ReadBytes(A_1);
		}

		// Token: 0x06000870 RID: 2160 RVA: 0x000475BC File Offset: 0x000457BC
		internal static void bRsgsqoFipU8MAMAF24(object A_0)
		{
			Array.Reverse(A_0);
		}

		// Token: 0x06000871 RID: 2161 RVA: 0x000475C8 File Offset: 0x000457C8
		internal static object WWqgbSoTWLab5fyJC78(object A_0)
		{
			return A_0.Hash;
		}

		// Token: 0x06000872 RID: 2162 RVA: 0x000475D4 File Offset: 0x000457D4
		internal static bool MZJ9IHoRrudNNlB7JkZ(object A_0, object A_1, object A_2, object A_3)
		{
			return A_0.VerifyHash(A_1, A_2, A_3);
		}

		// Token: 0x06000873 RID: 2163 RVA: 0x000475EC File Offset: 0x000457EC
		internal static void kCdVCPoLg0VWVIk6a6g(object A_0)
		{
			A_0.Close();
		}

		// Token: 0x06000874 RID: 2164 RVA: 0x000475F8 File Offset: 0x000457F8
		internal static object KZyxO3olnOmgHZ8xUnI(object A_0)
		{
			return A_0.GetName();
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x00047604 File Offset: 0x00045804
		internal static object MggiEfoa8jeIA7DoFmk(object A_0)
		{
			return A_0.Name;
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x00047610 File Offset: 0x00045810
		internal static object PAQMINoKrt3MVIJOZ4M(object A_0, object A_1)
		{
			return A_0 + A_1;
		}

		// Token: 0x06000877 RID: 2167 RVA: 0x00047620 File Offset: 0x00045820
		internal static bool IH2h7bdGhq6PqvDfeTR()
		{
			return null == null;
		}

		// Token: 0x06000878 RID: 2168 RVA: 0x00047628 File Offset: 0x00045828
		internal static object NCA9UGdB5vtOVh5O2cs()
		{
			return null;
		}

		// Token: 0x0400036D RID: 877
		private static IntPtr ueQ1CBZqwr;

		// Token: 0x0400036E RID: 878
		private static int VyN15LqlEh;

		// Token: 0x0400036F RID: 879
		private static long CoD1QZV1a1;

		// Token: 0x04000370 RID: 880
		[vua32v5yjQhjRjK4YIO.cNOY9qxWlDplbd6cKKd(typeof(vua32v5yjQhjRjK4YIO.cNOY9qxWlDplbd6cKKd.EQVVtxxP8PwZTLcbnHB<object>[]))]
		private static bool firstrundone;

		// Token: 0x04000371 RID: 881
		internal static Hashtable BSI1ZLPHr8;

		// Token: 0x04000372 RID: 882
		private static object bYc11bZ2yR;

		// Token: 0x04000373 RID: 883
		private static vua32v5yjQhjRjK4YIO.SNyQ5HxCH60X8KRDBAe PrY1OKksdd;

		// Token: 0x04000374 RID: 884
		private static bool VIl2UgjvI;

		// Token: 0x04000375 RID: 885
		private static List<int> BV01muBIf0;

		// Token: 0x04000376 RID: 886
		private static bool QxN19ECe8h;

		// Token: 0x04000377 RID: 887
		private static bool mhL1hZ6InY;

		// Token: 0x04000378 RID: 888
		private static int fKU1wiJQGY;

		// Token: 0x04000379 RID: 889
		private static uint[] U6XE6mvyw;

		// Token: 0x0400037A RID: 890
		internal static vua32v5yjQhjRjK4YIO.kmElpExx7qw4J50uBZY XBV1llcJHV;

		// Token: 0x0400037B RID: 891
		private static bool GJ23VPZUC;

		// Token: 0x0400037C RID: 892
		private static byte[] QRR1YKfBNJ;

		// Token: 0x0400037D RID: 893
		internal static vua32v5yjQhjRjK4YIO.kmElpExx7qw4J50uBZY iBN1U8RgNG;

		// Token: 0x0400037E RID: 894
		private static vua32v5yjQhjRjK4YIO.oDAa6ExAnCNOlNnQeLK D081RjBZ7X;

		// Token: 0x0400037F RID: 895
		private static vua32v5yjQhjRjK4YIO.f0sdc7xQdmWmvLqDBIn XJ517srtuJ;

		// Token: 0x04000380 RID: 896
		private static vua32v5yjQhjRjK4YIO.pIoGZoxwSRtUIn6Xi8M J8t1vEcUBI;

		// Token: 0x04000381 RID: 897
		private static int Pgs1HOBEQA;

		// Token: 0x04000382 RID: 898
		private static string WDJ1r9tJFl;

		// Token: 0x04000383 RID: 899
		private static int[] Syr1aJSCyW;

		// Token: 0x04000384 RID: 900
		private static bool uU3JCB0s8 = false;

		// Token: 0x04000385 RID: 901
		private static IntPtr hyO1NyyabH;

		// Token: 0x04000386 RID: 902
		private static SortedList uFW1iZApx1;

		// Token: 0x04000387 RID: 903
		private static long X4h1A928yN;

		// Token: 0x04000388 RID: 904
		private static object t8Q1fis8nb;

		// Token: 0x04000389 RID: 905
		private static vua32v5yjQhjRjK4YIO.O1Mm0Hx3dbSrcitnmCD CHf1uRY5iT;

		// Token: 0x0400038A RID: 906
		private static vua32v5yjQhjRjK4YIO.HXa62Gx9sx0rQ58QnKb HqA1otFDcJ;

		// Token: 0x0400038B RID: 907
		private static int RYG1kecuXB;

		// Token: 0x0400038C RID: 908
		private static object BiA1jH0AoM;

		// Token: 0x0400038D RID: 909
		private static IntPtr lQu18GAsIh;

		// Token: 0x0400038E RID: 910
		private static bool atZ1SSejVu;

		// Token: 0x0400038F RID: 911
		private static byte[] lRG1gLlTer;

		// Token: 0x04000390 RID: 912
		private static Dictionary<int, int> pAL10SKCoC;

		// Token: 0x04000391 RID: 913
		internal static RSACryptoServiceProvider EXHzxLTGx;

		// Token: 0x04000392 RID: 914
		private static IntPtr WB11tRIZxP;

		// Token: 0x04000393 RID: 915
		internal static Assembly QDHV0iQKg = Type.GetTypeFromHandle(MQ9uG3xi8RURJ9Fop2C.VO20CqLVtC(33554521)).Assembly;

		// Token: 0x04000394 RID: 916
		private static int SDV1d6LAgj;

		// Token: 0x04000395 RID: 917
		private static List<string> RaA1I3e0cE;

		// Token: 0x0200005A RID: 90
		// (Invoke) Token: 0x0600087A RID: 2170
		private delegate void KwCn5k5zcimCoLVRGm7(object o);

		// Token: 0x0200005B RID: 91
		internal class cNOY9qxWlDplbd6cKKd : Attribute
		{
			// Token: 0x0600087D RID: 2173 RVA: 0x0004762C File Offset: 0x0004582C
			public cNOY9qxWlDplbd6cKKd(object \u0020)
			{
			}

			// Token: 0x0200005C RID: 92
			internal class EQVVtxxP8PwZTLcbnHB<fKI2GwxEAsDTdquaYs1>
			{
				// Token: 0x0600087E RID: 2174 RVA: 0x0004763C File Offset: 0x0004583C
				public EQVVtxxP8PwZTLcbnHB()
				{
					vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
					PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
					base..ctor();
					int num = 0;
					if (!false)
					{
						num = 0;
					}
					switch (num)
					{
					default:
						return;
					}
				}

				// Token: 0x0600087F RID: 2175 RVA: 0x00047698 File Offset: 0x00045898
				// Note: this type is marked as 'beforefieldinit'.
				static EQVVtxxP8PwZTLcbnHB()
				{
					vua32v5yjQhjRjK4YIO.aep5UvAyyY();
				}

				// Token: 0x06000880 RID: 2176 RVA: 0x000476A8 File Offset: 0x000458A8
				internal static bool NaxHHvlhJaSsUEnivNB()
				{
					return vua32v5yjQhjRjK4YIO.cNOY9qxWlDplbd6cKKd.EQVVtxxP8PwZTLcbnHB<fKI2GwxEAsDTdquaYs1>.rYODlclAw6bkrMpokqN == null;
				}

				// Token: 0x06000881 RID: 2177 RVA: 0x000476BC File Offset: 0x000458BC
				internal static object lkXh0ZlSEta0ILObFdg()
				{
					return vua32v5yjQhjRjK4YIO.cNOY9qxWlDplbd6cKKd.EQVVtxxP8PwZTLcbnHB<fKI2GwxEAsDTdquaYs1>.rYODlclAw6bkrMpokqN;
				}

				// Token: 0x04000396 RID: 918
				private static object rYODlclAw6bkrMpokqN;
			}
		}

		// Token: 0x0200005D RID: 93
		internal class BiUZ1YxcuWyJnNOdvJ6
		{
			// Token: 0x06000882 RID: 2178 RVA: 0x000476CC File Offset: 0x000458CC
			internal static string S0xx5lyMHk(string \u0020, string \u0020)
			{
				byte[] array = vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.yLRjvBl1IeEQvCZHavZ(vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.esJSL2lUUZVSLGhY5AN(), \u0020);
				byte[] array2 = new byte[32];
				vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.zACXpElpKnxlosMwAYC(array2, fieldof(<PrivateImplementationDetails>{3B680954-DC6D-4553-B595-BA81E4D1ED23}.C356AFF1A01C2B0DA472E584C8E3C8F875B9A24280435D42836A77B19F5A8C18).FieldHandle);
				byte[] array3 = array2;
				byte[] array4 = vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.i2E1Jyl422YKbypyCGr(vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.yLRjvBl1IeEQvCZHavZ(Encoding.Unicode, \u0020));
				MemoryStream memoryStream = new MemoryStream();
				SymmetricAlgorithm symmetricAlgorithm = vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.fSxPJ5lOHVUFIJIU6MO();
				vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.U6WNRHlfYRxSAahFBJ7(symmetricAlgorithm, array3);
				vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.V1jd8qlFfyDLq5HwUMn(symmetricAlgorithm, array4);
				CryptoStream cryptoStream = new CryptoStream(memoryStream, vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.dIcJoUlTRgghOyC7LwR(symmetricAlgorithm), CryptoStreamMode.Write);
				vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.PCsKpglRnEkNeYFaX3R(cryptoStream, array, 0, array.Length);
				vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.IPM36ulLcYylodc4xaf(cryptoStream);
				return vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.UOrgJtlaf2fFH6no1qK(vua32v5yjQhjRjK4YIO.BiUZ1YxcuWyJnNOdvJ6.OHS18XlloGBtZouwpW3(memoryStream));
			}

			// Token: 0x06000884 RID: 2180 RVA: 0x00047760 File Offset: 0x00045960
			internal static object esJSL2lUUZVSLGhY5AN()
			{
				return Encoding.Unicode;
			}

			// Token: 0x06000885 RID: 2181 RVA: 0x00047770 File Offset: 0x00045970
			internal static object yLRjvBl1IeEQvCZHavZ(object A_0, object A_1)
			{
				return A_0.GetBytes(A_1);
			}

			// Token: 0x06000886 RID: 2182 RVA: 0x00047788 File Offset: 0x00045988
			internal static void zACXpElpKnxlosMwAYC(object A_0, RuntimeFieldHandle A_1)
			{
				RuntimeHelpers.InitializeArray(A_0, A_1);
			}

			// Token: 0x06000887 RID: 2183 RVA: 0x000477A0 File Offset: 0x000459A0
			internal static object i2E1Jyl422YKbypyCGr(object A_0)
			{
				return vua32v5yjQhjRjK4YIO.LxG5S2Hn4o(A_0);
			}

			// Token: 0x06000888 RID: 2184 RVA: 0x000477B4 File Offset: 0x000459B4
			internal static object fSxPJ5lOHVUFIJIU6MO()
			{
				return vua32v5yjQhjRjK4YIO.LXW5ASdnvZ();
			}

			// Token: 0x06000889 RID: 2185 RVA: 0x000477C4 File Offset: 0x000459C4
			internal static void U6WNRHlfYRxSAahFBJ7(object A_0, object A_1)
			{
				A_0.Key = A_1;
			}

			// Token: 0x0600088A RID: 2186 RVA: 0x000477DC File Offset: 0x000459DC
			internal static void V1jd8qlFfyDLq5HwUMn(object A_0, object A_1)
			{
				A_0.IV = A_1;
			}

			// Token: 0x0600088B RID: 2187 RVA: 0x000477F4 File Offset: 0x000459F4
			internal static object dIcJoUlTRgghOyC7LwR(object A_0)
			{
				return A_0.CreateEncryptor();
			}

			// Token: 0x0600088C RID: 2188 RVA: 0x00047808 File Offset: 0x00045A08
			internal static void PCsKpglRnEkNeYFaX3R(object A_0, object A_1, int A_2, int A_3)
			{
				A_0.Write(A_1, A_2, A_3);
			}

			// Token: 0x0600088D RID: 2189 RVA: 0x00047828 File Offset: 0x00045A28
			internal static void IPM36ulLcYylodc4xaf(object A_0)
			{
				A_0.Close();
			}

			// Token: 0x0600088E RID: 2190 RVA: 0x0004783C File Offset: 0x00045A3C
			internal static object OHS18XlloGBtZouwpW3(object A_0)
			{
				return A_0.ToArray();
			}

			// Token: 0x0600088F RID: 2191 RVA: 0x00047850 File Offset: 0x00045A50
			internal static object UOrgJtlaf2fFH6no1qK(object A_0)
			{
				return Convert.ToBase64String(A_0);
			}
		}

		// Token: 0x0200005E RID: 94
		// (Invoke) Token: 0x06000891 RID: 2193
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		internal delegate uint kmElpExx7qw4J50uBZY(IntPtr classthis, IntPtr comp, IntPtr info, [MarshalAs(UnmanagedType.U4)] uint flags, IntPtr nativeEntry, ref uint nativeSizeOfCode);

		// Token: 0x0200005F RID: 95
		// (Invoke) Token: 0x06000895 RID: 2197
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr cOGXYqxuqusFPv0tJD8();

		// Token: 0x02000060 RID: 96
		internal struct Hg2egWxVhLa2V3CMtWV
		{
			// Token: 0x04000397 RID: 919
			internal bool MoXISnUino;

			// Token: 0x04000398 RID: 920
			internal byte[] SvYIkqaRc9;
		}

		// Token: 0x02000061 RID: 97
		internal class jsNEGrxyc7c7MqjFUgf
		{
			// Token: 0x06000898 RID: 2200 RVA: 0x00047864 File Offset: 0x00045A64
			public jsNEGrxyc7c7MqjFUgf(Stream \u0020)
			{
				this.PTIIvZJmfC = new BinaryReader(\u0020);
			}

			// Token: 0x06000899 RID: 2201 RVA: 0x00047880 File Offset: 0x00045A80
			internal Stream m9OIO8Q0EK()
			{
				return vua32v5yjQhjRjK4YIO.jsNEGrxyc7c7MqjFUgf.EVjAhTl6KDkvF5hjm7K(this.PTIIvZJmfC);
			}

			// Token: 0x0600089A RID: 2202 RVA: 0x00047894 File Offset: 0x00045A94
			internal byte[] LdQx8niFJo(int \u0020)
			{
				return vua32v5yjQhjRjK4YIO.jsNEGrxyc7c7MqjFUgf.mZdAbilNLyTs7MDKqAs(this.PTIIvZJmfC, \u0020);
			}

			// Token: 0x0600089B RID: 2203 RVA: 0x000478AC File Offset: 0x00045AAC
			internal int VLRxqVOcxZ(byte[] \u0020, int \u0020, int \u0020)
			{
				return vua32v5yjQhjRjK4YIO.jsNEGrxyc7c7MqjFUgf.XnFVZolnJ98ARm1cX9I(this.PTIIvZJmfC, \u0020, \u0020, \u0020);
			}

			// Token: 0x0600089C RID: 2204 RVA: 0x000478C4 File Offset: 0x00045AC4
			internal int TiuxdQCTyx()
			{
				return this.PTIIvZJmfC.ReadInt32();
			}

			// Token: 0x0600089D RID: 2205 RVA: 0x000478D8 File Offset: 0x00045AD8
			internal void DIaxoZpvij()
			{
				vua32v5yjQhjRjK4YIO.jsNEGrxyc7c7MqjFUgf.TSLmJxl0E52fnvQ5ysY(this.PTIIvZJmfC);
			}

			// Token: 0x0600089E RID: 2206 RVA: 0x000478EC File Offset: 0x00045AEC
			internal static object EVjAhTl6KDkvF5hjm7K(object A_0)
			{
				return A_0.BaseStream;
			}

			// Token: 0x0600089F RID: 2207 RVA: 0x00047900 File Offset: 0x00045B00
			internal static object mZdAbilNLyTs7MDKqAs(object A_0, int A_1)
			{
				return A_0.ReadBytes(A_1);
			}

			// Token: 0x060008A0 RID: 2208 RVA: 0x00047918 File Offset: 0x00045B18
			internal static int XnFVZolnJ98ARm1cX9I(object A_0, object A_1, int A_2, int A_3)
			{
				return A_0.Read(A_1, A_2, A_3);
			}

			// Token: 0x060008A1 RID: 2209 RVA: 0x00047938 File Offset: 0x00045B38
			internal static void TSLmJxl0E52fnvQ5ysY(object A_0)
			{
				A_0.Close();
			}

			// Token: 0x04000399 RID: 921
			private BinaryReader PTIIvZJmfC;
		}

		// Token: 0x02000062 RID: 98
		// (Invoke) Token: 0x060008A3 RID: 2211
		[UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Ansi)]
		private delegate IntPtr O1Mm0Hx3dbSrcitnmCD(IntPtr hModule, string lpName, uint lpType);

		// Token: 0x02000063 RID: 99
		// (Invoke) Token: 0x060008A7 RID: 2215
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr f0sdc7xQdmWmvLqDBIn(IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

		// Token: 0x02000064 RID: 100
		// (Invoke) Token: 0x060008AB RID: 2219
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int SNyQ5HxCH60X8KRDBAe(IntPtr hProcess, IntPtr lpBaseAddress, [In] [Out] byte[] buffer, uint size, out IntPtr lpNumberOfBytesWritten);

		// Token: 0x02000065 RID: 101
		// (Invoke) Token: 0x060008AF RID: 2223
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int HXa62Gx9sx0rQ58QnKb(IntPtr lpAddress, int dwSize, int flNewProtect, ref int lpflOldProtect);

		// Token: 0x02000066 RID: 102
		// (Invoke) Token: 0x060008B3 RID: 2227
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr pIoGZoxwSRtUIn6Xi8M(uint dwDesiredAccess, int bInheritHandle, uint dwProcessId);

		// Token: 0x02000067 RID: 103
		// (Invoke) Token: 0x060008B7 RID: 2231
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int oDAa6ExAnCNOlNnQeLK(IntPtr ptr);

		// Token: 0x02000068 RID: 104
		[Flags]
		private enum i6IGfJxhEQreFkjitKN
		{

		}
	}
}
