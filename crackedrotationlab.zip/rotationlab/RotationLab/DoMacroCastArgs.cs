﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine
{
	// Token: 0x0200001C RID: 28
	public class DoMacroCastArgs : EventArgs
	{
		// Token: 0x17000012 RID: 18
		// (get) Token: 0x060000BF RID: 191 RVA: 0x000050E8 File Offset: 0x000032E8
		// (set) Token: 0x060000C0 RID: 192 RVA: 0x000050F8 File Offset: 0x000032F8
		public string MacroName { get; private set; }

		// Token: 0x060000C1 RID: 193 RVA: 0x00005114 File Offset: 0x00003314
		public DoMacroCastArgs(string macroName)
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
			DoMacroCastArgs.TCoPVWQM8I5D76yAikC();
			base..ctor();
			int num = 1;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_78ab67cec1824b2289ca2a9b24f27de2 == 0)
			{
				num = 1;
			}
			for (;;)
			{
				switch (num)
				{
				case 1:
					this.MacroName = macroName;
					num = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_82ef02aa8b754adb8434f8a772d183e3 == 0)
					{
						num = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x00005198 File Offset: 0x00003398
		// Note: this type is marked as 'beforefieldinit'.
		static DoMacroCastArgs()
		{
			DoMacroCastArgs.RqFP5NQGmuSxkymXrlY();
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x000051A8 File Offset: 0x000033A8
		internal static bool j1mB3oQgH2TUqVf0uFK()
		{
			return DoMacroCastArgs.rYtIpAQsWkltOwXonx3 == null;
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x000051BC File Offset: 0x000033BC
		internal static DoMacroCastArgs KqSGJPQXj8bJkJOrgii()
		{
			return DoMacroCastArgs.rYtIpAQsWkltOwXonx3;
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x000051CC File Offset: 0x000033CC
		internal static void TCoPVWQM8I5D76yAikC()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x000051DC File Offset: 0x000033DC
		internal static void RqFP5NQGmuSxkymXrlY()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x040000F6 RID: 246
		internal static DoMacroCastArgs rYtIpAQsWkltOwXonx3;
	}
}
