﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;

namespace RotationLabEngine
{
	// Token: 0x02000033 RID: 51
	public static class Convenant
	{
		// Token: 0x06000545 RID: 1349 RVA: 0x0002D074 File Offset: 0x0002B274
		// Note: this type is marked as 'beforefieldinit'.
		static Convenant()
		{
			Convenant.QvEIam4SavZpVT3h9UB();
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x0002D084 File Offset: 0x0002B284
		internal static void QvEIam4SavZpVT3h9UB()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x040001E9 RID: 489
		public const int None = 0;

		// Token: 0x040001EA RID: 490
		public const int Kyrian = 1;

		// Token: 0x040001EB RID: 491
		public const int Venthyr = 2;

		// Token: 0x040001EC RID: 492
		public const int NightFae = 3;

		// Token: 0x040001ED RID: 493
		public const int Necrolord = 4;
	}
}
