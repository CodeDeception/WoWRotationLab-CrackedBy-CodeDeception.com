﻿using System;

namespace wKolMkxZecDx58YaRR4
{
	// Token: 0x0200006A RID: 106
	internal class MQ9uG3xi8RURJ9Fop2C
	{
		// Token: 0x060008BC RID: 2236 RVA: 0x00047968 File Offset: 0x00045B68
		internal static RuntimeTypeHandle VO20CqLVtC(int token)
		{
			return MQ9uG3xi8RURJ9Fop2C.xmH1PT3UVY.GetRuntimeTypeHandleFromMetadataToken(token);
		}

		// Token: 0x060008BD RID: 2237 RVA: 0x0004797C File Offset: 0x00045B7C
		internal static RuntimeFieldHandle c4Y09CE49o(int token)
		{
			return MQ9uG3xi8RURJ9Fop2C.xmH1PT3UVY.GetRuntimeFieldHandleFromMetadataToken(token);
		}

		// Token: 0x060008C0 RID: 2240 RVA: 0x000479D4 File Offset: 0x00045BD4
		internal static bool kLmRDQlXLnNCRooTKfy()
		{
			return MQ9uG3xi8RURJ9Fop2C.T2xsdXlgKvUPTvcqDdh == null;
		}

		// Token: 0x060008C1 RID: 2241 RVA: 0x000479E8 File Offset: 0x00045BE8
		internal static MQ9uG3xi8RURJ9Fop2C bTnydOlMxgw5GMxn0Fj()
		{
			return MQ9uG3xi8RURJ9Fop2C.T2xsdXlgKvUPTvcqDdh;
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x000479F8 File Offset: 0x00045BF8
		internal static ModuleHandle FyF0uWlGyhugK4hdxvH(object A_0)
		{
			return A_0.ModuleHandle;
		}

		// Token: 0x0400039C RID: 924
		internal static ModuleHandle xmH1PT3UVY = MQ9uG3xi8RURJ9Fop2C.FyF0uWlGyhugK4hdxvH(typeof(MQ9uG3xi8RURJ9Fop2C).Assembly.GetModules()[0]);

		// Token: 0x0400039D RID: 925
		internal static MQ9uG3xi8RURJ9Fop2C T2xsdXlgKvUPTvcqDdh;
	}
}
