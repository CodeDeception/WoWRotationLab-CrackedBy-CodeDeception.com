﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine
{
	// Token: 0x0200003E RID: 62
	public class SpellInformation
	{
		// Token: 0x06000579 RID: 1401 RVA: 0x0002D6C4 File Offset: 0x0002B8C4
		public SpellInformation()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
			SpellInformation.uTuFSB4zKIJ9gORhgjK();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_24c6414a8a5b4f2680c42f1a5855f977 != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x0002D724 File Offset: 0x0002B924
		// Note: this type is marked as 'beforefieldinit'.
		static SpellInformation()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x0002D734 File Offset: 0x0002B934
		internal static void uTuFSB4zKIJ9gORhgjK()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x0002D744 File Offset: 0x0002B944
		internal static bool rXAPB54ji4pSGaNFQHU()
		{
			return SpellInformation.rbrdMK4vRcj2Gqv3pbQ == null;
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x0002D758 File Offset: 0x0002B958
		internal static SpellInformation pMXc994bWf1JUiEUqsh()
		{
			return SpellInformation.rbrdMK4vRcj2Gqv3pbQ;
		}

		// Token: 0x04000257 RID: 599
		public int Index;

		// Token: 0x04000258 RID: 600
		public bool Usable;

		// Token: 0x04000259 RID: 601
		public bool NoMana;

		// Token: 0x0400025A RID: 602
		public int CooldownRemaining;

		// Token: 0x0400025B RID: 603
		public int ChargeCurrent;

		// Token: 0x0400025C RID: 604
		public int ChargeMax;

		// Token: 0x0400025D RID: 605
		public int ChargeCooldownRemaining;

		// Token: 0x0400025E RID: 606
		public int ChargeTime;

		// Token: 0x0400025F RID: 607
		public bool IsInRange;

		// Token: 0x04000260 RID: 608
		private static SpellInformation rbrdMK4vRcj2Gqv3pbQ;
	}
}
