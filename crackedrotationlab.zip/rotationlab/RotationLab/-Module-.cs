﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using xDwZPux4SDqHCadp1SC;

// Token: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	static <Module>()
	{
		vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		<Module>.b6ePoZo7Iup0ni6NAiv();
	}

	// Token: 0x06000002 RID: 2 RVA: 0x00002064 File Offset: 0x00000264
	internal static void b6ePoZo7Iup0ni6NAiv()
	{
		g7nourxp055gaU44Yrc.lLHifFIsCLsZtjvFfN0i();
	}
}
