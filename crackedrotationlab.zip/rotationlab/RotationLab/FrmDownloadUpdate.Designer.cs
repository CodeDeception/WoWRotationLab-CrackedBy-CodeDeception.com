﻿namespace RotationLabEngine
{
	// Token: 0x0200002A RID: 42
	public partial class FrmDownloadUpdate : global::System.Windows.Forms.Form
	{
		// Token: 0x0600049B RID: 1179 RVA: 0x00029DD0 File Offset: 0x00027FD0
		protected override void Dispose(bool disposing)
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					break;
				case 2:
					if (this.components != null)
					{
						global::RotationLabEngine.FrmDownloadUpdate.FhhmdSpqIxYAdNacYKr(this.components);
						num2 = 1;
						if (global::<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_37a20c2e025c4269a91da4cf2ed7e3df == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				case 3:
					if (disposing)
					{
						num2 = 0;
						if (global::<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_d6675f44e192471dbaeaf2d22fed78ae != 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					}
					break;
				}
				base.Dispose(disposing);
				num2 = 0;
				if (global::<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_226f95e821ae480585438175bbddf9be != 0)
				{
					num2 = 0;
				}
			}
		}

		// Token: 0x040001BB RID: 443
		private global::System.ComponentModel.IContainer components;
	}
}
