﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;

namespace RotationLabEngine
{
	// Token: 0x02000018 RID: 24
	public static class AutoBind
	{
		// Token: 0x060000A6 RID: 166 RVA: 0x00004DD0 File Offset: 0x00002FD0
		// Note: this type is marked as 'beforefieldinit'.
		static AutoBind()
		{
			AutoBind.t5sfFkQK1QImmevY1A3();
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x00004DE0 File Offset: 0x00002FE0
		internal static void t5sfFkQK1QImmevY1A3()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}
	}
}
