﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine
{
	// Token: 0x02000040 RID: 64
	public class ItemInformation
	{
		// Token: 0x06000584 RID: 1412 RVA: 0x0002D81C File Offset: 0x0002BA1C
		public ItemInformation()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_1259d5d4e4144ef5a0c05f808ad73078 == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x06000585 RID: 1413 RVA: 0x0002D87C File Offset: 0x0002BA7C
		// Note: this type is marked as 'beforefieldinit'.
		static ItemInformation()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x06000586 RID: 1414 RVA: 0x0002D88C File Offset: 0x0002BA8C
		internal static bool NlNK3lOuRYoxJbDlMi3()
		{
			return ItemInformation.H3n3L2Ox7qZgUkvSbVF == null;
		}

		// Token: 0x06000587 RID: 1415 RVA: 0x0002D8A0 File Offset: 0x0002BAA0
		internal static ItemInformation CttYUPOVpRUMNUnxQyH()
		{
			return ItemInformation.H3n3L2Ox7qZgUkvSbVF;
		}

		// Token: 0x04000269 RID: 617
		public int Index;

		// Token: 0x0400026A RID: 618
		public int Count;

		// Token: 0x0400026B RID: 619
		public int CooldownRemaining;

		// Token: 0x0400026C RID: 620
		private static ItemInformation H3n3L2Ox7qZgUkvSbVF;
	}
}
