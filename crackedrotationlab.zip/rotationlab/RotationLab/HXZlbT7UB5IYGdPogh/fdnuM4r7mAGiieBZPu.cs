﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace HXZlbT7UB5IYGdPogh
{
	// Token: 0x02000017 RID: 23
	internal class fdnuM4r7mAGiieBZPu
	{
		// Token: 0x060000A0 RID: 160 RVA: 0x00004D1C File Offset: 0x00002F1C
		public fdnuM4r7mAGiieBZPu()
		{
			fdnuM4r7mAGiieBZPu.CMvWiHQTvGOd6dIrUfE();
			fdnuM4r7mAGiieBZPu.gDd5ZvQRKGv5qxhTvlY();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_6fd435aca0274a86955ba7bbb960082d == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x00004D7C File Offset: 0x00002F7C
		// Note: this type is marked as 'beforefieldinit'.
		static fdnuM4r7mAGiieBZPu()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00004D8C File Offset: 0x00002F8C
		internal static void CMvWiHQTvGOd6dIrUfE()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x00004D9C File Offset: 0x00002F9C
		internal static void gDd5ZvQRKGv5qxhTvlY()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x00004DAC File Offset: 0x00002FAC
		internal static bool ibkWQyQfHU2vF0Cwy5v()
		{
			return fdnuM4r7mAGiieBZPu.r33PAsQOPrNdeUbX6TV == null;
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x00004DC0 File Offset: 0x00002FC0
		internal static fdnuM4r7mAGiieBZPu Boi8CNQFm83ga1VwRMe()
		{
			return fdnuM4r7mAGiieBZPu.r33PAsQOPrNdeUbX6TV;
		}

		// Token: 0x040000EC RID: 236
		public string Token;

		// Token: 0x040000ED RID: 237
		public string Error;

		// Token: 0x040000EE RID: 238
		private static fdnuM4r7mAGiieBZPu r33PAsQOPrNdeUbX6TV;
	}
}
