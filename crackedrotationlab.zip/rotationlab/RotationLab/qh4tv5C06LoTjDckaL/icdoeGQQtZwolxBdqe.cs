﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using bSZew2cfycgxx2Qytd1;
using HXZlbT7UB5IYGdPogh;
using jKfdjbkhweMBv9T4LF;
using LinkDotNet.NUniqueHardwareID;
using MyU9Ep58ZH3s5ThDFJQ;
using Newtonsoft.Json;
using PFKsXUln68gK98ndGV;
using RotationLabEngine;
using Sk5EtwKTjRJr4xlhBC;
using XR7RtrxI8Vm7Dgx9BKr;

namespace qh4tv5C06LoTjDckaL
{
	// Token: 0x02000011 RID: 17
	internal static class icdoeGQQtZwolxBdqe
	{
		// Token: 0x0600005D RID: 93 RVA: 0x00003178 File Offset: 0x00001378
		[CompilerGenerated]
		public static void HItpuc7D0(EventHandler<LogEventArgs> \u0020)
		{
			EventHandler<LogEventArgs> eventHandler = icdoeGQQtZwolxBdqe.NewLogEvent;
			EventHandler<LogEventArgs> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<LogEventArgs> value = (EventHandler<LogEventArgs>)Delegate.Combine(eventHandler2, \u0020);
				eventHandler = Interlocked.CompareExchange<EventHandler<LogEventArgs>>(ref icdoeGQQtZwolxBdqe.NewLogEvent, value, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}

		// Token: 0x0600005E RID: 94 RVA: 0x000031B8 File Offset: 0x000013B8
		[CompilerGenerated]
		public static void WR94s0Tji(EventHandler<LogEventArgs> \u0020)
		{
			EventHandler<LogEventArgs> eventHandler = icdoeGQQtZwolxBdqe.NewLogEvent;
			EventHandler<LogEventArgs> eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler<LogEventArgs> value = (EventHandler<LogEventArgs>)Delegate.Remove(eventHandler2, \u0020);
				eventHandler = Interlocked.CompareExchange<EventHandler<LogEventArgs>>(ref icdoeGQQtZwolxBdqe.NewLogEvent, value, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}

		// Token: 0x0600005F RID: 95 RVA: 0x000031F8 File Offset: 0x000013F8
		public static void H0r92ppXT(string \u0020)
		{
			int num = 1;
			int num2 = num;
			EventHandler<LogEventArgs> newLogEvent;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					newLogEvent = icdoeGQQtZwolxBdqe.NewLogEvent;
					if (newLogEvent != null)
					{
						goto Block_2;
					}
					num2 = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_01d314db732841fc934f41441894a8f2 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
			return;
			Block_2:
			newLogEvent(null, new LogEventArgs(\u0020));
		}

		// Token: 0x06000060 RID: 96 RVA: 0x00003270 File Offset: 0x00001470
		public static string Qnow9skY1()
		{
			UniqueHardwareId uniqueHardwareId = new UniqueHardwareId();
			uniqueHardwareId.UseCPUInformation = true;
			icdoeGQQtZwolxBdqe.C97HkA3nHbcZgXgjt3m(uniqueHardwareId, false);
			icdoeGQQtZwolxBdqe.AImHGH3018HdqNW4snM(uniqueHardwareId, true);
			return icdoeGQQtZwolxBdqe.lX6IG93JOtq7DjCA0N9(uniqueHardwareId);
		}

		// Token: 0x06000061 RID: 97 RVA: 0x00003298 File Offset: 0x00001498
		public static string Qp6ArDHfx()
		{
			return icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(icdoeGQQtZwolxBdqe.serverDomain, vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1218526815 ^ -1218526967));
		}

		// Token: 0x06000062 RID: 98 RVA: 0x000032BC File Offset: 0x000014BC
		public static string G95hJ79oX()
		{
			return icdoeGQQtZwolxBdqe.serverDomain + icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(1048347516 ^ 1048347558);
		}

		// Token: 0x06000063 RID: 99 RVA: 0x000032E0 File Offset: 0x000014E0
		public static string Da6STDcvv()
		{
			return icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(icdoeGQQtZwolxBdqe.serverDomain, icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(~463906284 ^ -463906075));
		}

		// Token: 0x06000064 RID: 100 RVA: 0x00003304 File Offset: 0x00001504
		public static string yWpI5dOqO(string \u0020)
		{
			return icdoeGQQtZwolxBdqe.hwHU0C3YYJFsuXd0OdF(new string[]
			{
				icdoeGQQtZwolxBdqe.serverDomain,
				vua32v5yjQhjRjK4YIO.BRA5TcZvlv(764415235 ^ 764415003),
				\u0020,
				vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-309791748 - 2077333185 ^ 1907842169),
				icdoeGQQtZwolxBdqe.M8cele3tGAxpNJVP26l()
			});
		}

		// Token: 0x06000065 RID: 101 RVA: 0x00003364 File Offset: 0x00001564
		public static InA3Q4LFDQmiFopNqj xD5ivBQoQ(string \u0020)
		{
			try
			{
				HttpClient httpClient = new HttpClient();
				int num = 6;
				HttpResponseMessage result;
				InA3Q4LFDQmiFopNqj result2;
				for (;;)
				{
					FormUrlEncodedContent content;
					switch (num)
					{
					case 0:
						goto IL_147;
					case 1:
					{
						result = httpClient.PostAsync(icdoeGQQtZwolxBdqe.G95hJ79oX(), content).Result;
						int num2 = 3;
						num = num2;
						continue;
					}
					case 2:
						icdoeGQQtZwolxBdqe.zXgHVd3gv9dAKVC0gMM(icdoeGQQtZwolxBdqe.NCqR6U3s6JE5U8EuaEM(httpClient), icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(-911697958 - 376275890 ^ -1287973518), icdoeGQQtZwolxBdqe.Qnow9skY1());
						num = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_a045e374816444ca92d30db5245d264e == 0)
						{
							num = 0;
							continue;
						}
						continue;
					case 3:
						if (icdoeGQQtZwolxBdqe.eyFVny3XvPYoDpi2toF(result))
						{
							num = 5;
							continue;
						}
						break;
					case 4:
						goto IL_1DB;
					case 5:
						goto IL_19B;
					case 6:
						icdoeGQQtZwolxBdqe.zXgHVd3gv9dAKVC0gMM(icdoeGQQtZwolxBdqe.NCqR6U3s6JE5U8EuaEM(httpClient), icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(1858354135 - 1114350030 ^ 744004421), \u0020);
						num = 2;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0a2b7fe605ba404ba745ea0e50bfd1bb == 0)
						{
							num = 2;
							continue;
						}
						continue;
					case 7:
						break;
					default:
						goto IL_147;
					}
					result2 = new InA3Q4LFDQmiFopNqj
					{
						Error = icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(~-1482987862 ^ 1482987735), icdoeGQQtZwolxBdqe.dKHoby3GfdLpUMnSlBN(result).ToString())
					};
					num = 4;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_5d40d00282484c3192de8d3f455be896 == 0)
					{
						num = 0;
						continue;
					}
					continue;
					IL_147:
					content = new FormUrlEncodedContent(new KeyValuePair<string, string>[]
					{
						new KeyValuePair<string, string>(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(268206341 ^ 268206179), icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(~-531755127 ^ 531755264))
					});
					num = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_57b2e386d0354e0b85dd8e8db78e6c05 == 0)
					{
						num = 1;
					}
				}
				IL_19B:
				result2 = JsonConvert.DeserializeObject<InA3Q4LFDQmiFopNqj>(icdoeGQQtZwolxBdqe.X3A74J3MuB8kb54e7rZ(result).ReadAsStringAsync().Result);
				IL_1DB:
				return result2;
			}
			catch (JsonReaderException ex)
			{
				InA3Q4LFDQmiFopNqj result2 = new InA3Q4LFDQmiFopNqj
				{
					Error = icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-235868112 ^ -235867666), icdoeGQQtZwolxBdqe.O2L2lE3Bf9iehbqy44I(ex))
				};
				int num3 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_5e42540a7e2247379e20536f2877b437 != 0)
				{
					num3 = 0;
				}
				switch (num3)
				{
				}
				return result2;
			}
			catch (AggregateException ex2)
			{
				int num4 = 1;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_912464c7521643f2968751cbbc64f3cf != 0)
				{
					num4 = 1;
				}
				IEnumerator<Exception> enumerator;
				for (;;)
				{
					switch (num4)
					{
					case 1:
						enumerator = ex2.InnerExceptions.GetEnumerator();
						num4 = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_8587ff20fd5f487a89bfe65d8ab138e4 == 0)
						{
							num4 = 0;
							continue;
						}
						continue;
					}
					break;
				}
				try
				{
					InA3Q4LFDQmiFopNqj result2;
					for (;;)
					{
						if (enumerator.MoveNext())
						{
							goto IL_338;
						}
						int num5 = 2;
						IL_2BF:
						switch (num5)
						{
						case 1:
							continue;
						case 2:
							goto IL_364;
						case 3:
							goto IL_345;
						}
						IL_338:
						Exception ex3 = enumerator.Current;
						result2 = new InA3Q4LFDQmiFopNqj
						{
							Error = icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(185404423 + 1853889833 ^ 2039294190) + icdoeGQQtZwolxBdqe.O2L2lE3Bf9iehbqy44I(ex2)
						};
						num5 = 1;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0e5e3d7d8cdf4d2a9040ab7043b65fe6 == 0)
						{
							num5 = 3;
							goto IL_2BF;
						}
						goto IL_2BF;
					}
					IL_345:
					return result2;
					IL_364:;
				}
				finally
				{
					int num6;
					if (enumerator == null)
					{
						num6 = 1;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_e4c3e507bea3489ca1e59bddf0d58f83 != 0)
						{
							num6 = 0;
						}
					}
					else
					{
						icdoeGQQtZwolxBdqe.jcKf8h3DpiBd48ZS4El(enumerator);
						num6 = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_3033bf1c1fc44fbd97a2780a04032069 == 0)
						{
							num6 = 0;
						}
					}
					switch (num6)
					{
					}
				}
			}
			catch (Exception ex4)
			{
				int num7 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_6fd435aca0274a86955ba7bbb960082d == 0)
				{
					num7 = 0;
				}
				switch (num7)
				{
				default:
					return new InA3Q4LFDQmiFopNqj
					{
						Error = icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1520361985 >> 6 ^ -23755351), icdoeGQQtZwolxBdqe.O2L2lE3Bf9iehbqy44I(ex4))
					};
				}
			}
			return null;
		}

		// Token: 0x06000066 RID: 102 RVA: 0x00003818 File Offset: 0x00001A18
		public static fdnuM4r7mAGiieBZPu Login(string username, string password)
		{
			try
			{
				HttpClient httpClient = new HttpClient();
				int num = 6;
				fdnuM4r7mAGiieBZPu result2;
				for (;;)
				{
					HttpResponseMessage result;
					switch (num)
					{
					case 1:
						goto IL_92;
					case 2:
						if (!icdoeGQQtZwolxBdqe.eyFVny3XvPYoDpi2toF(result))
						{
							goto IL_17D;
						}
						goto IL_92;
					case 3:
					{
						FormUrlEncodedContent content;
						result = httpClient.PostAsync(icdoeGQQtZwolxBdqe.dvjlho3vNEXK5fSrsYi(), content).Result;
						num = 2;
						continue;
					}
					case 4:
						goto IL_17D;
					case 6:
					{
						FormUrlEncodedContent content = new FormUrlEncodedContent(new KeyValuePair<string, string>[]
						{
							new KeyValuePair<string, string>(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(--1722095099 ^ 1722094749), icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(326177456 ^ 326176936)),
							new KeyValuePair<string, string>(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(-1815843576 ^ -1815843026), username),
							new KeyValuePair<string, string>(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-789419076 ^ -35552607 ^ 756280103), password),
							new KeyValuePair<string, string>(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(--1722095099 ^ 1722095541), icdoeGQQtZwolxBdqe.M8cele3tGAxpNJVP26l())
						});
						num = 3;
						continue;
					}
					}
					break;
					IL_92:
					result2 = JsonConvert.DeserializeObject<fdnuM4r7mAGiieBZPu>(icdoeGQQtZwolxBdqe.X3A74J3MuB8kb54e7rZ(result).ReadAsStringAsync().Result);
					num = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_f40e85c0282d4285a254092b800ae8f8 != 0)
					{
						num = 0;
						continue;
					}
					continue;
					IL_17D:
					result2 = new fdnuM4r7mAGiieBZPu
					{
						Error = icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(268802365 >> 1 ^ 134401308) + icdoeGQQtZwolxBdqe.dKHoby3GfdLpUMnSlBN(result).ToString()
					};
					num = 5;
				}
				return result2;
			}
			catch (JsonReaderException)
			{
				fdnuM4r7mAGiieBZPu result2 = new fdnuM4r7mAGiieBZPu
				{
					Error = vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1406908615 ^ 676245432 ^ -2073367845)
				};
				int num2 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_b58cc6448c07462981f7780e6183361e == 0)
				{
					num2 = 0;
				}
				switch (num2)
				{
				}
				return result2;
			}
			catch (AggregateException ex)
			{
				IEnumerator<Exception> enumerator = ex.InnerExceptions.GetEnumerator();
				try
				{
					fdnuM4r7mAGiieBZPu result2;
					for (;;)
					{
						if (icdoeGQQtZwolxBdqe.TPChWp3jYrJlABHOQtQ(enumerator))
						{
							goto IL_2A4;
						}
						int num3 = 3;
						IL_26B:
						switch (num3)
						{
						default:
							goto IL_285;
						case 1:
							break;
						case 2:
						{
							IL_2A4:
							Exception ex2 = enumerator.Current;
							result2 = new fdnuM4r7mAGiieBZPu
							{
								Error = icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(1633072087 ^ 1633071625), icdoeGQQtZwolxBdqe.O2L2lE3Bf9iehbqy44I(ex2))
							};
							num3 = 0;
							if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_815f08b431b44ac887f007356b7a532a == 0)
							{
								num3 = 0;
								goto IL_26B;
							}
							goto IL_26B;
						}
						case 3:
							goto IL_30B;
						}
					}
					IL_285:
					return result2;
					IL_30B:;
				}
				finally
				{
					if (enumerator != null)
					{
						int num4 = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0e5e3d7d8cdf4d2a9040ab7043b65fe6 == 0)
						{
							num4 = 0;
						}
						switch (num4)
						{
						default:
							enumerator.Dispose();
							break;
						}
					}
				}
			}
			catch (Exception ex3)
			{
				fdnuM4r7mAGiieBZPu result2 = new fdnuM4r7mAGiieBZPu
				{
					Error = icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(-161182833 ^ -161183151), icdoeGQQtZwolxBdqe.O2L2lE3Bf9iehbqy44I(ex3))
				};
				int num5 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_4130c9db5c2b43e596cc610f57348b4a == 0)
				{
					num5 = 0;
				}
				switch (num5)
				{
				}
				return result2;
			}
			return null;
		}

		// Token: 0x06000067 RID: 103 RVA: 0x00003C64 File Offset: 0x00001E64
		public static bool mmmZKEZw3()
		{
			try
			{
				HttpClient httpClient = new HttpClient();
				icdoeGQQtZwolxBdqe.NCqR6U3s6JE5U8EuaEM(httpClient).Add(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(978854837 ^ 978854649), yQGkVJcOSOQdjuwds7e.ini.GetValue(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(-1872685799 ^ -1872685109), vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-717857995 >> 5 ^ -22433731), icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(978854837 ^ 978854215)));
				int num = 3;
				bool result;
				for (;;)
				{
					switch (num)
					{
					case 1:
						result = true;
						num = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0a2b7fe605ba404ba745ea0e50bfd1bb != 0)
						{
							num = 0;
							continue;
						}
						continue;
					case 2:
					{
						FormUrlEncodedContent content = new FormUrlEncodedContent(new KeyValuePair<string, string>[]
						{
							new KeyValuePair<string, string>(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(1308721404 ^ 1308721562), vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1399929319 << 3 ^ 1685467696))
						});
						num = 3;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_5d83dab2d7c4415687f4df21e1f4a0a7 != 0)
						{
							num = 5;
							continue;
						}
						continue;
					}
					case 3:
						icdoeGQQtZwolxBdqe.zXgHVd3gv9dAKVC0gMM(icdoeGQQtZwolxBdqe.NCqR6U3s6JE5U8EuaEM(httpClient), icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(1073891089 ^ 1073890891), icdoeGQQtZwolxBdqe.Qnow9skY1());
						num = 2;
						continue;
					case 4:
						goto IL_195;
					case 5:
					{
						FormUrlEncodedContent content;
						if (!icdoeGQQtZwolxBdqe.eyFVny3XvPYoDpi2toF(httpClient.PostAsync(icdoeGQQtZwolxBdqe.dvjlho3vNEXK5fSrsYi(), content).Result))
						{
							goto IL_195;
						}
						num = 1;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0c080a9909304bb4a8ca9ea8d5e25f67 == 0)
						{
							num = 0;
							continue;
						}
						continue;
					}
					}
					break;
				}
				return result;
				IL_195:;
			}
			catch (AggregateException)
			{
				int num2 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_5d40d00282484c3192de8d3f455be896 != 0)
				{
					num2 = 0;
				}
				switch (num2)
				{
				default:
					return false;
				}
			}
			catch (Exception)
			{
				int num3 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_827c6d37267a42a5864c59085f394f8f == 0)
				{
					num3 = 0;
				}
				switch (num3)
				{
				default:
					return false;
				}
			}
			return false;
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00003EB8 File Offset: 0x000020B8
		public static Rxlep3aFWM75xoYk07 TgQUk35PZ(string \u0020, string \u0020)
		{
			try
			{
				HttpClient httpClient = new HttpClient();
				int num = 2;
				Rxlep3aFWM75xoYk07 result;
				for (;;)
				{
					switch (num)
					{
					case 1:
					{
						FormUrlEncodedContent content = new FormUrlEncodedContent(new KeyValuePair<string, string>[]
						{
							new KeyValuePair<string, string>(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(-1352111144 ^ -1352111426), vua32v5yjQhjRjK4YIO.BRA5TcZvlv(~-1605313923 ^ 1605314186)),
							new KeyValuePair<string, string>(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(-789419076 ^ -35552607 ^ 756279869), \u0020)
						});
						result = JsonConvert.DeserializeObject<Rxlep3aFWM75xoYk07>(httpClient.PostAsync(icdoeGQQtZwolxBdqe.G95hJ79oX(), content).Result.Content.ReadAsStringAsync().Result);
						num = 3;
						continue;
					}
					case 2:
						icdoeGQQtZwolxBdqe.NCqR6U3s6JE5U8EuaEM(httpClient).Add(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(--2124070285 ^ 2124070081), \u0020);
						num = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_57b2e386d0354e0b85dd8e8db78e6c05 != 0)
						{
							num = 0;
							continue;
						}
						continue;
					case 3:
						goto IL_140;
					}
					icdoeGQQtZwolxBdqe.zXgHVd3gv9dAKVC0gMM(icdoeGQQtZwolxBdqe.NCqR6U3s6JE5U8EuaEM(httpClient), vua32v5yjQhjRjK4YIO.BRA5TcZvlv(~1005505369 ^ -1005505028), icdoeGQQtZwolxBdqe.M8cele3tGAxpNJVP26l());
					num = 1;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_40d264c41f474fea9eba2908d12918c1 == 0)
					{
						num = 1;
					}
				}
				IL_140:
				return result;
			}
			catch (JsonReaderException ex)
			{
				int num2 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0c080a9909304bb4a8ca9ea8d5e25f67 == 0)
				{
					num2 = 0;
				}
				switch (num2)
				{
				default:
					return new Rxlep3aFWM75xoYk07
					{
						Error = icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(2090212177 ^ 2090211449) + icdoeGQQtZwolxBdqe.O2L2lE3Bf9iehbqy44I(ex)
					};
				}
			}
			catch (AggregateException ex2)
			{
				int num3 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_fd0c1f052d0e476eab1db9043408a8d6 == 0)
				{
					num3 = 0;
				}
				switch (num3)
				{
				case 1:
					goto IL_330;
				}
				for (;;)
				{
					IEnumerator<Exception> enumerator = ex2.InnerExceptions.GetEnumerator();
					try
					{
						if (enumerator.MoveNext())
						{
							goto IL_289;
						}
						int num4 = 3;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_521a515f15c94d10b5254529acc6f115 == 0)
						{
							num4 = 2;
						}
						Rxlep3aFWM75xoYk07 result;
						for (;;)
						{
							IL_1FC:
							switch (num4)
							{
							case 1:
								goto IL_216;
							case 2:
								result = new Rxlep3aFWM75xoYk07
								{
									Error = icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(790722942 ^ 790723158), ex2.Message)
								};
								num4 = 0;
								if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_b58cc6448c07462981f7780e6183361e == 0)
								{
									num4 = 1;
									continue;
								}
								continue;
							case 3:
								goto IL_29B;
							}
							break;
						}
						goto IL_289;
						IL_216:
						return result;
						IL_29B:
						break;
						IL_289:
						Exception ex3 = enumerator.Current;
						num4 = 2;
						goto IL_1FC;
					}
					finally
					{
						int num5;
						if (enumerator == null)
						{
							num5 = 0;
							if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_f40e85c0282d4285a254092b800ae8f8 == 0)
							{
								num5 = 1;
							}
						}
						else
						{
							icdoeGQQtZwolxBdqe.jcKf8h3DpiBd48ZS4El(enumerator);
							num5 = 0;
							if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_24213672444f404ab1c51fbb2634eb8c == 0)
							{
								num5 = 0;
							}
						}
						switch (num5)
						{
						}
					}
				}
				IL_330:;
			}
			catch (Exception ex4)
			{
				Rxlep3aFWM75xoYk07 result = new Rxlep3aFWM75xoYk07
				{
					Error = icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1696412362 - -137042106 ^ -1559370024), icdoeGQQtZwolxBdqe.O2L2lE3Bf9iehbqy44I(ex4))
				};
				int num6 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_c609793e83ea4d9f8a76fd0fe20634d3 == 0)
				{
					num6 = 0;
				}
				switch (num6)
				{
				}
				return result;
			}
			return null;
		}

		// Token: 0x06000069 RID: 105 RVA: 0x000042D0 File Offset: 0x000024D0
		public static QkZCxleFAdLKmShDaf yKc1JfyrE(string \u0020)
		{
			try
			{
				Version version = icdoeGQQtZwolxBdqe.wFtybVQWLLD4f6ZRKTP(icdoeGQQtZwolxBdqe.n7auk03zKP3GgSgKe9g(icdoeGQQtZwolxBdqe.re6HL63biGqT7HLCaNl()));
				int num = 3;
				QkZCxleFAdLKmShDaf result;
				for (;;)
				{
					switch (num)
					{
					default:
					{
						FormUrlEncodedContent content = new FormUrlEncodedContent(new KeyValuePair<string, string>[]
						{
							new KeyValuePair<string, string>(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(-1008853611 >> 6 ^ -15763184), icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(-2018852357 ^ -2018852203)),
							new KeyValuePair<string, string>(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1399929319 << 3 ^ 1685467968), version.ToString())
						});
						num = 1;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_f07fcafdab6044ae94aa2a4d4d748d5c != 0)
						{
							num = 0;
						}
						break;
					}
					case 1:
					{
						FormUrlEncodedContent content;
						HttpClient httpClient;
						result = JsonConvert.DeserializeObject<QkZCxleFAdLKmShDaf>(icdoeGQQtZwolxBdqe.X3A74J3MuB8kb54e7rZ(httpClient.PostAsync(icdoeGQQtZwolxBdqe.G95hJ79oX(), content).Result).ReadAsStringAsync().Result);
						num = 1;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_78ab67cec1824b2289ca2a9b24f27de2 == 0)
						{
							num = 2;
						}
						break;
					}
					case 2:
						goto IL_182;
					case 3:
					{
						HttpClient httpClient = new HttpClient();
						icdoeGQQtZwolxBdqe.zXgHVd3gv9dAKVC0gMM(icdoeGQQtZwolxBdqe.NCqR6U3s6JE5U8EuaEM(httpClient), icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(579026892 ^ 579026560), \u0020);
						int num2 = 4;
						num = num2;
						break;
					}
					case 4:
					{
						HttpClient httpClient;
						icdoeGQQtZwolxBdqe.zXgHVd3gv9dAKVC0gMM(httpClient.DefaultRequestHeaders, icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(881693030 + 414722879 ^ 1296416255), icdoeGQQtZwolxBdqe.Qnow9skY1());
						num = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_4130c9db5c2b43e596cc610f57348b4a != 0)
						{
							num = 0;
						}
						break;
					}
					}
				}
				IL_182:
				return result;
			}
			catch (JsonReaderException ex)
			{
				int num3 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_c9958ff501e7430a9a68ee9837d30eaa != 0)
				{
					num3 = 0;
				}
				switch (num3)
				{
				default:
					return new QkZCxleFAdLKmShDaf
					{
						Error = icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(1858354135 - 1114350030 ^ 744003987), icdoeGQQtZwolxBdqe.O2L2lE3Bf9iehbqy44I(ex))
					};
				}
			}
			catch (AggregateException ex2)
			{
				int num4 = 1;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_1ec1c85d27ea4a539ba7e0e334676a34 != 0)
				{
					num4 = 1;
				}
				switch (num4)
				{
				case 1:
				{
					IEnumerator<Exception> enumerator = ex2.InnerExceptions.GetEnumerator();
					try
					{
						QkZCxleFAdLKmShDaf result;
						for (;;)
						{
							if (icdoeGQQtZwolxBdqe.TPChWp3jYrJlABHOQtQ(enumerator))
							{
								goto IL_290;
							}
							int num5 = 2;
							IL_257:
							switch (num5)
							{
							case 1:
							{
								IL_290:
								Exception ex3 = enumerator.Current;
								result = new QkZCxleFAdLKmShDaf
								{
									Error = icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(-1755352853 ^ -1755352207), icdoeGQQtZwolxBdqe.O2L2lE3Bf9iehbqy44I(ex2))
								};
								num5 = 3;
								if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_114c8e4d680c4b9997b685901f6ff336 != 0)
								{
									num5 = 3;
									goto IL_257;
								}
								goto IL_257;
							}
							case 2:
								goto IL_2F6;
							case 3:
								goto IL_271;
							}
						}
						IL_271:
						return result;
						IL_2F6:;
					}
					finally
					{
						if (enumerator != null)
						{
							for (;;)
							{
								enumerator.Dispose();
								int num6 = 1;
								if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_fa027ca03d194169b4d4b16c724923ba != 0)
								{
									num6 = 1;
								}
								switch (num6)
								{
								case 1:
									goto IL_35D;
								}
							}
						}
						IL_35D:;
					}
					break;
				}
				}
			}
			catch (Exception ex4)
			{
				QkZCxleFAdLKmShDaf result = new QkZCxleFAdLKmShDaf
				{
					Error = icdoeGQQtZwolxBdqe.M3w20I3mVHKirlQLccL(icdoeGQQtZwolxBdqe.WY4xQ63HRePdZYxZ8CF(-553744847 ^ -553744981), icdoeGQQtZwolxBdqe.O2L2lE3Bf9iehbqy44I(ex4))
				};
				int num7 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_a4220304efac479885fc7bed52e95949 == 0)
				{
					num7 = 0;
				}
				switch (num7)
				{
				}
				return result;
			}
			return null;
		}

		// Token: 0x0600006A RID: 106 RVA: 0x00004728 File Offset: 0x00002928
		// Note: this type is marked as 'beforefieldinit'.
		static icdoeGQQtZwolxBdqe()
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
					num2 = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_e0aba0d9fb124085a8bd5fdd21baeb5d == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					icdoeGQQtZwolxBdqe.msPQANQPwWkYPHbXStJ();
					num2 = 1;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_fa027ca03d194169b4d4b16c724923ba == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 3:
					goto IL_33;
				}
				icdoeGQQtZwolxBdqe.bk8guKQEVoUmw185txl();
				num2 = 3;
			}
			IL_33:
			icdoeGQQtZwolxBdqe.serverDomain = vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-825446221 ^ -825445531);
		}

		// Token: 0x0600006B RID: 107 RVA: 0x000047D0 File Offset: 0x000029D0
		internal static bool MeBIxu36qZ0LTo0Q114()
		{
			return icdoeGQQtZwolxBdqe.tdGg6u32DBnWt4IIuHb == null;
		}

		// Token: 0x0600006C RID: 108 RVA: 0x000047E4 File Offset: 0x000029E4
		internal static icdoeGQQtZwolxBdqe Bf2TEq3NJWCBvgTqd3G()
		{
			return icdoeGQQtZwolxBdqe.tdGg6u32DBnWt4IIuHb;
		}

		// Token: 0x0600006D RID: 109 RVA: 0x000047F4 File Offset: 0x000029F4
		internal static void C97HkA3nHbcZgXgjt3m(object A_0, bool A_1)
		{
			A_0.UseMACAddress = A_1;
		}

		// Token: 0x0600006E RID: 110 RVA: 0x0000480C File Offset: 0x00002A0C
		internal static void AImHGH3018HdqNW4snM(object A_0, bool A_1)
		{
			A_0.UseVolumeInformation = A_1;
		}

		// Token: 0x0600006F RID: 111 RVA: 0x00004824 File Offset: 0x00002A24
		internal static object lX6IG93JOtq7DjCA0N9(object A_0)
		{
			return A_0.CalculateHardwareId();
		}

		// Token: 0x06000070 RID: 112 RVA: 0x00004838 File Offset: 0x00002A38
		internal static object M3w20I3mVHKirlQLccL(object A_0, object A_1)
		{
			return A_0 + A_1;
		}

		// Token: 0x06000071 RID: 113 RVA: 0x00004850 File Offset: 0x00002A50
		internal static object WY4xQ63HRePdZYxZ8CF(int \u0020)
		{
			return vua32v5yjQhjRjK4YIO.BRA5TcZvlv(\u0020);
		}

		// Token: 0x06000072 RID: 114 RVA: 0x00004864 File Offset: 0x00002A64
		internal static object M8cele3tGAxpNJVP26l()
		{
			return icdoeGQQtZwolxBdqe.Qnow9skY1();
		}

		// Token: 0x06000073 RID: 115 RVA: 0x00004874 File Offset: 0x00002A74
		internal static object hwHU0C3YYJFsuXd0OdF(object A_0)
		{
			return string.Concat(A_0);
		}

		// Token: 0x06000074 RID: 116 RVA: 0x00004888 File Offset: 0x00002A88
		internal static object NCqR6U3s6JE5U8EuaEM(object A_0)
		{
			return A_0.DefaultRequestHeaders;
		}

		// Token: 0x06000075 RID: 117 RVA: 0x0000489C File Offset: 0x00002A9C
		internal static void zXgHVd3gv9dAKVC0gMM(object A_0, object A_1, object A_2)
		{
			A_0.Add(A_1, A_2);
		}

		// Token: 0x06000076 RID: 118 RVA: 0x000048B8 File Offset: 0x00002AB8
		internal static bool eyFVny3XvPYoDpi2toF(object A_0)
		{
			return A_0.IsSuccessStatusCode;
		}

		// Token: 0x06000077 RID: 119 RVA: 0x000048CC File Offset: 0x00002ACC
		internal static object X3A74J3MuB8kb54e7rZ(object A_0)
		{
			return A_0.Content;
		}

		// Token: 0x06000078 RID: 120 RVA: 0x000048E0 File Offset: 0x00002AE0
		internal static HttpStatusCode dKHoby3GfdLpUMnSlBN(object A_0)
		{
			return A_0.StatusCode;
		}

		// Token: 0x06000079 RID: 121 RVA: 0x000048F4 File Offset: 0x00002AF4
		internal static object O2L2lE3Bf9iehbqy44I(object A_0)
		{
			return A_0.Message;
		}

		// Token: 0x0600007A RID: 122 RVA: 0x00004908 File Offset: 0x00002B08
		internal static void jcKf8h3DpiBd48ZS4El(object A_0)
		{
			((IDisposable)A_0).Dispose();
		}

		// Token: 0x0600007B RID: 123 RVA: 0x0000491C File Offset: 0x00002B1C
		internal static object dvjlho3vNEXK5fSrsYi()
		{
			return icdoeGQQtZwolxBdqe.G95hJ79oX();
		}

		// Token: 0x0600007C RID: 124 RVA: 0x0000492C File Offset: 0x00002B2C
		internal static bool TPChWp3jYrJlABHOQtQ(object A_0)
		{
			return ((IEnumerator)A_0).MoveNext();
		}

		// Token: 0x0600007D RID: 125 RVA: 0x00004940 File Offset: 0x00002B40
		internal static object re6HL63biGqT7HLCaNl()
		{
			return Assembly.GetExecutingAssembly();
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00004950 File Offset: 0x00002B50
		internal static object n7auk03zKP3GgSgKe9g(object A_0)
		{
			return A_0.GetName();
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00004964 File Offset: 0x00002B64
		internal static object wFtybVQWLLD4f6ZRKTP(object A_0)
		{
			return A_0.Version;
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00004978 File Offset: 0x00002B78
		internal static void msPQANQPwWkYPHbXStJ()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x06000081 RID: 129 RVA: 0x00004988 File Offset: 0x00002B88
		internal static void bk8guKQEVoUmw185txl()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x040000C4 RID: 196
		[CompilerGenerated]
		private static EventHandler<LogEventArgs> NewLogEvent;

		// Token: 0x040000C5 RID: 197
		private static string serverDomain;

		// Token: 0x040000C6 RID: 198
		private static icdoeGQQtZwolxBdqe tdGg6u32DBnWt4IIuHb;
	}
}
