﻿using System;

namespace XR7RtrxI8Vm7Dgx9BKr
{
	// Token: 0x02000069 RID: 105
	internal class PnrHSvxSLFnA986pZWM
	{
		// Token: 0x060008BA RID: 2234 RVA: 0x0004794C File Offset: 0x00045B4C
		internal static void QUh0QAwUQW()
		{
		}

		// Token: 0x0400039B RID: 923
		private static bool t411bB1dDq;
	}
}
