﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;

namespace RotationLabEngine
{
	// Token: 0x02000037 RID: 55
	public static class UnitType
	{
		// Token: 0x0600054B RID: 1355 RVA: 0x0002D0D4 File Offset: 0x0002B2D4
		// Note: this type is marked as 'beforefieldinit'.
		static UnitType()
		{
			UnitType.cFBhE44l0q5CPhkQCWl();
		}

		// Token: 0x0600054C RID: 1356 RVA: 0x0002D0E4 File Offset: 0x0002B2E4
		internal static void cFBhE44l0q5CPhkQCWl()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x0400020C RID: 524
		public const string Player = "player";

		// Token: 0x0400020D RID: 525
		public const string Target = "target";

		// Token: 0x0400020E RID: 526
		public const string Focus = "focus";

		// Token: 0x0400020F RID: 527
		public const string Pet = "pet";

		// Token: 0x04000210 RID: 528
		public const string Mouseover = "mouseover";

		// Token: 0x04000211 RID: 529
		public const string Party1 = "party1";

		// Token: 0x04000212 RID: 530
		public const string Party2 = "party2";

		// Token: 0x04000213 RID: 531
		public const string Party3 = "party3";

		// Token: 0x04000214 RID: 532
		public const string Party4 = "party4";

		// Token: 0x04000215 RID: 533
		public const string Arena1 = "arena1";

		// Token: 0x04000216 RID: 534
		public const string Arena2 = "arena2";

		// Token: 0x04000217 RID: 535
		public const string Arena3 = "arena3";

		// Token: 0x04000218 RID: 536
		public const string Arena4 = "arena4";

		// Token: 0x04000219 RID: 537
		public const string Arena5 = "arena5";

		// Token: 0x0400021A RID: 538
		public const string Raid1 = "raid1";

		// Token: 0x0400021B RID: 539
		public const string Raid2 = "raid2";

		// Token: 0x0400021C RID: 540
		public const string Raid3 = "raid3";

		// Token: 0x0400021D RID: 541
		public const string Raid4 = "raid4";

		// Token: 0x0400021E RID: 542
		public const string Raid5 = "raid5";

		// Token: 0x0400021F RID: 543
		public const string Raid6 = "raid6";

		// Token: 0x04000220 RID: 544
		public const string Raid7 = "raid7";

		// Token: 0x04000221 RID: 545
		public const string Raid8 = "raid8";

		// Token: 0x04000222 RID: 546
		public const string Raid9 = "raid9";

		// Token: 0x04000223 RID: 547
		public const string Raid10 = "raid10";

		// Token: 0x04000224 RID: 548
		public const string Raid11 = "raid11";

		// Token: 0x04000225 RID: 549
		public const string Raid12 = "raid12";

		// Token: 0x04000226 RID: 550
		public const string Raid13 = "raid13";

		// Token: 0x04000227 RID: 551
		public const string Raid14 = "raid14";

		// Token: 0x04000228 RID: 552
		public const string Raid15 = "raid15";

		// Token: 0x04000229 RID: 553
		public const string Raid16 = "raid16";

		// Token: 0x0400022A RID: 554
		public const string Raid17 = "raid17";

		// Token: 0x0400022B RID: 555
		public const string Raid18 = "raid18";

		// Token: 0x0400022C RID: 556
		public const string Raid19 = "raid19";

		// Token: 0x0400022D RID: 557
		public const string Raid20 = "raid20";

		// Token: 0x0400022E RID: 558
		public const string Raid21 = "raid21";

		// Token: 0x0400022F RID: 559
		public const string Raid22 = "raid22";

		// Token: 0x04000230 RID: 560
		public const string Raid23 = "raid23";

		// Token: 0x04000231 RID: 561
		public const string Raid24 = "raid24";

		// Token: 0x04000232 RID: 562
		public const string Raid25 = "raid25";
	}
}
