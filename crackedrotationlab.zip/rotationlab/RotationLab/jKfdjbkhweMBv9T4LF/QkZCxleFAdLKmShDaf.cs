﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace jKfdjbkhweMBv9T4LF
{
	// Token: 0x02000016 RID: 22
	internal class QkZCxleFAdLKmShDaf
	{
		// Token: 0x0600009A RID: 154 RVA: 0x00004C68 File Offset: 0x00002E68
		public QkZCxleFAdLKmShDaf()
		{
			QkZCxleFAdLKmShDaf.qciA9gQprnEEVLj8pTo();
			QkZCxleFAdLKmShDaf.TG54ToQ4icfTXVlBaXm();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_d6675f44e192471dbaeaf2d22fed78ae == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600009B RID: 155 RVA: 0x00004CC8 File Offset: 0x00002EC8
		// Note: this type is marked as 'beforefieldinit'.
		static QkZCxleFAdLKmShDaf()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x0600009C RID: 156 RVA: 0x00004CD8 File Offset: 0x00002ED8
		internal static void qciA9gQprnEEVLj8pTo()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x0600009D RID: 157 RVA: 0x00004CE8 File Offset: 0x00002EE8
		internal static void TG54ToQ4icfTXVlBaXm()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00004CF8 File Offset: 0x00002EF8
		internal static bool Boba1hQUHq43ZagTeeD()
		{
			return QkZCxleFAdLKmShDaf.CQhNoOQZpBG8frSR6bR == null;
		}

		// Token: 0x0600009F RID: 159 RVA: 0x00004D0C File Offset: 0x00002F0C
		internal static QkZCxleFAdLKmShDaf q0fuwTQ1lrvZ2NBY0cQ()
		{
			return QkZCxleFAdLKmShDaf.CQhNoOQZpBG8frSR6bR;
		}

		// Token: 0x040000E7 RID: 231
		public bool HasUpdate;

		// Token: 0x040000E8 RID: 232
		public string Version;

		// Token: 0x040000E9 RID: 233
		public string Type;

		// Token: 0x040000EA RID: 234
		public string Error;

		// Token: 0x040000EB RID: 235
		internal static QkZCxleFAdLKmShDaf CQhNoOQZpBG8frSR6bR;
	}
}
