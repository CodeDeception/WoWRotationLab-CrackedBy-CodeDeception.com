﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace PFKsXUln68gK98ndGV
{
	// Token: 0x02000014 RID: 20
	internal class InA3Q4LFDQmiFopNqj
	{
		// Token: 0x0600008F RID: 143 RVA: 0x00004B10 File Offset: 0x00002D10
		public InA3Q4LFDQmiFopNqj()
		{
			InA3Q4LFDQmiFopNqj.q7VqKxQweZNolmBEVda();
			InA3Q4LFDQmiFopNqj.O3M9GkQAPVdIUZrFpek();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_e008bee02c10447c9c4063221ddff8d1 != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x06000090 RID: 144 RVA: 0x00004B70 File Offset: 0x00002D70
		// Note: this type is marked as 'beforefieldinit'.
		static InA3Q4LFDQmiFopNqj()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x06000091 RID: 145 RVA: 0x00004B80 File Offset: 0x00002D80
		internal static void q7VqKxQweZNolmBEVda()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x06000092 RID: 146 RVA: 0x00004B90 File Offset: 0x00002D90
		internal static void O3M9GkQAPVdIUZrFpek()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x06000093 RID: 147 RVA: 0x00004BA0 File Offset: 0x00002DA0
		internal static bool ns794YQCbpRXG8cw73Y()
		{
			return InA3Q4LFDQmiFopNqj.xwcPfyQQgCu2hxEOqBK == null;
		}

		// Token: 0x06000094 RID: 148 RVA: 0x00004BB4 File Offset: 0x00002DB4
		internal static InA3Q4LFDQmiFopNqj Bs6rmgQ9y4ofRFCptAr()
		{
			return InA3Q4LFDQmiFopNqj.xwcPfyQQgCu2hxEOqBK;
		}

		// Token: 0x040000DE RID: 222
		public string Username;

		// Token: 0x040000DF RID: 223
		public int Expiry;

		// Token: 0x040000E0 RID: 224
		public string License;

		// Token: 0x040000E1 RID: 225
		public string Error;

		// Token: 0x040000E2 RID: 226
		internal static InA3Q4LFDQmiFopNqj xwcPfyQQgCu2hxEOqBK;
	}
}
