﻿using System;
using bSZew2cfycgxx2Qytd1;
using MyU9Ep58ZH3s5ThDFJQ;
using xDwZPux4SDqHCadp1SC;

// Token: 0x0200009C RID: 156
internal sealed class <PrivateImplementationDetails>{E39AAE57-6643-4572-829F-EE1D2660BE70}
{
	// Token: 0x06000D84 RID: 3460 RVA: 0x0006C440 File Offset: 0x0006A640
	[STAThread]
	private static void Main()
	{
		g7nourxp055gaU44Yrc.lLHifFIsCLsZtjvFfN0i();
		yQGkVJcOSOQdjuwds7e.eHkcFjwTAE();
	}

	// Token: 0x06000D85 RID: 3461 RVA: 0x0006C454 File Offset: 0x0006A654
	static <PrivateImplementationDetails>{E39AAE57-6643-4572-829F-EE1D2660BE70}()
	{
		int num = 1;
		int num2 = num;
		for (;;)
		{
			switch (num2)
			{
			case 1:
				vua32v5yjQhjRjK4YIO.aep5UvAyyY();
				num2 = 0;
				if (!true)
				{
					num2 = 0;
					continue;
				}
				continue;
			case 2:
				<PrivateImplementationDetails>{E39AAE57-6643-4572-829F-EE1D2660BE70}.hWaZhT051Sf90H29Di9();
				<PrivateImplementationDetails>{E39AAE57-6643-4572-829F-EE1D2660BE70}.kGgU310xBF0cg0HvDIN();
				num2 = 3;
				continue;
			case 3:
				return;
			}
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
			num2 = 2;
			if (!true)
			{
				num2 = 2;
			}
		}
	}

	// Token: 0x06000D86 RID: 3462 RVA: 0x0006C4E4 File Offset: 0x0006A6E4
	internal static void hWaZhT051Sf90H29Di9()
	{
		vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
	}

	// Token: 0x06000D87 RID: 3463 RVA: 0x0006C4F4 File Offset: 0x0006A6F4
	internal static void kGgU310xBF0cg0HvDIN()
	{
		g7nourxp055gaU44Yrc.lLHifFIsCLsZtjvFfN0i();
	}

	// Token: 0x06000D88 RID: 3464 RVA: 0x0006C504 File Offset: 0x0006A704
	internal static bool y0MitM0EoGmJXyJtwEa()
	{
		return <PrivateImplementationDetails>{E39AAE57-6643-4572-829F-EE1D2660BE70}.CHLfhW0PrWZGmNGswdu == null;
	}

	// Token: 0x06000D89 RID: 3465 RVA: 0x0006C518 File Offset: 0x0006A718
	internal static <PrivateImplementationDetails>{E39AAE57-6643-4572-829F-EE1D2660BE70} RCgvuE0ctqMiQBkDoAJ()
	{
		return <PrivateImplementationDetails>{E39AAE57-6643-4572-829F-EE1D2660BE70}.CHLfhW0PrWZGmNGswdu;
	}

	// Token: 0x04000432 RID: 1074
	private static <PrivateImplementationDetails>{E39AAE57-6643-4572-829F-EE1D2660BE70} CHLfhW0PrWZGmNGswdu;
}
