﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine
{
	// Token: 0x02000028 RID: 40
	public partial class Form2 : Form
	{
		// Token: 0x060003E9 RID: 1001 RVA: 0x00025D54 File Offset: 0x00023F54
		public Form2()
		{
			Form2.W2qyHcZeMOymmoRFyPj();
			Form2.maJvfXZkEHInXjcAQfK();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_f8f2733f262849f48168e4f76ab239d7 == 0)
			{
				num = 0;
			}
			for (;;)
			{
				switch (num)
				{
				default:
					this.HIBcEIeJaf();
					num = 1;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_fd0c1f052d0e476eab1db9043408a8d6 == 0)
					{
						num = 0;
					}
					break;
				case 1:
					return;
				}
			}
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x00025DD8 File Offset: 0x00023FD8
		private void OubcW7EVAT(object \u0020, EventArgs \u0020)
		{
			Form2.BSc88JZrmSOnkHTpwAS(this);
		}

		// Token: 0x060003EB RID: 1003 RVA: 0x00025DE8 File Offset: 0x00023FE8
		public void setMacroTitle(string str)
		{
			this.label1.Text = str;
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x00025E04 File Offset: 0x00024004
		public void setMacroText(string str)
		{
			Form2.icG9NyZ7e7C9Y6s0PTb(this.guna2TextBox1, str);
		}

		// Token: 0x060003ED RID: 1005 RVA: 0x00025E20 File Offset: 0x00024020
		private void HN3cPvkxEc(object \u0020, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (!Form2.xoQaRWZ2BMyrTi1eb4O(this.guna2TextBox1.Text, ""))
					{
						return;
					}
					num2 = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_a4220304efac479885fc7bed52e95949 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
			Clipboard.SetText(this.guna2TextBox1.Text);
		}

		// Token: 0x060003EF RID: 1007 RVA: 0x00025F80 File Offset: 0x00024180
		private void HIBcEIeJaf()
		{
			int num = 6;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.guna2DragControl1.TargetControl = this.label1;
						num2 = 11;
						continue;
					case 2:
						Form2.x2ebkIZv1d8qMhESuxb(this.guna2TextBox1, true);
						Form2.NlCs39Zbe7pWYi9cOyF(this.guna2TextBox1, Form2.nm4S6LZjV87TK7bxGob(-2083830725 ^ -2083847943));
						Form2.eavvrPZzwq5pJVTkiwA(this.guna2TextBox1, '\0');
						num2 = 39;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_b018848e194944659fd6bf9f5a1f9097 != 0)
						{
							num2 = 34;
							continue;
						}
						continue;
					case 3:
						base.FormBorderStyle = FormBorderStyle.None;
						num2 = 16;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_408cdf8d10324497825639e7638db7b2 == 0)
						{
							num2 = 8;
							continue;
						}
						continue;
					case 4:
						this.label1.Text = vua32v5yjQhjRjK4YIO.BRA5TcZvlv(835315079 ^ 835317095);
						num2 = 26;
						continue;
					case 5:
						this.guna2BorderlessForm1 = new Guna2BorderlessForm(this.components);
						num2 = 10;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_84a9e919b9fe4f039ce072ff9fa8ab32 != 0)
						{
							num2 = 48;
							continue;
						}
						continue;
					case 6:
						goto IL_4B9;
					case 7:
						base.ClientSize = new Size(496, 324);
						num2 = 21;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_114c8e4d680c4b9997b685901f6ff336 == 0)
						{
							num2 = 5;
							continue;
						}
						continue;
					case 8:
						base.SuspendLayout();
						num2 = 73;
						continue;
					case 9:
						Form2.k1Iit2UP4gZsEJZDc98(this.guna2TextBox1, true);
						num2 = 56;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_1895b09984304f78868023ed6e046da0 == 0)
						{
							num2 = 36;
							continue;
						}
						continue;
					case 10:
						Form2.IMxc3bU3jNG2j5HwEBw(this.guna2Button1, new Size(130, 41));
						num2 = 55;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_289b03d4275042dab02535e36c7e14db == 0)
						{
							num2 = 52;
							continue;
						}
						continue;
					case 11:
						Form2.gWyi8EUwKNqjqdLHIlM(this.guna2DragControl1, true);
						num2 = 64;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_6e7080206d494848a398a0198996a1e6 != 0)
						{
							num2 = 13;
							continue;
						}
						continue;
					case 12:
						Form2.ra2vfVZJCMEuEhMMQ7v(this.guna2BorderlessForm1, false);
						num2 = 52;
						continue;
					case 13:
						Form2.FcyjsuZDSTrIxyFxyHn(this.guna2TextBox1, new Point(12, 53));
						num2 = 2;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_1eba0904f5ed439aa0e9edb8d6f647ef == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 14:
						Form2.FDyqQLUQkII9VVE8anO(this, vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-2083830725 ^ -2083847999));
						num2 = 34;
						continue;
					case 15:
						Form2.Pk4VebUoqg8uiaDjmWs(this.guna2Button2, Form2.WFxGsqUdG9d2fcTxsMc());
						num2 = 43;
						continue;
					case 16:
						Form2.bSpB19UZtgICmv7Pw6L(this, Form2.nm4S6LZjV87TK7bxGob(1657092858 << 1 ^ -980799218));
						num2 = 32;
						continue;
					case 17:
						Form2.gAMaonUc3WT7AKuFwkZ(this.guna2Button2, 3);
						num2 = 31;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_e9a32e0c5583434583e6a99f38209d4e != 0)
						{
							num2 = 37;
							continue;
						}
						continue;
					case 18:
						this.guna2TextBox1.BorderRadius = 10;
						num2 = 27;
						continue;
					case 19:
						this.guna2Button1 = new Guna2Button();
						num2 = 66;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_8590fa2330a9409ebec2e2249b244600 != 0)
						{
							num2 = 31;
							continue;
						}
						continue;
					case 20:
						this.guna2Button2 = new Guna2Button();
						num2 = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_d6675f44e192471dbaeaf2d22fed78ae != 0)
						{
							num2 = 8;
							continue;
						}
						continue;
					case 21:
						base.ControlBox = false;
						num2 = 49;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_e008bee02c10447c9c4063221ddff8d1 == 0)
						{
							num2 = 30;
							continue;
						}
						continue;
					case 22:
						this.label1.Name = Form2.nm4S6LZjV87TK7bxGob(1657226489 - -588572257 ^ -2049175038);
						num2 = 53;
						continue;
					case 23:
						Form2.dX33pHUydViUXr9bXwo(Form2.utuV9bUVfP8YEHTgE8c(this.guna2Button2), Form2.bAkfnHZYgo0NcAy2p0n(169, 169, 169));
						num2 = 57;
						continue;
					case 24:
						Form2.OiYkW4UulhDrRhQgIMU(this.guna2Button1.DisabledState, Form2.CeT0YgUxvPHyvAYETgX());
						num2 = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_acfa09b970e04d3e89283a58545b6d36 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 25:
						Form2.NlCs39Zbe7pWYi9cOyF(this.guna2Button2, Form2.nm4S6LZjV87TK7bxGob(-1745773992 ^ -1745771702));
						num2 = 27;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_408cdf8d10324497825639e7638db7b2 != 0)
						{
							num2 = 54;
							continue;
						}
						continue;
					case 26:
						this.guna2DragControl1.DockIndicatorTransparencyValue = 0.6;
						num2 = 1;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0d042870c9044e3385234a5737b1d0da == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 27:
						goto IL_B06;
					case 28:
						Form2.cQkEfKZt6vEJR7E9e1a(this.guna2TextBox1, "");
						Form2.ktGychZssMSZRnUgHpU(this.guna2TextBox1.DisabledState, Form2.bAkfnHZYgo0NcAy2p0n(208, 208, 208));
						Form2.YKu4cqZguHsrM837GlO(this.guna2TextBox1).FillColor = Color.FromArgb(226, 226, 226);
						num2 = 31;
						continue;
					case 29:
						Form2.Q78r1VUqBflpkHEARR4(this.label1, new Font(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(790722942 ^ 790712804), 13.8f, FontStyle.Regular, GraphicsUnit.Point, 0));
						num2 = 46;
						continue;
					case 30:
						Form2.Pk4VebUoqg8uiaDjmWs(this.guna2Button1, Form2.WFxGsqUdG9d2fcTxsMc());
						num2 = 45;
						continue;
					case 31:
						Form2.g4EB5AZXRpyEvQMqKtt(Form2.YKu4cqZguHsrM837GlO(this.guna2TextBox1), Form2.bAkfnHZYgo0NcAy2p0n(138, 138, 138));
						num2 = 19;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_c7104ccd40024e009409c6d14eb5a99a == 0)
						{
							num2 = 50;
							continue;
						}
						continue;
					case 32:
						base.StartPosition = FormStartPosition.CenterParent;
						num2 = 14;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_6fd435aca0274a86955ba7bbb960082d == 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 33:
						Form2.btJ0dAZnx2V6pNiRLpn(this.guna2BorderlessForm1, this);
						num2 = 41;
						continue;
					case 34:
						base.ResumeLayout(false);
						Form2.CceTgDUUc2iLIIo2Evi(this);
						num2 = 35;
						continue;
					case 35:
						return;
					case 36:
						Form2.FDh0T6UCxLjTgMS69CP(this.guna2Button1, new EventHandler(this.OubcW7EVAT));
						Form2.lDTfaLU9y6MU09oJo9p(this.label1, true);
						num2 = 4;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_c609793e83ea4d9f8a76fd0fe20634d3 != 0)
						{
							num2 = 29;
							continue;
						}
						continue;
					case 37:
						Form2.FDyqQLUQkII9VVE8anO(this.guna2Button2, Form2.nm4S6LZjV87TK7bxGob(790722942 ^ 790707600));
						num2 = 59;
						continue;
					case 38:
						Form2.tO6MOXZBHiSffrhjZuQ(this.guna2TextBox1, new Font(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-789419076 ^ -35552607 ^ 756269345), 9f));
						num2 = 62;
						continue;
					case 39:
						goto IL_C3A;
					case 40:
						Form2.gAMaonUc3WT7AKuFwkZ(this.guna2TextBox1, 0);
						num2 = 58;
						continue;
					case 41:
						Form2.o777SuZ0n3ESisbxdZU(this.guna2BorderlessForm1, 0.6);
						num2 = 12;
						continue;
					case 42:
						this.guna2Button1.DisabledState.BorderColor = Form2.CeT0YgUxvPHyvAYETgX();
						num2 = 19;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_c02245dc84a14a53adc46bd8002cd2b2 == 0)
						{
							num2 = 24;
							continue;
						}
						continue;
					case 43:
						this.guna2Button2.Location = new Point(12, 268);
						num2 = 25;
						continue;
					case 44:
						Form2.ud1gRlUixIkvlpnk14F(Form2.eHYMC6UIDXLpjMOuWwt(this), this.guna2Button1);
						num2 = 68;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_57b2e386d0354e0b85dd8e8db78e6c05 != 0)
						{
							num2 = 12;
							continue;
						}
						continue;
					case 45:
						goto IL_273;
					case 46:
						Form2.FcyjsuZDSTrIxyFxyHn(this.label1, new Point(12, 13));
						num2 = 20;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_923d36d0be6e41d5945d4b2a6e0fe214 == 0)
						{
							num2 = 22;
							continue;
						}
						continue;
					case 47:
						this.guna2TextBox1.Size = new Size(470, 204);
						num2 = 40;
						continue;
					case 48:
						goto IL_68A;
					case 49:
						Form2.eHYMC6UIDXLpjMOuWwt(this).Add(this.guna2Button2);
						Form2.eHYMC6UIDXLpjMOuWwt(this).Add(this.label1);
						num2 = 44;
						continue;
					case 50:
						Form2.TFd801ZMCbHnI6oaFJ6(Form2.YKu4cqZguHsrM837GlO(this.guna2TextBox1), Form2.bAkfnHZYgo0NcAy2p0n(138, 138, 138));
						num2 = 69;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_669639b2fc7d4196b99820c1478aeb2d == 0)
						{
							num2 = 39;
							continue;
						}
						continue;
					case 51:
						Form2.NlCs39Zbe7pWYi9cOyF(this.guna2Button1, vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1734223699 - -1503209248 ^ -231025687));
						num2 = 10;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0656062713004318aa3a835b6bf28eab == 0)
						{
							num2 = 10;
							continue;
						}
						continue;
					case 52:
						Form2.Rq8sVQZmEJ9lOomxoYE(this.guna2BorderlessForm1, true);
						num2 = 18;
						continue;
					case 53:
						Form2.IMxc3bU3jNG2j5HwEBw(this.label1, new Size(80, 29));
						num2 = 70;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_5d83dab2d7c4415687f4df21e1f4a0a7 == 0)
						{
							num2 = 16;
							continue;
						}
						continue;
					case 54:
						Form2.IMxc3bU3jNG2j5HwEBw(this.guna2Button2, new Size(122, 41));
						num2 = 17;
						continue;
					case 55:
						Form2.gAMaonUc3WT7AKuFwkZ(this.guna2Button1, 1);
						num2 = 72;
						continue;
					case 56:
						this.guna2TextBox1.ScrollBars = ScrollBars.Both;
						num2 = 63;
						continue;
					case 57:
						Form2.utuV9bUVfP8YEHTgE8c(this.guna2Button2).ForeColor = Color.FromArgb(141, 141, 141);
						num2 = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_b018848e194944659fd6bf9f5a1f9097 == 0)
						{
							num2 = 67;
							continue;
						}
						continue;
					case 58:
						Form2.yDNdFKU5vCvNtstfMFr(this.guna2Button1, 15);
						num2 = 42;
						continue;
					case 59:
						this.guna2Button2.Click += this.HN3cPvkxEc;
						num2 = 60;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_d7db82c175de47d2b5f36bc0c7f71006 != 0)
						{
							num2 = 7;
							continue;
						}
						continue;
					case 60:
						Form2.YOxfchUSRegdIdIq3IR(this, new SizeF(8f, 16f));
						base.AutoScaleMode = AutoScaleMode.Font;
						num2 = 7;
						continue;
					case 61:
						Form2.U8mRLxUApmDYL0jrl9J(Form2.utuV9bUVfP8YEHTgE8c(this.guna2Button2), Form2.CeT0YgUxvPHyvAYETgX());
						num2 = 65;
						continue;
					case 62:
						Form2.ktGychZssMSZRnUgHpU(this.guna2TextBox1.HoverState, Form2.bAkfnHZYgo0NcAy2p0n(94, 148, 255));
						num2 = 13;
						continue;
					case 63:
						Form2.QmF0nVUEMkKEC9DExwZ(this.guna2TextBox1, "");
						num2 = 47;
						continue;
					case 64:
						Form2.yDNdFKU5vCvNtstfMFr(this.guna2Button2, 15);
						num2 = 61;
						continue;
					case 65:
						this.guna2Button2.DisabledState.CustomBorderColor = Form2.CeT0YgUxvPHyvAYETgX();
						num2 = 23;
						continue;
					case 66:
						this.label1 = new Label();
						num2 = 71;
						continue;
					case 67:
						Form2.u27vHMUh5iHfHYTqLMm(this.guna2Button2, Color.FromArgb(255, 128, 0));
						this.guna2Button2.Font = new Font(Form2.nm4S6LZjV87TK7bxGob(881693030 + 414722879 ^ 1296405657), 9f);
						num2 = 7;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_114c8e4d680c4b9997b685901f6ff336 != 0)
						{
							num2 = 15;
							continue;
						}
						continue;
					case 68:
						Form2.ud1gRlUixIkvlpnk14F(Form2.eHYMC6UIDXLpjMOuWwt(this), this.guna2TextBox1);
						num2 = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_6b44d6635c594e2d8eb32a8d702c09e9 != 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 69:
						Form2.ktGychZssMSZRnUgHpU(Form2.hjPoFAZGY9m0jAgr5UZ(this.guna2TextBox1), Color.FromArgb(94, 148, 255));
						num2 = 38;
						continue;
					case 70:
						Form2.gAMaonUc3WT7AKuFwkZ(this.label1, 2);
						num2 = 4;
						continue;
					case 71:
						this.guna2DragControl1 = new Guna2DragControl(this.components);
						num2 = 20;
						continue;
					case 72:
						Form2.FDyqQLUQkII9VVE8anO(this.guna2Button1, vua32v5yjQhjRjK4YIO.BRA5TcZvlv(1765342390 ^ 1765324886));
						num2 = 36;
						continue;
					case 73:
						goto IL_CB8;
					case 74:
						Form2.tPjygPU8m5BvyKf9pbu(this.guna2Button1.DisabledState, Color.FromArgb(141, 141, 141));
						Form2.Q78r1VUqBflpkHEARR4(this.guna2Button1, new Font(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-789419076 ^ -35552607 ^ 756269345), 9f));
						num2 = 30;
						continue;
					}
					Form2.dX33pHUydViUXr9bXwo(Form2.utuV9bUVfP8YEHTgE8c(this.guna2Button1), Form2.bAkfnHZYgo0NcAy2p0n(169, 169, 169));
					num2 = 74;
				}
				IL_273:
				this.guna2Button1.Location = new Point(352, 268);
				num = 51;
				continue;
				IL_4B9:
				this.components = new Container();
				num = 5;
				continue;
				IL_68A:
				this.guna2TextBox1 = new Guna2TextBox();
				num = 19;
				continue;
				IL_B06:
				this.guna2TextBox1.Cursor = Form2.vxVgGqZH4eWtS2WnIQ5();
				num = 28;
				continue;
				IL_C3A:
				Form2.GZ8UkWUWTFPy15TjyQk(this.guna2TextBox1, "");
				num = 9;
				continue;
				IL_CB8:
				Form2.xlGIroZN1MxllMGrNJr(this.guna2BorderlessForm1, 15);
				num = 33;
			}
		}

		// Token: 0x060003F0 RID: 1008 RVA: 0x00026C80 File Offset: 0x00024E80
		// Note: this type is marked as 'beforefieldinit'.
		static Form2()
		{
			Form2.io2hwrU1iUC5BsvFH06();
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x00026C90 File Offset: 0x00024E90
		internal static void W2qyHcZeMOymmoRFyPj()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x00026CA0 File Offset: 0x00024EA0
		internal static void maJvfXZkEHInXjcAQfK()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x00026CB0 File Offset: 0x00024EB0
		internal static bool wFQwweZaW9eeTBQEjDB()
		{
			return Form2.V4eCK9ZlTPhqakoaKxl == null;
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x00026CC4 File Offset: 0x00024EC4
		internal static Form2 Rb9Mi6ZKeGnvt1SyYGs()
		{
			return Form2.V4eCK9ZlTPhqakoaKxl;
		}

		// Token: 0x060003F5 RID: 1013 RVA: 0x00026CD4 File Offset: 0x00024ED4
		internal static void BSc88JZrmSOnkHTpwAS(object A_0)
		{
			A_0.Close();
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x00026CE8 File Offset: 0x00024EE8
		internal static void icG9NyZ7e7C9Y6s0PTb(object A_0, object A_1)
		{
			A_0.Text = A_1;
		}

		// Token: 0x060003F7 RID: 1015 RVA: 0x00026D00 File Offset: 0x00024F00
		internal static bool xoQaRWZ2BMyrTi1eb4O(object A_0, object A_1)
		{
			return A_0 != A_1;
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x00026D18 File Offset: 0x00024F18
		internal static void a7PmI0Z62Y1Sex25Im5(object A_0)
		{
			((IDisposable)A_0).Dispose();
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x00026D2C File Offset: 0x00024F2C
		internal static void xlGIroZN1MxllMGrNJr(object A_0, int A_1)
		{
			A_0.BorderRadius = A_1;
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x00026D44 File Offset: 0x00024F44
		internal static void btJ0dAZnx2V6pNiRLpn(object A_0, object A_1)
		{
			A_0.ContainerControl = A_1;
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x00026D5C File Offset: 0x00024F5C
		internal static void o777SuZ0n3ESisbxdZU(object A_0, double A_1)
		{
			A_0.DockIndicatorTransparencyValue = A_1;
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x00026D74 File Offset: 0x00024F74
		internal static void ra2vfVZJCMEuEhMMQ7v(object A_0, bool A_1)
		{
			A_0.ResizeForm = A_1;
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x00026D8C File Offset: 0x00024F8C
		internal static void Rq8sVQZmEJ9lOomxoYE(object A_0, bool A_1)
		{
			A_0.TransparentWhileDrag = A_1;
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x00026DA4 File Offset: 0x00024FA4
		internal static object vxVgGqZH4eWtS2WnIQ5()
		{
			return Cursors.IBeam;
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x00026DB4 File Offset: 0x00024FB4
		internal static void cQkEfKZt6vEJR7E9e1a(object A_0, object A_1)
		{
			A_0.DefaultText = A_1;
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x00026DCC File Offset: 0x00024FCC
		internal static Color bAkfnHZYgo0NcAy2p0n(int A_0, int A_1, int A_2)
		{
			return Color.FromArgb(A_0, A_1, A_2);
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x00026DE8 File Offset: 0x00024FE8
		internal static void ktGychZssMSZRnUgHpU(object A_0, Color A_1)
		{
			A_0.BorderColor = A_1;
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x00026E00 File Offset: 0x00025000
		internal static object YKu4cqZguHsrM837GlO(object A_0)
		{
			return A_0.DisabledState;
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x00026E14 File Offset: 0x00025014
		internal static void g4EB5AZXRpyEvQMqKtt(object A_0, Color A_1)
		{
			A_0.ForeColor = A_1;
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x00026E2C File Offset: 0x0002502C
		internal static void TFd801ZMCbHnI6oaFJ6(object A_0, Color A_1)
		{
			A_0.PlaceholderForeColor = A_1;
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x00026E44 File Offset: 0x00025044
		internal static object hjPoFAZGY9m0jAgr5UZ(object A_0)
		{
			return A_0.FocusedState;
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x00026E58 File Offset: 0x00025058
		internal static void tO6MOXZBHiSffrhjZuQ(object A_0, object A_1)
		{
			A_0.Font = A_1;
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x00026E70 File Offset: 0x00025070
		internal static void FcyjsuZDSTrIxyFxyHn(object A_0, Point A_1)
		{
			A_0.Location = A_1;
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x00026E88 File Offset: 0x00025088
		internal static void x2ebkIZv1d8qMhESuxb(object A_0, bool A_1)
		{
			A_0.Multiline = A_1;
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x00026EA0 File Offset: 0x000250A0
		internal static object nm4S6LZjV87TK7bxGob(int \u0020)
		{
			return vua32v5yjQhjRjK4YIO.BRA5TcZvlv(\u0020);
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x00026EB4 File Offset: 0x000250B4
		internal static void NlCs39Zbe7pWYi9cOyF(object A_0, object A_1)
		{
			A_0.Name = A_1;
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x00026ECC File Offset: 0x000250CC
		internal static void eavvrPZzwq5pJVTkiwA(object A_0, char A_1)
		{
			A_0.PasswordChar = A_1;
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x00026EE4 File Offset: 0x000250E4
		internal static void GZ8UkWUWTFPy15TjyQk(object A_0, object A_1)
		{
			A_0.PlaceholderText = A_1;
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x00026EFC File Offset: 0x000250FC
		internal static void k1Iit2UP4gZsEJZDc98(object A_0, bool A_1)
		{
			A_0.ReadOnly = A_1;
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x00026F14 File Offset: 0x00025114
		internal static void QmF0nVUEMkKEC9DExwZ(object A_0, object A_1)
		{
			A_0.SelectedText = A_1;
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x00026F2C File Offset: 0x0002512C
		internal static void gAMaonUc3WT7AKuFwkZ(object A_0, int A_1)
		{
			A_0.TabIndex = A_1;
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x00026F44 File Offset: 0x00025144
		internal static void yDNdFKU5vCvNtstfMFr(object A_0, int A_1)
		{
			A_0.BorderRadius = A_1;
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x00026F5C File Offset: 0x0002515C
		internal static Color CeT0YgUxvPHyvAYETgX()
		{
			return Color.DarkGray;
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x00026F6C File Offset: 0x0002516C
		internal static void OiYkW4UulhDrRhQgIMU(object A_0, Color A_1)
		{
			A_0.CustomBorderColor = A_1;
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x00026F84 File Offset: 0x00025184
		internal static object utuV9bUVfP8YEHTgE8c(object A_0)
		{
			return A_0.DisabledState;
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x00026F98 File Offset: 0x00025198
		internal static void dX33pHUydViUXr9bXwo(object A_0, Color A_1)
		{
			A_0.FillColor = A_1;
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x00026FB0 File Offset: 0x000251B0
		internal static void tPjygPU8m5BvyKf9pbu(object A_0, Color A_1)
		{
			A_0.ForeColor = A_1;
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x00026FC8 File Offset: 0x000251C8
		internal static void Q78r1VUqBflpkHEARR4(object A_0, object A_1)
		{
			A_0.Font = A_1;
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x00026FE0 File Offset: 0x000251E0
		internal static Color WFxGsqUdG9d2fcTxsMc()
		{
			return Color.White;
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x00026FF0 File Offset: 0x000251F0
		internal static void Pk4VebUoqg8uiaDjmWs(object A_0, Color A_1)
		{
			A_0.ForeColor = A_1;
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x00027008 File Offset: 0x00025208
		internal static void IMxc3bU3jNG2j5HwEBw(object A_0, Size A_1)
		{
			A_0.Size = A_1;
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x00027020 File Offset: 0x00025220
		internal static void FDyqQLUQkII9VVE8anO(object A_0, object A_1)
		{
			A_0.Text = A_1;
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x00027038 File Offset: 0x00025238
		internal static void FDh0T6UCxLjTgMS69CP(object A_0, object A_1)
		{
			A_0.Click += A_1;
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x00027050 File Offset: 0x00025250
		internal static void lDTfaLU9y6MU09oJo9p(object A_0, bool A_1)
		{
			A_0.AutoSize = A_1;
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x00027068 File Offset: 0x00025268
		internal static void gWyi8EUwKNqjqdLHIlM(object A_0, bool A_1)
		{
			A_0.UseTransparentDrag = A_1;
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x00027080 File Offset: 0x00025280
		internal static void U8mRLxUApmDYL0jrl9J(object A_0, Color A_1)
		{
			A_0.BorderColor = A_1;
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x00027098 File Offset: 0x00025298
		internal static void u27vHMUh5iHfHYTqLMm(object A_0, Color A_1)
		{
			A_0.FillColor = A_1;
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x000270B0 File Offset: 0x000252B0
		internal static void YOxfchUSRegdIdIq3IR(object A_0, SizeF A_1)
		{
			A_0.AutoScaleDimensions = A_1;
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x000270C8 File Offset: 0x000252C8
		internal static object eHYMC6UIDXLpjMOuWwt(object A_0)
		{
			return A_0.Controls;
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x000270DC File Offset: 0x000252DC
		internal static void ud1gRlUixIkvlpnk14F(object A_0, object A_1)
		{
			A_0.Add(A_1);
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x000270F4 File Offset: 0x000252F4
		internal static void bSpB19UZtgICmv7Pw6L(object A_0, object A_1)
		{
			A_0.Name = A_1;
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x0002710C File Offset: 0x0002530C
		internal static void CceTgDUUc2iLIIo2Evi(object A_0)
		{
			A_0.PerformLayout();
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x00027120 File Offset: 0x00025320
		internal static void io2hwrU1iUC5BsvFH06()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x040001A7 RID: 423
		private Guna2BorderlessForm guna2BorderlessForm1;

		// Token: 0x040001A8 RID: 424
		private Label label1;

		// Token: 0x040001A9 RID: 425
		private Guna2Button guna2Button1;

		// Token: 0x040001AA RID: 426
		private Guna2TextBox guna2TextBox1;

		// Token: 0x040001AB RID: 427
		private Guna2DragControl guna2DragControl1;

		// Token: 0x040001AC RID: 428
		private Guna2Button guna2Button2;

		// Token: 0x040001AD RID: 429
		private static Form2 V4eCK9ZlTPhqakoaKxl;
	}
}
