﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace RotationLabEngine
{
	// Token: 0x0200003D RID: 61
	public class BuffsDebuffs
	{
		// Token: 0x06000572 RID: 1394 RVA: 0x0002D600 File Offset: 0x0002B800
		public BuffsDebuffs()
		{
			BuffsDebuffs.y5LJO14GYlW0L4pTDHN();
			BuffsDebuffs.HuxRiE4Bb187Rd0ojMO();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_f8f2733f262849f48168e4f76ab239d7 == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x0002D660 File Offset: 0x0002B860
		// Note: this type is marked as 'beforefieldinit'.
		static BuffsDebuffs()
		{
			BuffsDebuffs.PsnEBH4DcLHeKlcbyE0();
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x0002D670 File Offset: 0x0002B870
		internal static void y5LJO14GYlW0L4pTDHN()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x0002D680 File Offset: 0x0002B880
		internal static void HuxRiE4Bb187Rd0ojMO()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x06000576 RID: 1398 RVA: 0x0002D690 File Offset: 0x0002B890
		internal static bool aWINCC4XefQGpZxD1GF()
		{
			return BuffsDebuffs.FtUIWV4gTFdF1EB5mPm == null;
		}

		// Token: 0x06000577 RID: 1399 RVA: 0x0002D6A4 File Offset: 0x0002B8A4
		internal static BuffsDebuffs ToIgRV4MSKMm6bTdZSa()
		{
			return BuffsDebuffs.FtUIWV4gTFdF1EB5mPm;
		}

		// Token: 0x06000578 RID: 1400 RVA: 0x0002D6B4 File Offset: 0x0002B8B4
		internal static void PsnEBH4DcLHeKlcbyE0()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x04000252 RID: 594
		public int Index;

		// Token: 0x04000253 RID: 595
		public int TimeRemaining;

		// Token: 0x04000254 RID: 596
		public bool SrcPlayer;

		// Token: 0x04000255 RID: 597
		public int Stacks;

		// Token: 0x04000256 RID: 598
		internal static BuffsDebuffs FtUIWV4gTFdF1EB5mPm;
	}
}
