﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;

namespace RotationLabEngine
{
	// Token: 0x02000036 RID: 54
	public static class RuneType
	{
		// Token: 0x0600054A RID: 1354 RVA: 0x0002D0C4 File Offset: 0x0002B2C4
		// Note: this type is marked as 'beforefieldinit'.
		static RuneType()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x04000207 RID: 519
		public const int None = 0;

		// Token: 0x04000208 RID: 520
		public const int Blood = 1;

		// Token: 0x04000209 RID: 521
		public const int Unholy = 2;

		// Token: 0x0400020A RID: 522
		public const int Frost = 3;

		// Token: 0x0400020B RID: 523
		public const int Death = 4;
	}
}
