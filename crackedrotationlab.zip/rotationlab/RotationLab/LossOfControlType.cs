﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;

namespace RotationLabEngine
{
	// Token: 0x02000032 RID: 50
	public static class LossOfControlType
	{
		// Token: 0x06000543 RID: 1347 RVA: 0x0002D054 File Offset: 0x0002B254
		// Note: this type is marked as 'beforefieldinit'.
		static LossOfControlType()
		{
			LossOfControlType.SE9Eis497c0ibgiLT19();
		}

		// Token: 0x06000544 RID: 1348 RVA: 0x0002D064 File Offset: 0x0002B264
		internal static void SE9Eis497c0ibgiLT19()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x040001DE RID: 478
		public const int STUN = 1;

		// Token: 0x040001DF RID: 479
		public const int SCHOOL_INTERRUPT = 2;

		// Token: 0x040001E0 RID: 480
		public const int DISARM = 3;

		// Token: 0x040001E1 RID: 481
		public const int PACIFYSILENCE = 4;

		// Token: 0x040001E2 RID: 482
		public const int SILENCE = 5;

		// Token: 0x040001E3 RID: 483
		public const int PACIFY = 6;

		// Token: 0x040001E4 RID: 484
		public const int ROOT = 7;

		// Token: 0x040001E5 RID: 485
		public const int FEAR = 8;

		// Token: 0x040001E6 RID: 486
		public const int CHARM = 9;

		// Token: 0x040001E7 RID: 487
		public const int CONFUSE = 10;

		// Token: 0x040001E8 RID: 488
		public const int POSSESS = 11;
	}
}
