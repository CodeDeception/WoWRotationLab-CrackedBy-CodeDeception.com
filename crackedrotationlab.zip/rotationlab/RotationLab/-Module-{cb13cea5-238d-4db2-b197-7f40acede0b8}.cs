﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;
using z6sH8Cxtx1xCxjgcS7P;

// Token: 0x0200009D RID: 157
internal sealed class <Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}
{
	// Token: 0x06000D8A RID: 3466 RVA: 0x0006C528 File Offset: 0x0006A728
	// Note: this type is marked as 'beforefieldinit'.
	static <Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}()
	{
		<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.kle3EK08dAW3SxL5UhN();
		<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.zJEiPu0qyQ82TV3Xqg1();
		int num = 0;
		if (!true)
		{
			num = 0;
		}
		for (;;)
		{
			switch (num)
			{
			default:
				<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.jAwGfy0dEOyeNVyFNPR();
				num = 1;
				if (!true)
				{
					num = 0;
				}
				break;
			case 1:
				return;
			}
		}
	}

	// Token: 0x06000D8B RID: 3467 RVA: 0x0006C598 File Offset: 0x0006A798
	internal static void xfbebda61de6545d9b3b8bf386646e2c6()
	{
		int num = 1;
		int num2 = num;
		object[] u;
		for (;;)
		{
			switch (num2)
			{
			case 1:
				u = new object[0];
				num2 = 0;
				if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.ARan0t0yNbPHjJkQM31() == null)
				{
					num2 = 0;
					continue;
				}
				continue;
			}
			break;
		}
		ykD11HxHfZBYH7OcFOG.by2xXOQ8u6(1, u, null);
	}

	// Token: 0x06000D8C RID: 3468 RVA: 0x0006C60C File Offset: 0x0006A80C
	internal static void kle3EK08dAW3SxL5UhN()
	{
		vua32v5yjQhjRjK4YIO.aep5UvAyyY();
	}

	// Token: 0x06000D8D RID: 3469 RVA: 0x0006C61C File Offset: 0x0006A81C
	internal static void zJEiPu0qyQ82TV3Xqg1()
	{
		vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
	}

	// Token: 0x06000D8E RID: 3470 RVA: 0x0006C62C File Offset: 0x0006A82C
	internal static void jAwGfy0dEOyeNVyFNPR()
	{
		<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.xfbebda61de6545d9b3b8bf386646e2c6();
	}

	// Token: 0x06000D8F RID: 3471 RVA: 0x0006C63C File Offset: 0x0006A83C
	internal static bool f3LLGu0VECMU6WmhtHS()
	{
		return <Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.FXh1E80ubRbXCgl7wdd == null;
	}

	// Token: 0x06000D90 RID: 3472 RVA: 0x0006C650 File Offset: 0x0006A850
	internal static <Module>{cb13cea5-238d-4db2-b197-7f40acede0b8} ARan0t0yNbPHjJkQM31()
	{
		return <Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.FXh1E80ubRbXCgl7wdd;
	}

	// Token: 0x04000433 RID: 1075
	internal static int m_8587ff20fd5f487a89bfe65d8ab138e4;

	// Token: 0x04000434 RID: 1076
	internal static int m_c8b0d443bf9b43f59672b15574afc30a;

	// Token: 0x04000435 RID: 1077
	internal static int m_28ebedbdab9e4e3895d75e5b9bfb0d5f;

	// Token: 0x04000436 RID: 1078
	internal static int m_daf45904bfaa4c9ca932e5fef26f8db2;

	// Token: 0x04000437 RID: 1079
	internal static int m_6b44d6635c594e2d8eb32a8d702c09e9;

	// Token: 0x04000438 RID: 1080
	internal static int m_62a8cf43711147aba48e59420bf61060;

	// Token: 0x04000439 RID: 1081
	internal static int m_0d042870c9044e3385234a5737b1d0da;

	// Token: 0x0400043A RID: 1082
	internal static int m_fbdcf9cf6ee44fc984b2109059e5d2e6;

	// Token: 0x0400043B RID: 1083
	internal static int m_6e7080206d494848a398a0198996a1e6;

	// Token: 0x0400043C RID: 1084
	internal static int m_484d9dff0be247d0909491a365bde396;

	// Token: 0x0400043D RID: 1085
	internal static int m_e4c3e507bea3489ca1e59bddf0d58f83;

	// Token: 0x0400043E RID: 1086
	internal static int m_923d36d0be6e41d5945d4b2a6e0fe214;

	// Token: 0x0400043F RID: 1087
	internal static int m_b018848e194944659fd6bf9f5a1f9097;

	// Token: 0x04000440 RID: 1088
	internal static int m_57b2e386d0354e0b85dd8e8db78e6c05;

	// Token: 0x04000441 RID: 1089
	internal static int m_e0aba0d9fb124085a8bd5fdd21baeb5d;

	// Token: 0x04000442 RID: 1090
	internal static int m_f33e632e358f4933afb605f58e8b0859;

	// Token: 0x04000443 RID: 1091
	internal static int m_289b03d4275042dab02535e36c7e14db;

	// Token: 0x04000444 RID: 1092
	internal static int m_e3b631d8a3e54afc92ab7132d2862d60;

	// Token: 0x04000445 RID: 1093
	internal static int m_24213672444f404ab1c51fbb2634eb8c;

	// Token: 0x04000446 RID: 1094
	internal static int m_1895b09984304f78868023ed6e046da0;

	// Token: 0x04000447 RID: 1095
	internal static int m_2a54bde8cc7e419395a5bfe6af1796c0;

	// Token: 0x04000448 RID: 1096
	internal static int m_fd0c1f052d0e476eab1db9043408a8d6;

	// Token: 0x04000449 RID: 1097
	internal static int m_a8b0fe86ca414d59a00505e4688a2028;

	// Token: 0x0400044A RID: 1098
	internal static int m_91bfb50313e244f4ba50c746ee3a2624;

	// Token: 0x0400044B RID: 1099
	internal static int m_1259d5d4e4144ef5a0c05f808ad73078;

	// Token: 0x0400044C RID: 1100
	internal static int m_bbde65f049484d1e84226476c9c6bfea;

	// Token: 0x0400044D RID: 1101
	internal static int m_40d264c41f474fea9eba2908d12918c1;

	// Token: 0x0400044E RID: 1102
	internal static int m_337ad221e95e4d7f9f7c49af16666ee6;

	// Token: 0x0400044F RID: 1103
	internal static int m_815f08b431b44ac887f007356b7a532a;

	// Token: 0x04000450 RID: 1104
	internal static int m_ce59933fd09643e182b90c09334cb5d2;

	// Token: 0x04000451 RID: 1105
	internal static int m_24c6414a8a5b4f2680c42f1a5855f977;

	// Token: 0x04000452 RID: 1106
	internal static int m_e1a603e3ded74e569c1ef8e445f3828e;

	// Token: 0x04000453 RID: 1107
	internal static int m_82ef02aa8b754adb8434f8a772d183e3;

	// Token: 0x04000454 RID: 1108
	internal static int m_f6be3324a0314b2e90c5fdfd38911414;

	// Token: 0x04000455 RID: 1109
	internal static int m_2450e204911e419ba8c7c2ba4ba001f5;

	// Token: 0x04000456 RID: 1110
	internal static int m_1ab95fbf5c0845689e9d97c1311c612e;

	// Token: 0x04000457 RID: 1111
	internal static int m_32f345487a004baaa2d77f4407dc7bbc;

	// Token: 0x04000458 RID: 1112
	internal static int m_5a783af3da954710be4da15470ca6dd2;

	// Token: 0x04000459 RID: 1113
	internal static int m_b8bb7cdbcd66488bbe9aea1b375752f3;

	// Token: 0x0400045A RID: 1114
	internal static int m_69e534c26f724032be7eb1d4c6a60655;

	// Token: 0x0400045B RID: 1115
	internal static int m_5570c327a6334a12993e71a93a06169a;

	// Token: 0x0400045C RID: 1116
	internal static int m_b58cc6448c07462981f7780e6183361e;

	// Token: 0x0400045D RID: 1117
	internal static int m_912464c7521643f2968751cbbc64f3cf;

	// Token: 0x0400045E RID: 1118
	internal static int m_fa027ca03d194169b4d4b16c724923ba;

	// Token: 0x0400045F RID: 1119
	internal static int m_e261d078e14d4a5882d9023bb7f6495a;

	// Token: 0x04000460 RID: 1120
	internal static int m_f9e98f6a964b4abbaedd241bdefc81fd;

	// Token: 0x04000461 RID: 1121
	internal static int m_37a20c2e025c4269a91da4cf2ed7e3df;

	// Token: 0x04000462 RID: 1122
	internal static int m_cd978457d1e445849b2a5ed79e10da71;

	// Token: 0x04000463 RID: 1123
	internal static int m_e9a32e0c5583434583e6a99f38209d4e;

	// Token: 0x04000464 RID: 1124
	internal static int m_f1e441e915f3465198512fda3e140bf5;

	// Token: 0x04000465 RID: 1125
	internal static int m_d7db82c175de47d2b5f36bc0c7f71006;

	// Token: 0x04000466 RID: 1126
	internal static int m_6ecdbee983964eca9eb75beb96e5f7ee;

	// Token: 0x04000467 RID: 1127
	internal static int m_d95aff6635834f54a612ecd769021757;

	// Token: 0x04000468 RID: 1128
	internal static int m_e008bee02c10447c9c4063221ddff8d1;

	// Token: 0x04000469 RID: 1129
	internal static int m_a65af4741e8c4e4da9b36e623cb150b3;

	// Token: 0x0400046A RID: 1130
	internal static int m_521a515f15c94d10b5254529acc6f115;

	// Token: 0x0400046B RID: 1131
	internal static int m_54c2f8a2b1dd479e83e6b60054e43e88;

	// Token: 0x0400046C RID: 1132
	internal static int m_a4220304efac479885fc7bed52e95949;

	// Token: 0x0400046D RID: 1133
	internal static int m_5d40d00282484c3192de8d3f455be896;

	// Token: 0x0400046E RID: 1134
	internal static int m_408cdf8d10324497825639e7638db7b2;

	// Token: 0x0400046F RID: 1135
	internal static int m_0e5e3d7d8cdf4d2a9040ab7043b65fe6;

	// Token: 0x04000470 RID: 1136
	internal static int m_10efcbc7d65a482a889c795c7b640c03;

	// Token: 0x04000471 RID: 1137
	internal static int m_b7f67e3eba18452ab17dba1f1cebde43;

	// Token: 0x04000472 RID: 1138
	internal static int m_c02245dc84a14a53adc46bd8002cd2b2;

	// Token: 0x04000473 RID: 1139
	internal static int m_f247572d217b4ec7bd891923cd5e68bf;

	// Token: 0x04000474 RID: 1140
	internal static int m_14783df6d9f947ad8c31e2be62e41a18;

	// Token: 0x04000475 RID: 1141
	internal static int m_a5d4b7819e164965bb08f6d803806b82;

	// Token: 0x04000476 RID: 1142
	internal static int m_f67918d8ca3e4dfd9e21621dec4357d8;

	// Token: 0x04000477 RID: 1143
	internal static int m_c835c27d43a14f3da6b7339e694b8c99;

	// Token: 0x04000478 RID: 1144
	internal static int m_df90654cf93748ec8b3f08513de52694;

	// Token: 0x04000479 RID: 1145
	internal static int m_6fd435aca0274a86955ba7bbb960082d;

	// Token: 0x0400047A RID: 1146
	internal static int m_226f95e821ae480585438175bbddf9be;

	// Token: 0x0400047B RID: 1147
	internal static int m_5b41e96a488843f6bf9e80607461149a;

	// Token: 0x0400047C RID: 1148
	internal static int m_c9958ff501e7430a9a68ee9837d30eaa;

	// Token: 0x0400047D RID: 1149
	internal static int m_acfa09b970e04d3e89283a58545b6d36;

	// Token: 0x0400047E RID: 1150
	internal static int m_78ab67cec1824b2289ca2a9b24f27de2;

	// Token: 0x0400047F RID: 1151
	internal static int m_cc95b2f29ca843e1a5155e0d5770ad09;

	// Token: 0x04000480 RID: 1152
	internal static int m_26eee6bc8981469dae80fe8383e39f2d;

	// Token: 0x04000481 RID: 1153
	internal static int m_f8f2733f262849f48168e4f76ab239d7;

	// Token: 0x04000482 RID: 1154
	internal static int m_1ec1c85d27ea4a539ba7e0e334676a34;

	// Token: 0x04000483 RID: 1155
	internal static int m_5e42540a7e2247379e20536f2877b437;

	// Token: 0x04000484 RID: 1156
	internal static int m_f07fcafdab6044ae94aa2a4d4d748d5c;

	// Token: 0x04000485 RID: 1157
	internal static int m_f40e85c0282d4285a254092b800ae8f8;

	// Token: 0x04000486 RID: 1158
	internal static int m_8590fa2330a9409ebec2e2249b244600;

	// Token: 0x04000487 RID: 1159
	internal static int m_0883e7397db64368b06c9c6e6d729e08;

	// Token: 0x04000488 RID: 1160
	internal static int m_0c080a9909304bb4a8ca9ea8d5e25f67;

	// Token: 0x04000489 RID: 1161
	internal static int m_84a9e919b9fe4f039ce072ff9fa8ab32;

	// Token: 0x0400048A RID: 1162
	internal static int m_c609793e83ea4d9f8a76fd0fe20634d3;

	// Token: 0x0400048B RID: 1163
	internal static int m_3033bf1c1fc44fbd97a2780a04032069;

	// Token: 0x0400048C RID: 1164
	internal static int m_1eba0904f5ed439aa0e9edb8d6f647ef;

	// Token: 0x0400048D RID: 1165
	internal static int m_450de79ddfe6409a988b8682e74747f2;

	// Token: 0x0400048E RID: 1166
	internal static int m_01d314db732841fc934f41441894a8f2;

	// Token: 0x0400048F RID: 1167
	internal static int m_114c8e4d680c4b9997b685901f6ff336;

	// Token: 0x04000490 RID: 1168
	internal static int m_048cbf45e2414893ae0803941a76e8e0;

	// Token: 0x04000491 RID: 1169
	internal static int m_0656062713004318aa3a835b6bf28eab;

	// Token: 0x04000492 RID: 1170
	internal static int m_30d33a1ced8343dfb34aa8f1408e62af;

	// Token: 0x04000493 RID: 1171
	internal static int m_034caeaa576b4bc4a97d7628b4976987;

	// Token: 0x04000494 RID: 1172
	internal static int m_d6675f44e192471dbaeaf2d22fed78ae;

	// Token: 0x04000495 RID: 1173
	internal static int m_c7104ccd40024e009409c6d14eb5a99a;

	// Token: 0x04000496 RID: 1174
	internal static int m_923fe78ab3e6434cb4a8749dafbd7eb4;

	// Token: 0x04000497 RID: 1175
	internal static int m_669639b2fc7d4196b99820c1478aeb2d;

	// Token: 0x04000498 RID: 1176
	internal static int m_5d83dab2d7c4415687f4df21e1f4a0a7;

	// Token: 0x04000499 RID: 1177
	internal static int m_f4a460e528dc4f8f9f02849e498e6a35;

	// Token: 0x0400049A RID: 1178
	internal static int m_0a2b7fe605ba404ba745ea0e50bfd1bb;

	// Token: 0x0400049B RID: 1179
	internal static int m_a045e374816444ca92d30db5245d264e;

	// Token: 0x0400049C RID: 1180
	internal static int m_60948d6233084caaad2cec2725ac87ec;

	// Token: 0x0400049D RID: 1181
	internal static int m_cd19de316ac941abb4bc8c157ab3d341;

	// Token: 0x0400049E RID: 1182
	internal static int m_37d2e63e4691457582d3a8717f754394;

	// Token: 0x0400049F RID: 1183
	internal static int m_f3698823c3c74819a0d3976ddbed89ba;

	// Token: 0x040004A0 RID: 1184
	internal static int m_1ae970e9678b41e298250f643c4313e8;

	// Token: 0x040004A1 RID: 1185
	internal static int m_6112394f91444b1a8348d0503b4f813b;

	// Token: 0x040004A2 RID: 1186
	internal static int m_d808aff233c746968dbfcb5437cf67e9;

	// Token: 0x040004A3 RID: 1187
	internal static int m_4130c9db5c2b43e596cc610f57348b4a;

	// Token: 0x040004A4 RID: 1188
	internal static int m_1fb8b2aca6884e69a3c8f5ed9b2ba50b;

	// Token: 0x040004A5 RID: 1189
	internal static int m_e9ed32793f344edc971bad365818217d;

	// Token: 0x040004A6 RID: 1190
	internal static int m_827c6d37267a42a5864c59085f394f8f;

	// Token: 0x040004A7 RID: 1191
	internal static <Module>{cb13cea5-238d-4db2-b197-7f40acede0b8} FXh1E80ubRbXCgl7wdd;
}
