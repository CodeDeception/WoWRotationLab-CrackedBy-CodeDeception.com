﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;

namespace RotationLabEngine
{
	// Token: 0x02000034 RID: 52
	public static class ClassType
	{
		// Token: 0x06000547 RID: 1351 RVA: 0x0002D094 File Offset: 0x0002B294
		// Note: this type is marked as 'beforefieldinit'.
		static ClassType()
		{
			ClassType.xaGaJG4UjGOhvGks3W3();
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x0002D0A4 File Offset: 0x0002B2A4
		internal static void xaGaJG4UjGOhvGks3W3()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x040001EE RID: 494
		public const int Warrior = 1;

		// Token: 0x040001EF RID: 495
		public const int Paladin = 2;

		// Token: 0x040001F0 RID: 496
		public const int Hunter = 3;

		// Token: 0x040001F1 RID: 497
		public const int Rogue = 4;

		// Token: 0x040001F2 RID: 498
		public const int Priest = 5;

		// Token: 0x040001F3 RID: 499
		public const int DeathKnight = 6;

		// Token: 0x040001F4 RID: 500
		public const int Shaman = 7;

		// Token: 0x040001F5 RID: 501
		public const int Mage = 8;

		// Token: 0x040001F6 RID: 502
		public const int Warlock = 9;

		// Token: 0x040001F7 RID: 503
		public const int Monk = 10;

		// Token: 0x040001F8 RID: 504
		public const int Druid = 11;

		// Token: 0x040001F9 RID: 505
		public const int DemonHunter = 12;
	}
}
