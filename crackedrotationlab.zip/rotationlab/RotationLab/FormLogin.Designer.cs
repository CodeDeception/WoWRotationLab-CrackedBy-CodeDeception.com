﻿namespace RotationLabEngine
{
	// Token: 0x02000029 RID: 41
	public partial class FormLogin : global::System.Windows.Forms.Form
	{
		// Token: 0x0600042E RID: 1070 RVA: 0x00027734 File Offset: 0x00025934
		protected override void Dispose(bool disposing)
		{
			if (!disposing)
			{
				goto IL_49;
			}
			if (this.components != null)
			{
				goto IL_6A;
			}
			int num = 0;
			if (global::<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_24c6414a8a5b4f2680c42f1a5855f977 != 0)
			{
				num = 0;
			}
			IL_10:
			switch (num)
			{
			case 1:
				return;
			case 2:
				IL_6A:
				global::RotationLabEngine.FormLogin.PO6DtnUNJ2VUEXxfW8l(this.components);
				num = 3;
				goto IL_10;
			}
			IL_49:
			base.Dispose(disposing);
			num = 0;
			if (global::<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_cd978457d1e445849b2a5ed79e10da71 == 0)
			{
				num = 1;
				goto IL_10;
			}
			goto IL_10;
		}

		// Token: 0x040001AE RID: 430
		private global::System.ComponentModel.IContainer components;
	}
}
