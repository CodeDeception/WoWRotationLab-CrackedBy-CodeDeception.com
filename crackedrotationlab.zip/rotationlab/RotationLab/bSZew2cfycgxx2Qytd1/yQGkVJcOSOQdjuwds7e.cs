﻿using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using MyU9Ep58ZH3s5ThDFJQ;
using PeanutButter.INI;
using PFKsXUln68gK98ndGV;
using qh4tv5C06LoTjDckaL;
using RotationLabEngine;
using XR7RtrxI8Vm7Dgx9BKr;

namespace bSZew2cfycgxx2Qytd1
{
	// Token: 0x02000031 RID: 49
	internal static class yQGkVJcOSOQdjuwds7e
	{
		// Token: 0x0600052F RID: 1327 RVA: 0x0002CBD8 File Offset: 0x0002ADD8
		internal static void eHkcFjwTAE()
		{
			int num = 7;
			for (;;)
			{
				int num2 = num;
				InA3Q4LFDQmiFopNqj inA3Q4LFDQmiFopNqj;
				for (;;)
				{
					switch (num2)
					{
					case 0:
						goto IL_2AD;
					case 1:
						break;
					case 2:
						yQGkVJcOSOQdjuwds7e.s6rS0F4VREk1lvEeSYu(yQGkVJcOSOQdjuwds7e.ini, Encoding.UTF8);
						num2 = 19;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0656062713004318aa3a835b6bf28eab != 0)
						{
							num2 = 18;
							continue;
						}
						continue;
					case 3:
						Application.SetCompatibleTextRenderingDefault(false);
						num2 = 10;
						continue;
					case 4:
						goto IL_BC;
					case 5:
						return;
					case 6:
						yQGkVJcOSOQdjuwds7e.xE5cT9HGIm();
						num2 = 0;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_a65af4741e8c4e4da9b36e623cb150b3 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 7:
						if (yQGkVJcOSOQdjuwds7e.sG16BSpbIlvHfN5vtGh(Environment.OSVersion.Version) >= 6)
						{
							num2 = 6;
							continue;
						}
						goto IL_2AD;
					case 8:
						if (inA3Q4LFDQmiFopNqj != null)
						{
							num2 = 15;
							continue;
						}
						goto IL_BC;
					case 9:
						goto IL_23A;
					case 10:
						yQGkVJcOSOQdjuwds7e.apHJYB4W3pZ5lwhoPlC();
						if (!(Path.GetFileName(yQGkVJcOSOQdjuwds7e.zJasST4PZJIU8Cd7Bnd()) == vua32v5yjQhjRjK4YIO.BRA5TcZvlv(1657092858 << 1 ^ -980798742)))
						{
							num2 = 21;
							continue;
						}
						goto IL_F7;
					case 11:
						goto IL_F7;
					case 12:
						goto IL_36C;
					case 13:
						inA3Q4LFDQmiFopNqj = yQGkVJcOSOQdjuwds7e.M8rTEW4qEbC5eEx7tiG(yQGkVJcOSOQdjuwds7e.rHp72V48mS71QJole9q(yQGkVJcOSOQdjuwds7e.ini, vua32v5yjQhjRjK4YIO.BRA5TcZvlv(464986539 ^ 464987001), vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1755352853 ^ -1755352561), ""));
						num2 = 3;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_0e5e3d7d8cdf4d2a9040ab7043b65fe6 == 0)
						{
							num2 = 8;
							continue;
						}
						continue;
					case 14:
						goto IL_1F2;
					case 15:
						goto IL_2FE;
					case 16:
						return;
					case 17:
						goto IL_140;
					case 18:
						goto IL_140;
					case 19:
						if (yQGkVJcOSOQdjuwds7e.El7hdt4ylKV46gylYnH(yQGkVJcOSOQdjuwds7e.ini.GetValue(vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-1872685799 ^ -1872685109), vua32v5yjQhjRjK4YIO.BRA5TcZvlv(359120413 ^ 359120121), ""), ""))
						{
							num2 = 13;
							continue;
						}
						goto IL_BC;
					case 20:
						return;
					case 21:
						break;
					default:
						goto IL_2AD;
					}
					yQGkVJcOSOQdjuwds7e.ini = new INIFile(yQGkVJcOSOQdjuwds7e.weJH1G4u97UyuYi6tHw(yQGkVJcOSOQdjuwds7e.ug7Chg4xYsWf9BoKJuL(yQGkVJcOSOQdjuwds7e.OXlajH45yyOacXpFJF5().Location), vua32v5yjQhjRjK4YIO.BRA5TcZvlv(-902888658 ^ -902871822)));
					num2 = 2;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_450de79ddfe6409a988b8682e74747f2 != 0)
					{
						num2 = 2;
						continue;
					}
					continue;
					IL_F7:
					yQGkVJcOSOQdjuwds7e.SWi0Zh4csYGEfTNjmc3(yQGkVJcOSOQdjuwds7e.JPsPHo4EQ0J75bmbroQ(171996523 ^ 171979307), yQGkVJcOSOQdjuwds7e.JPsPHo4EQ0J75bmbroQ(-506871478 - 1486829658 ^ -1993683142), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					num2 = 0;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_2450e204911e419ba8c7c2ba4ba001f5 != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
					IL_140:
					if (yQGkVJcOSOQdjuwds7e.AuthenticatedUserData == null)
					{
						num2 = 5;
						if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_f6be3324a0314b2e90c5fdfd38911414 == 0)
						{
							num2 = 4;
							continue;
						}
						continue;
					}
					IL_1F2:
					if (yQGkVJcOSOQdjuwds7e.AuthenticatedUserData.Username != null)
					{
						yQGkVJcOSOQdjuwds7e.uE0Lws4dhRtEKwPaxXI(new Form1());
						num2 = 16;
						continue;
					}
					num2 = 20;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_a8b0fe86ca414d59a00505e4688a2028 == 0)
					{
						num2 = 17;
						continue;
					}
					continue;
					IL_23A:
					if (yQGkVJcOSOQdjuwds7e.AuthenticatedUserData.Error == null)
					{
						num2 = 18;
						continue;
					}
					goto IL_36C;
					IL_BC:
					if (yQGkVJcOSOQdjuwds7e.AuthenticatedUserData == null)
					{
						break;
					}
					goto IL_23A;
					IL_2AD:
					yQGkVJcOSOQdjuwds7e.UQ4GtxpzWBgpaDBx0ib();
					num2 = 3;
					continue;
					IL_36C:
					yQGkVJcOSOQdjuwds7e.uE0Lws4dhRtEKwPaxXI(new FormLogin());
					num2 = 17;
					if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_289b03d4275042dab02535e36c7e14db == 0)
					{
						num2 = 9;
					}
				}
				num = 12;
				continue;
				IL_2FE:
				yQGkVJcOSOQdjuwds7e.AuthenticatedUserData = inA3Q4LFDQmiFopNqj;
				num = 4;
			}
		}

		// Token: 0x06000530 RID: 1328
		[DllImport("user32.dll", EntryPoint = "SetProcessDPIAware")]
		private static extern bool xE5cT9HGIm();

		// Token: 0x06000531 RID: 1329 RVA: 0x0002CF74 File Offset: 0x0002B174
		// Note: this type is marked as 'beforefieldinit'.
		static yQGkVJcOSOQdjuwds7e()
		{
			yQGkVJcOSOQdjuwds7e.MXRwqU4obY9DgZYckoh();
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x0002CF7C File Offset: 0x0002B17C
		internal static int sG16BSpbIlvHfN5vtGh(object A_0)
		{
			return A_0.Major;
		}

		// Token: 0x06000533 RID: 1331 RVA: 0x0002CF88 File Offset: 0x0002B188
		internal static void UQ4GtxpzWBgpaDBx0ib()
		{
			Application.EnableVisualStyles();
		}

		// Token: 0x06000534 RID: 1332 RVA: 0x0002CF90 File Offset: 0x0002B190
		internal static void apHJYB4W3pZ5lwhoPlC()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x06000535 RID: 1333 RVA: 0x0002CF98 File Offset: 0x0002B198
		internal static object zJasST4PZJIU8Cd7Bnd()
		{
			return Application.ExecutablePath;
		}

		// Token: 0x06000536 RID: 1334 RVA: 0x0002CFA0 File Offset: 0x0002B1A0
		internal static object JPsPHo4EQ0J75bmbroQ(int \u0020)
		{
			return vua32v5yjQhjRjK4YIO.BRA5TcZvlv(\u0020);
		}

		// Token: 0x06000537 RID: 1335 RVA: 0x0002CFAC File Offset: 0x0002B1AC
		internal static DialogResult SWi0Zh4csYGEfTNjmc3(object A_0, object A_1, MessageBoxButtons A_2, MessageBoxIcon A_3)
		{
			return MessageBox.Show(A_0, A_1, A_2, A_3);
		}

		// Token: 0x06000538 RID: 1336 RVA: 0x0002CFC4 File Offset: 0x0002B1C4
		internal static object OXlajH45yyOacXpFJF5()
		{
			return Assembly.GetExecutingAssembly();
		}

		// Token: 0x06000539 RID: 1337 RVA: 0x0002CFCC File Offset: 0x0002B1CC
		internal static object ug7Chg4xYsWf9BoKJuL(object A_0)
		{
			return Path.GetDirectoryName(A_0);
		}

		// Token: 0x0600053A RID: 1338 RVA: 0x0002CFD8 File Offset: 0x0002B1D8
		internal static object weJH1G4u97UyuYi6tHw(object A_0, object A_1)
		{
			return Path.Combine(A_0, A_1);
		}

		// Token: 0x0600053B RID: 1339 RVA: 0x0002CFE8 File Offset: 0x0002B1E8
		internal static void s6rS0F4VREk1lvEeSYu(object A_0, object A_1)
		{
			A_0.DefaultEncoding = A_1;
		}

		// Token: 0x0600053C RID: 1340 RVA: 0x0002CFF8 File Offset: 0x0002B1F8
		internal static bool El7hdt4ylKV46gylYnH(object A_0, object A_1)
		{
			return A_0 != A_1;
		}

		// Token: 0x0600053D RID: 1341 RVA: 0x0002D008 File Offset: 0x0002B208
		internal static object rHp72V48mS71QJole9q(object A_0, object A_1, object A_2, object A_3)
		{
			return A_0.GetValue(A_1, A_2, A_3);
		}

		// Token: 0x0600053E RID: 1342 RVA: 0x0002D020 File Offset: 0x0002B220
		internal static object M8rTEW4qEbC5eEx7tiG(object A_0)
		{
			return icdoeGQQtZwolxBdqe.xD5ivBQoQ(A_0);
		}

		// Token: 0x0600053F RID: 1343 RVA: 0x0002D02C File Offset: 0x0002B22C
		internal static void uE0Lws4dhRtEKwPaxXI(object A_0)
		{
			Application.Run(A_0);
		}

		// Token: 0x06000540 RID: 1344 RVA: 0x0002D038 File Offset: 0x0002B238
		internal static bool Fb4A45pvDy2vsYd0L9K()
		{
			return yQGkVJcOSOQdjuwds7e.WqbwLepDvltyK6xmnFR == null;
		}

		// Token: 0x06000541 RID: 1345 RVA: 0x0002D044 File Offset: 0x0002B244
		internal static yQGkVJcOSOQdjuwds7e ASTweDpj2XLy7XmUpGb()
		{
			return yQGkVJcOSOQdjuwds7e.WqbwLepDvltyK6xmnFR;
		}

		// Token: 0x06000542 RID: 1346 RVA: 0x0002D04C File Offset: 0x0002B24C
		internal static void MXRwqU4obY9DgZYckoh()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x040001DB RID: 475
		public static INIFile ini;

		// Token: 0x040001DC RID: 476
		public static InA3Q4LFDQmiFopNqj AuthenticatedUserData;

		// Token: 0x040001DD RID: 477
		private static yQGkVJcOSOQdjuwds7e WqbwLepDvltyK6xmnFR;
	}
}
