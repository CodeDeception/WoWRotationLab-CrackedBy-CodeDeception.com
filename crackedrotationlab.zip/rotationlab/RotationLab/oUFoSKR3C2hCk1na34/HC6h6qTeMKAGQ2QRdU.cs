﻿using System;
using System.Collections.Generic;
using MyU9Ep58ZH3s5ThDFJQ;
using XR7RtrxI8Vm7Dgx9BKr;

namespace oUFoSKR3C2hCk1na34
{
	// Token: 0x02000013 RID: 19
	internal class HC6h6qTeMKAGQ2QRdU
	{
		// Token: 0x06000089 RID: 137 RVA: 0x00004A5C File Offset: 0x00002C5C
		public HC6h6qTeMKAGQ2QRdU()
		{
			HC6h6qTeMKAGQ2QRdU.c9mnUPQoENI6Pkj7YtO();
			HC6h6qTeMKAGQ2QRdU.rAcL3ZQ3qtNaOKlsHwc();
			base..ctor();
			int num = 0;
			if (<Module>{cb13cea5-238d-4db2-b197-7f40acede0b8}.m_827c6d37267a42a5864c59085f394f8f == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600008A RID: 138 RVA: 0x00004ABC File Offset: 0x00002CBC
		// Note: this type is marked as 'beforefieldinit'.
		static HC6h6qTeMKAGQ2QRdU()
		{
			vua32v5yjQhjRjK4YIO.aep5UvAyyY();
		}

		// Token: 0x0600008B RID: 139 RVA: 0x00004ACC File Offset: 0x00002CCC
		internal static void c9mnUPQoENI6Pkj7YtO()
		{
			vua32v5yjQhjRjK4YIO.p1T5fGSd8t();
		}

		// Token: 0x0600008C RID: 140 RVA: 0x00004ADC File Offset: 0x00002CDC
		internal static void rAcL3ZQ3qtNaOKlsHwc()
		{
			PnrHSvxSLFnA986pZWM.QUh0QAwUQW();
		}

		// Token: 0x0600008D RID: 141 RVA: 0x00004AEC File Offset: 0x00002CEC
		internal static bool S3uei9QqdVWeKtGGeRD()
		{
			return HC6h6qTeMKAGQ2QRdU.CbI7muQ8f1QsQTxYATd == null;
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00004B00 File Offset: 0x00002D00
		internal static HC6h6qTeMKAGQ2QRdU q13ToGQdKmgA9xqDgQW()
		{
			return HC6h6qTeMKAGQ2QRdU.CbI7muQ8f1QsQTxYATd;
		}

		// Token: 0x040000D8 RID: 216
		public int CheckR;

		// Token: 0x040000D9 RID: 217
		public int CheckG;

		// Token: 0x040000DA RID: 218
		public int CheckB;

		// Token: 0x040000DB RID: 219
		public Dictionary<string, string> Files;

		// Token: 0x040000DC RID: 220
		public string Error;

		// Token: 0x040000DD RID: 221
		internal static HC6h6qTeMKAGQ2QRdU CbI7muQ8f1QsQTxYATd;
	}
}
