﻿using System;
using MyU9Ep58ZH3s5ThDFJQ;

// Token: 0x02000056 RID: 86
internal class <Module>{257AB92C-9F14-4BF8-A136-AD424ED38FED}
{
	// Token: 0x060007F0 RID: 2032 RVA: 0x000431CC File Offset: 0x000413CC
	static <Module>{257AB92C-9F14-4BF8-A136-AD424ED38FED}()
	{
		vua32v5yjQhjRjK4YIO.aep5UvAyyY();
	}
}
